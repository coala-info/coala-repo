"""
CWL Agent - Main orchestrator for generating CWL from CLI help documents.

This module provides the CWLAgent class that orchestrates the full workflow:
1. Parse CLI help text using LLM (Gemini)
2. Generate CWL v1.2 CommandLineTool
3. Search for BioContainers Docker images
4. Search for tool homepage
5. Validate generated CWL with cwltool
6. Optionally run demo execution
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import re
import subprocess
import tempfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Literal, Optional

import httpx

from cwlagent.generator import CWLGenerator, load_cwl_yaml
from cwlagent.models import CWLCommandLineTool, DockerRequirement
from cwlagent.parser import GeminiProvider, HelpTextParser
from cwlagent.validator import CWLValidator, ValidationResult

logger = logging.getLogger(__name__)


def _normalize_api_key(api_key: Optional[str]) -> Optional[str]:
    """Remove first and last character (key stored as 1 + 39-char key + 1). Idempotent: if already 39 chars starting with AIza, return as-is."""
    if not api_key:
        return api_key
    key = api_key.strip()
    if len(key) == 39 and key.startswith("AIza"):
        return key
    if len(key) < 2:
        return key
    return key[1:-1].strip() or key


@dataclass
class AgentResult:
    """Result from CWL agent generation process."""

    # Input
    help_text: str
    tool_name: str

    # Generated content
    cwl_yaml: str
    cwl_model: CWLCommandLineTool

    # Validation
    validation_result: ValidationResult
    validation_passed: bool

    # Optional metadata
    docker_image: Optional[str] = None
    tool_homepage: Optional[str] = None
    tool_description: Optional[str] = None

    # Execution demo
    demo_executed: bool = False
    demo_passed: bool = False
    demo_output: Optional[str] = None
    demo_error: Optional[str] = None

    # Labels
    labels: dict[str, str] = field(default_factory=dict)

    # Generation failed before producing valid CWL (e.g. command not found in Docker image)
    generation_failed: bool = False
    fail_reason: Optional[str] = None

    def to_dict(self) -> dict[str, Any]:
        """Convert result to dictionary."""
        return {
            "tool_name": self.tool_name,
            "help_text": self.help_text,
            "cwl_yaml": self.cwl_yaml,
            "validation": {
                "passed": self.validation_passed,
                "label": self.labels.get("validation", ""),
                "errors": self.validation_result.errors if self.validation_result else [],
                "warnings": self.validation_result.warnings if self.validation_result else [],
            },
            "docker_image": self.docker_image,
            "tool_homepage": self.tool_homepage,
            "tool_description": self.tool_description,
            "demo": {
                "executed": self.demo_executed,
                "passed": self.demo_passed,
                "label": self.labels.get("demo", ""),
                "output": self.demo_output,
                "error": self.demo_error,
            },
            "labels": self.labels,
            "generation_failed": self.generation_failed,
            "fail_reason": self.fail_reason,
        }


def _parse_version_key(meta_version: str) -> tuple[int, ...]:
    """Parse meta_version into a comparable tuple (e.g. '2.27.1' -> (2, 27, 1)). All elements are int so sort never mixes str/int."""
    s = (meta_version or "").strip().lstrip("vV")
    parts: list[int] = []
    for segment in re.split(r"[\\._-]", s):
        try:
            parts.append(int(segment))
        except ValueError:
            # Non-numeric suffix (e.g. 2.26.0gx, 1.2.rglab): use -1 so sort is well-defined (no str vs int)
            parts.append(-1)
    return tuple(parts)


def _pick_docker_image_from_version(version_payload: dict[str, Any]) -> Optional[str]:
    """
    From a TRS version detail response, pick the best Docker image.

    Prefers image_type=='Docker', then by 'updated' date (most recent first).
    Handles image_name that may be a JSON string of array (e.g. ["img1", "ubuntu:latest"]).
    """
    images = version_payload.get("images") or []
    docker_images = [img for img in images if (img or {}).get("image_type") == "Docker"]
    if not docker_images:
        return None

    # Sort by updated desc (most recent first); missing updated at end
    def sort_key(img: dict) -> tuple:
        updated = (img or {}).get("updated") or ""
        return (0 if updated else 1, updated)

    docker_images.sort(key=sort_key, reverse=True)
    best = docker_images[0]
    image_name = (best or {}).get("image_name")
    if not image_name or not isinstance(image_name, str):
        return None

    # image_name may be a JSON array string, e.g. '["quay.io/...", "ubuntu:latest"]'
    image_name = image_name.strip()
    if image_name.startswith("["):
        try:
            arr = json.loads(image_name)
            if isinstance(arr, list) and arr:
                # Prefer ubuntu:latest for common CLI tools (e.g. md5sum)
                for candidate in arr:
                    if isinstance(candidate, str):
                        cand = candidate.strip()
                        if "ubuntu" in cand.lower() or "debian" in cand.lower():
                            return cand
                return arr[0] if isinstance(arr[0], str) else None
        except (json.JSONDecodeError, TypeError):
            pass
    return image_name


# Tools that are typically in base images (GNU coreutils etc.) when not in BioContainers.
FALLBACK_IMAGE_FOR_TOOL: dict[str, str] = {
    "md5sum": "ubuntu:latest",
    "sha256sum": "ubuntu:latest",
    "grep": "ubuntu:latest",
    "sed": "ubuntu:latest",
    "awk": "ubuntu:latest",
    "sort": "ubuntu:latest",
    "cat": "ubuntu:latest",
    "head": "ubuntu:latest",
    "tail": "ubuntu:latest",
    "wc": "ubuntu:latest",
    "cut": "ubuntu:latest",
    "uniq": "ubuntu:latest",
    "tr": "ubuntu:latest",
    "echo": "ubuntu:latest",
    "basename": "ubuntu:latest",
    "dirname": "ubuntu:latest",
}


class BioContainersSearch:
    """
    Search for Docker images using BioContainers TRS API and fallbacks.

    Uses GA4GH TRS v2 API: https://api.biocontainers.pro/ga4gh/trs/v2/ui/
    - /tools?name=<tool>&organization=biocontainers -> pick tool, latest version
    - /tools/<id>/versions/<version_id> -> get images, pick Docker image
    For tools like md5sum not in BioContainers, returns ubuntu:latest (or from TRS images if present).
    """

    TRS_API_BASE = "https://api.biocontainers.pro/ga4gh/trs/v2"
    QUAY_API_URL = "https://quay.io/api/v1/repository"
    BIOCONTAINERS_NAMESPACE = "biocontainers"

    def __init__(self, timeout: float = 30.0):
        self.timeout = timeout

    async def _search_trs(self, client: httpx.AsyncClient, normalized: str) -> Optional[str]:
        """Search TRS API for tool name and organization=biocontainers; return Docker image or None."""
        # Normalize: strip and remove trailing hyphens so "samtools " or "samtools-view" can match
        normalized = normalized.strip().strip("-")
        if not normalized:
            return None

        tools_url = f"{self.TRS_API_BASE}/tools"
        params = {"name": normalized, "organization": self.BIOCONTAINERS_NAMESPACE}
        try:
            resp = await client.get(tools_url, params=params)
            if resp.status_code != 200:
                return None
            data = resp.json()
        except (httpx.HTTPError, ValueError, TypeError) as e:
            logger.debug(f"TRS tools request failed for {normalized}: {e}")
            return None

        # API may return a single tool object; normalize to list
        if isinstance(data, dict):
            data = [data]
        if not isinstance(data, list) or not data:
            return None

        def tool_sort_key(t: dict) -> tuple:
            """Prefer exact name match, then exact id match, then name startswith."""
            name = (t.get("name") or "").lower().replace("_", "-").strip()
            tid = (t.get("id") or "").lower().replace("_", "-").strip()
            n = normalized.lower()
            if name == n or tid == n:
                return (0, 0)
            if name.startswith(n) or tid.startswith(n):
                return (1, -len(name))
            if n in name or n in tid:
                return (2, -len(name))
            return (3, 0)

        def name_match(t: dict) -> bool:
            name = (t.get("name") or "").lower().replace("_", "-").strip()
            tid = (t.get("id") or "").lower().replace("_", "-").strip()
            return name == normalized or tid == normalized or normalized in (name, tid)

        candidates = [t for t in data if isinstance(t, dict) and name_match(t)]
        if not candidates:
            # Fallback: tools whose name or id contains normalized (e.g. "samtools" in "samtools-test")
            candidates = [
                t for t in data
                if isinstance(t, dict)
                and (normalized in ((t.get("name") or "").lower()) or normalized in ((t.get("id") or "").lower()))
            ]
        if not candidates:
            return None

        # Prefer exact match (e.g. "samtools" over "samtools-test")
        candidates.sort(key=tool_sort_key)
        tool = candidates[0]
        tool_id = tool.get("id")
        versions = tool.get("versions") or []
        if not tool_id or not versions:
            return None

        # Sort by meta_version (latest first)
        def version_sort(v: dict) -> tuple:
            return _parse_version_key((v or {}).get("meta_version") or "")

        sorted_versions = sorted(versions, key=version_sort, reverse=True)
        latest = sorted_versions[0]
        version_id = latest.get("id")
        version_url = latest.get("url")
        if not version_id and version_url:
            # Derive id from url if needed
            version_id = version_url.rstrip("/").split("/")[-1]

        if not version_id:
            return None

        # Fetch version descriptor to get images (API may return http:// but redirect to https)
        if version_url:
            detail_url = version_url
            if detail_url.startswith("http://"):
                detail_url = "https" + detail_url[4:]
        else:
            detail_url = f"{self.TRS_API_BASE}/tools/{tool_id}/versions/{version_id}"
        try:
            detail_resp = await client.get(detail_url, follow_redirects=True)
            if detail_resp.status_code != 200:
                return None
            version_payload = detail_resp.json()
        except (httpx.HTTPError, ValueError, TypeError) as e:
            logger.debug(f"TRS version detail failed for {tool_id}/{version_id}: {e}")
            return None

        if not isinstance(version_payload, dict):
            return None
        return _pick_docker_image_from_version(version_payload)

    async def search(self, tool_name: str) -> Optional[str]:
        """
        Search for a Docker image for the given tool.

        Uses BioContainers TRS API first (https://api.biocontainers.pro/ga4gh/trs/v2/ui/).
        For tools like md5sum (GNU coreutils), falls back to ubuntu:latest when not in TRS.

        Args:
            tool_name: Name of the tool to search for

        Returns:
            Docker image reference (e.g. quay.io/biocontainers/bedtools:2.27.1--1,
            or ubuntu:latest for md5sum) or None if not found
        """
        normalized = tool_name.lower().replace("_", "-").replace(" ", "-").strip().strip("-")

        # Known CLI tools in base images (e.g. md5sum) — return fallback without network
        fallback = FALLBACK_IMAGE_FOR_TOOL.get(normalized)
        if fallback:
            return fallback

        try:
            async with httpx.AsyncClient(timeout=self.timeout, follow_redirects=True) as client:
                # 1) TRS API
                image = await self._search_trs(client, normalized)
                if image:
                    return image
                # Try base name when compound (e.g. "samtools-view" -> "samtools")
                if "-" in normalized or "_" in normalized:
                    base_name = normalized.split("-")[0].split("_")[0]
                    if base_name and base_name != normalized:
                        image = await self._search_trs(client, base_name)
                        if image:
                            return image

                # 3) Legacy Quay-based search
                repo_url = f"{self.QUAY_API_URL}/{self.BIOCONTAINERS_NAMESPACE}/{normalized}"
                response = await client.get(repo_url)
                if response.status_code == 200:
                    tags_url = f"{repo_url}/tag/"
                    tags_response = await client.get(tags_url)
                    if tags_response.status_code == 200:
                        tags_data = tags_response.json()
                        tags = tags_data.get("tags", [])
                        valid_tags = [
                            t for t in tags
                            if not (t.get("name") or "").startswith("sha256")
                            and t.get("name") != "latest"
                        ]
                        if valid_tags:
                            # Prefer highest version (e.g. 1.23 over 1.20); fallback to last_modified
                            def quay_tag_sort_key(t: dict) -> tuple:
                                name = (t.get("name") or "").strip()
                                vm = _parse_version_key(
                                    name.split("--")[0] if "--" in name else name
                                )
                                return (vm, t.get("last_modified", ""))
                            sorted_tags = sorted(
                                valid_tags,
                                key=quay_tag_sort_key,
                                reverse=True,
                            )
                            latest_tag = sorted_tags[0].get("name", "latest")
                            return f"quay.io/{self.BIOCONTAINERS_NAMESPACE}/{normalized}:{latest_tag}"
                    return f"quay.io/{self.BIOCONTAINERS_NAMESPACE}/{normalized}"

                search_url = "https://quay.io/api/v1/find/repositories"
                search_response = await client.get(
                    search_url,
                    params={"query": normalized, "namespace": self.BIOCONTAINERS_NAMESPACE},
                )
                if search_response.status_code == 200:
                    search_data = search_response.json()
                    for result in search_data.get("results", []):
                        if result.get("namespace") == self.BIOCONTAINERS_NAMESPACE:
                            repo_name = result.get("name")
                            if repo_name and normalized in repo_name.lower():
                                return f"quay.io/{self.BIOCONTAINERS_NAMESPACE}/{repo_name}"
        except Exception as e:
            logger.warning(f"BioContainers search failed for {tool_name}: {e}")

        # Fallback for common CLI tools in base images (e.g. md5sum -> ubuntu:latest)
        fallback = FALLBACK_IMAGE_FOR_TOOL.get(normalized)
        if fallback:
            return fallback
        return None


class ToolHomepageSearch:
    """Search for tool homepage using web search."""

    def __init__(self, timeout: float = 30.0):
        self.timeout = timeout

    async def search(self, tool_name: str, tool_description: Optional[str] = None) -> Optional[str]:
        """
        Search for the tool's project homepage.

        Args:
            tool_name: Name of the tool
            tool_description: Optional description to help with search

        Returns:
            URL of the tool's homepage or None
        """
        # Common patterns for bioinformatics tools
        known_sources = {
            "samtools": "https://www.htslib.org/",
            "bcftools": "https://www.htslib.org/",
            "bwa": "https://github.com/lh3/bwa",
            "bowtie2": "https://github.com/BenLangmead/bowtie2",
            "fastqc": "https://www.bioinformatics.babraham.ac.uk/projects/fastqc/",
            "bedtools": "https://bedtools.readthedocs.io/",
            "gatk": "https://gatk.broadinstitute.org/",
            "star": "https://github.com/alexdobin/STAR",
            "hisat2": "https://github.com/DaehwanKimLab/hisat2",
            "salmon": "https://combine-lab.github.io/salmon/",
            "kallisto": "https://pachterlab.github.io/kallisto/",
            "picard": "https://broadinstitute.github.io/picard/",
            "trimmomatic": "http://www.usadellab.org/cms/?page=trimmomatic",
            "cutadapt": "https://cutadapt.readthedocs.io/",
            "multiqc": "https://multiqc.info/",
            "md5sum": "https://www.gnu.org/software/coreutils/",
            "grep": "https://www.gnu.org/software/grep/",
            "sed": "https://www.gnu.org/software/sed/",
            "awk": "https://www.gnu.org/software/gawk/",
            "sort": "https://www.gnu.org/software/coreutils/",
            "cat": "https://www.gnu.org/software/coreutils/",
            "head": "https://www.gnu.org/software/coreutils/",
            "tail": "https://www.gnu.org/software/coreutils/",
            "wc": "https://www.gnu.org/software/coreutils/",
        }

        normalized = tool_name.lower().replace("-", "").replace("_", "")

        # Check known sources first
        for key, url in known_sources.items():
            if key in normalized or normalized in key:
                return url

        # Try to search GitHub
        try:
            async with httpx.AsyncClient(timeout=self.timeout, follow_redirects=True) as client:
                # GitHub API search
                github_url = "https://api.github.com/search/repositories"
                params = {
                    "q": f"{tool_name} in:name,description",
                    "sort": "stars",
                    "order": "desc",
                    "per_page": 5,
                }
                headers = {"Accept": "application/vnd.github.v3+json"}

                response = await client.get(github_url, params=params, headers=headers)

                if response.status_code == 200:
                    data = response.json()
                    items = data.get("items", [])

                    for item in items:
                        name = item.get("name", "").lower()
                        if normalized in name or name in normalized:
                            return item.get("html_url")

                    # Return first result if no exact match
                    if items:
                        return items[0].get("html_url")

        except Exception as e:
            logger.warning(f"Homepage search failed for {tool_name}: {e}")

        return None


class CWLExecutor:
    """Execute CWL tools using cwltool for demo/testing."""

    def __init__(self, cwltool_path: str = "cwltool", use_singularity: bool = False):
        self.cwltool_path = cwltool_path
        self.use_singularity = use_singularity

    def execute(
        self,
        cwl_content: str,
        inputs: Optional[dict[str, Any]] = None,
        timeout: int = 60,
    ) -> tuple[bool, str, str]:
        """
        Execute a CWL tool with optional inputs.

        Args:
            cwl_content: CWL YAML content
            inputs: Input parameters as a dictionary
            timeout: Execution timeout in seconds

        Returns:
            Tuple of (success, stdout, stderr)
        """
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir_path = Path(tmpdir)

            # Write CWL file
            cwl_file = tmpdir_path / "tool.cwl"
            cwl_file.write_text(cwl_content)

            # Write inputs file if provided
            cmd = [self.cwltool_path]
            if self.use_singularity:
                cmd.append("--singularity")
            else:
                cmd.append("--no-container")

            if inputs:
                inputs_file = tmpdir_path / "inputs.json"
                inputs_file.write_text(json.dumps(inputs))
                cmd.extend([str(cwl_file), str(inputs_file)])
            else:
                cmd.append(str(cwl_file))

            try:
                result = subprocess.run(
                    cmd,
                    capture_output=True,
                    text=True,
                    timeout=timeout,
                    cwd=tmpdir,
                )

                return (
                    result.returncode == 0,
                    result.stdout,
                    result.stderr,
                )

            except subprocess.TimeoutExpired:
                return False, "", f"Execution timed out after {timeout} seconds"
            except Exception as e:
                return False, "", str(e)

    def create_demo_inputs(self, cwl_model: CWLCommandLineTool) -> Optional[dict[str, Any]]:
        """
        Create demo inputs based on CWL input definitions.

        Args:
            cwl_model: CWL model with input definitions

        Returns:
            Dictionary of demo inputs or None if inputs can't be auto-generated
        """
        inputs = {}

        for inp in cwl_model.inputs:
            input_id = inp.id
            input_type = inp.type_

            # Handle optional types
            if isinstance(input_type, list):
                # Find the non-null type
                for t in input_type:
                    if t != "null":
                        input_type = t
                        break

            # Skip if still a list (complex union type)
            if isinstance(input_type, list):
                continue

            # Generate demo values based on type
            if isinstance(input_type, dict):
                # Array or record type - skip for demo
                continue
            elif input_type == "string":
                inputs[input_id] = "demo_string"
            elif input_type == "int":
                inputs[input_id] = 1
            elif input_type == "float" or input_type == "double":
                inputs[input_id] = 1.0
            elif input_type == "boolean":
                inputs[input_id] = True
            elif input_type == "File":
                # Create a temporary demo file
                return None  # File inputs need special handling
            elif input_type == "Directory":
                return None  # Directory inputs need special handling

        return inputs if inputs else None


class CWLAgent:
    """
    Main agent for generating CWL CommandLineTool documents from CLI help text.

    This agent orchestrates the full workflow:
    1. Parse CLI help text using Gemini LLM
    2. Generate CWL v1.2 CommandLineTool
    3. Search for BioContainers Docker image
    4. Search for tool homepage
    5. Validate with cwltool
    6. Optionally run demo execution
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        model: str = "gemini-3-flash-preview",
        use_docker: bool = True,
        run_demo: bool = False,
        cwl_version: str = "v1.2",
        generation_method: Literal["structured", "direct"] = "structured",
        remove_docker_after_use: bool = True,
        use_singularity: bool = False,
    ):
        """
        Initialize the CWL Agent.

        Args:
            api_key: Google API key for Gemini. If None, uses GOOGLE_API_KEY env var.
                Key is normalized (trim first/last char) to support env vars wrapped in quotes.
            model: Gemini model name to use
            use_docker: Whether to search for and include Docker requirements
            run_demo: Whether to run demo execution after generation
            cwl_version: CWL version to use (default: v1.2)
            generation_method: "structured" = parse help to JSON then generate CWL;
                "direct" = single LLM prompt to generate CWL from help text.
            remove_docker_after_use: If True, remove pulled Docker image after generation (default).
                Set False to keep the image (e.g. for faster validate-run).
        """
        self.api_key = _normalize_api_key(api_key)
        if self.api_key:
            os.environ["GOOGLE_API_KEY"] = self.api_key  # SDK may read env; use normalized key
        self.model = model
        self.use_docker = use_docker
        self.use_singularity = use_singularity
        self.run_demo = run_demo
        self.remove_docker_after_use = remove_docker_after_use
        self.cwl_version = cwl_version
        self.generation_method = generation_method

        # Initialize components
        self.parser = HelpTextParser(
            llm_provider=GeminiProvider(api_key=self.api_key, model=model)
        )
        self.generator = CWLGenerator(cwl_version=cwl_version, stdout_capture=True)
        self.validator = CWLValidator()
        self.biocontainers = BioContainersSearch()
        self.homepage_search = ToolHomepageSearch()
        self.executor = CWLExecutor(use_singularity=use_singularity)

    async def generate_async(
        self,
        help_text: str,
        tool_name: Optional[str] = None,
        docker_image: Optional[str] = None,
        tool_homepage: Optional[str] = None,
    ) -> AgentResult:
        """
        Generate CWL from CLI help text asynchronously.

        Args:
            help_text: The CLI tool's help text (e.g., from --help)
            tool_name: Optional hint for the tool name
            docker_image: If set, use this image and skip BioContainers/Quay lookup.
            tool_homepage: If set, use this homepage and skip homepage lookup.

        Returns:
            AgentResult with generated CWL and metadata
        """
        if self.generation_method == "direct":
            return await self._generate_direct(
                help_text, tool_name, docker_image=docker_image, tool_homepage=tool_homepage
            )
        return await self._generate_structured(
            help_text, tool_name, docker_image=docker_image, tool_homepage=tool_homepage
        )

    async def _generate_direct(
        self,
        help_text: str,
        tool_name: Optional[str] = None,
        docker_image: Optional[str] = None,
        tool_homepage: Optional[str] = None,
    ) -> AgentResult:
        """Generate CWL via a single LLM prompt (help text -> CWL YAML)."""
        logger.info("Generating CWL directly from help text with LLM...")
        cwl_yaml_raw, actual_tool_name = await self.parser.generate_cwl_direct_async(
            help_text, tool_name
        )
        logger.info(f"Detected tool: {actual_tool_name}")

        try:
            cwl_model = load_cwl_yaml(cwl_yaml_raw)
            parse_ok = True
        except ValueError as e:
            logger.warning(f"Failed to parse LLM CWL as model: {e}")
            parse_ok = False
            base = (
                json.dumps(actual_tool_name.split())
                if " " in actual_tool_name
                else json.dumps(actual_tool_name)
            )
            cwl_model = load_cwl_yaml(
                f"cwlVersion: v1.2\nclass: CommandLineTool\nbaseCommand: {base}\ninputs: []\noutputs: []"
            )

        if docker_image is None and self.use_docker:
            docker_image = await self.biocontainers.search(actual_tool_name)
        if tool_homepage is None:
            tool_homepage = await self.homepage_search.search(actual_tool_name, cwl_model.doc)
        homepage = tool_homepage

        if parse_ok:
            if docker_image:
                docker_req = DockerRequirement(docker_pull=docker_image)
                if cwl_model.hints is None:
                    cwl_model.hints = []
                cwl_model.hints.append(docker_req)
            if homepage:
                doc_parts = [cwl_model.doc] if cwl_model.doc else []
                doc_parts.append(f"\nTool homepage: {homepage}")
                cwl_model.doc = "\n".join(doc_parts)
            cwl_yaml = self.generator.to_yaml(cwl_model)
        else:
            cwl_yaml = cwl_yaml_raw
        validation_result = self.validator.validate(cwl_yaml)
        validation_passed = validation_result.is_valid

        result = AgentResult(
            help_text=help_text,
            tool_name=actual_tool_name,
            cwl_yaml=cwl_yaml,
            cwl_model=cwl_model,
            validation_result=validation_result,
            validation_passed=validation_passed,
            docker_image=docker_image,
            tool_homepage=homepage,
            tool_description=cwl_model.doc,
            labels={"validation": "PASS" if validation_passed else "FAIL"},
        )
        if self.run_demo and validation_passed:
            demo_inputs = self.executor.create_demo_inputs(cwl_model)
            if demo_inputs is not None:
                success, stdout, stderr = self.executor.execute(cwl_yaml, demo_inputs)
                result.demo_executed = True
                result.demo_passed = success
                result.demo_output = stdout
                result.demo_error = stderr
                result.labels["demo"] = "PASS" if success else "FAIL"
            else:
                result.demo_executed = False
                result.labels["demo"] = "SKIPPED - Complex inputs required"
        return result

    async def _generate_structured(
        self,
        help_text: str,
        tool_name: Optional[str] = None,
        docker_image: Optional[str] = None,
        tool_homepage: Optional[str] = None,
    ) -> AgentResult:
        """Generate CWL via parse (help -> JSON) then generate (JSON -> CWL)."""
        logger.info("Parsing help text with Gemini...")
        tool_info = await self.parser.parse_async(help_text, tool_name)
        actual_tool_name = tool_name or tool_info.name
        logger.info(f"Detected tool: {actual_tool_name}")

        resolved_image_here = docker_image is None and self.use_docker
        resolved_homepage_here = tool_homepage is None
        if resolved_image_here:
            docker_image = await self.biocontainers.search(actual_tool_name)
        if resolved_homepage_here:
            tool_homepage = await self.homepage_search.search(
                actual_tool_name, tool_info.description
            )
        homepage = tool_homepage
        # Log image/homepage at INFO only when we resolved them here (single-tool generate); when
        # called from generate_multi they are pre-resolved once, so log at DEBUG to avoid spam
        if resolved_image_here or resolved_homepage_here:
            logger.info(f"Docker image: {docker_image or 'Not found'}")
            logger.info(f"Homepage: {homepage or 'Not found'}")
        else:
            logger.debug(f"Docker image: {docker_image or 'Not found'}")
            logger.debug(f"Homepage: {homepage or 'Not found'}")

        logger.info("Generating CWL...")
        cwl_model = self.generator.generate(tool_info)
        if docker_image:
            docker_req = DockerRequirement(docker_pull=docker_image)
            if cwl_model.hints is None:
                cwl_model.hints = []
            cwl_model.hints.append(docker_req)
        if homepage:
            doc_parts = [cwl_model.doc] if cwl_model.doc else []
            doc_parts.append(f"\nTool homepage: {homepage}")
            cwl_model.doc = "\n".join(doc_parts)

        cwl_yaml = self.generator.to_yaml(cwl_model)

        # Step 5: Validate
        logger.info("Validating CWL...")
        validation_result = self.validator.validate(cwl_yaml)
        validation_passed = validation_result.is_valid

        # Create result
        result = AgentResult(
            help_text=help_text,
            tool_name=actual_tool_name,
            cwl_yaml=cwl_yaml,
            cwl_model=cwl_model,
            validation_result=validation_result,
            validation_passed=validation_passed,
            docker_image=docker_image,
            tool_homepage=homepage,
            tool_description=tool_info.description,
            labels={
                "validation": "PASS" if validation_passed else "FAIL",
            },
        )

        # Step 6: Run demo if requested
        if self.run_demo and validation_passed:
            logger.info("Running demo execution...")
            demo_inputs = self.executor.create_demo_inputs(cwl_model)

            if demo_inputs is not None:
                success, stdout, stderr = self.executor.execute(cwl_yaml, demo_inputs)
                result.demo_executed = True
                result.demo_passed = success
                result.demo_output = stdout
                result.demo_error = stderr
                result.labels["demo"] = "PASS" if success else "FAIL"
            else:
                result.demo_executed = False
                result.labels["demo"] = "SKIPPED - Complex inputs required"

        return result

    def generate(
        self,
        help_text: str,
        tool_name: Optional[str] = None,
        docker_image: Optional[str] = None,
        tool_homepage: Optional[str] = None,
    ) -> AgentResult:
        """
        Generate CWL from CLI help text synchronously.

        Args:
            help_text: The CLI tool's help text (e.g., from --help)
            tool_name: Optional hint for the tool name
            docker_image: If set, use this image and skip BioContainers/Quay lookup.
            tool_homepage: If set, use this homepage and skip homepage lookup.

        Returns:
            AgentResult with generated CWL and metadata
        """
        return asyncio.run(
            self.generate_async(
                help_text, tool_name,
                docker_image=docker_image,
                tool_homepage=tool_homepage,
            )
        )

    async def generate_multi_async(
        self,
        command: str,
        default_docker_image: Optional[str] = None,
    ) -> list[AgentResult]:
        """
        Generate CWL for a command and, if it has subcommands, for each subcommand.

        Image API is searched once (base command). Docker image is pulled once. Each subcommand
        only parses its help text and generates/validates CWL (no per-sub image search or pull).

        When default_docker_image is set (e.g. ubuntu:latest), use it and skip BioContainers search.
        When use_docker is True and default_docker_image is None: resolves Docker image via BioContainers once.
        E.g. "samtools" -> [samtools_dict.cwl, samtools_faidx.cwl, ...]
        """
        base_command = command.split()[0].strip()
        # Resolve Docker image once: use default_docker_image if set, else search BioContainers once
        docker_image: Optional[str] = default_docker_image
        if docker_image is None and self.use_docker:
            docker_image = await self.biocontainers.search(base_command)
        tool_homepage = await self.homepage_search.search(base_command, None)
        logger.info(f"Docker image: {docker_image or 'Not found'}")
        logger.info(f"Homepage: {tool_homepage or 'Not found'}")

        # Pull image once so all get_help_text_from_docker calls use cache (no repeated download)
        if docker_image:
            self._pull_docker_image(docker_image, use_singularity=self.use_singularity)

        def _make_failed_result(fail_reason: str) -> AgentResult:
            minimal_cwl = (
                "cwlVersion: v1.2\nclass: CommandLineTool\nbaseCommand: unknown\n"
                "inputs: []\noutputs: []\n# Generation failed\n"
            )
            try:
                minimal_model = load_cwl_yaml(minimal_cwl)
            except Exception:
                minimal_model = load_cwl_yaml(
                    "cwlVersion: v1.2\nclass: CommandLineTool\nbaseCommand: unknown\ninputs: []\noutputs: []"
                )
            return AgentResult(
                help_text="",
                tool_name=base_command,
                cwl_yaml=minimal_cwl,
                cwl_model=minimal_model,
                validation_result=ValidationResult(
                    is_valid=False, errors=[fail_reason], warnings=[]
                ),
                validation_passed=False,
                docker_image=docker_image,
                tool_homepage=tool_homepage,
                tool_description=fail_reason,
                labels={"validation": "FAIL"},
                generation_failed=True,
                fail_reason=fail_reason,
            )

        # Get main help from Docker if we have an image, else from local
        try:
            if docker_image:
                main_help = self.get_help_text_from_docker(
                    docker_image, command, use_singularity=self.use_singularity
                )
                logger.info(
                    "Got main help from %s (not local)",
                    "Singularity" if self.use_singularity else "Docker",
                )
            else:
                main_help = self.get_help_text(command)
        except RuntimeError as e:
            if "FAIL to generate CWL" in str(e) or "not found in Docker image" in str(e):
                return [_make_failed_result(str(e))]
            logger.warning(f"Could not get help from Docker, falling back to local: {e}")
            try:
                main_help = self.get_help_text(command)
            except Exception as e2:
                return [_make_failed_result(f"{e}; fallback failed: {e2}")]
            # Keep docker_image so subcommands still use it for help and CWL (search/pull only once)
        except Exception as e:
            logger.warning(f"Could not get help from Docker, falling back to local: {e}")
            try:
                main_help = self.get_help_text(command)
            except Exception as e2:
                return [_make_failed_result(f"{e}; fallback failed: {e2}")]
            # Keep docker_image so subcommands still use it for help and CWL (search/pull only once)

        subcommands = await self.parser.extract_subcommands_async(main_help, base_command)

        if not subcommands:
            result = await self.generate_async(
                main_help,
                base_command,
                docker_image=docker_image,
                tool_homepage=tool_homepage,
            )
            if docker_image and self.remove_docker_after_use:
                self._remove_docker_image(docker_image)
            return [result]

        results: list[AgentResult] = []
        for sub in subcommands:
            try:
                if docker_image:
                    sub_help = self.get_help_text_from_docker(
                        docker_image,
                        f"{base_command} {sub}",
                        use_singularity=self.use_singularity,
                    )
                else:
                    sub_help = self.get_help_text(f"{base_command} {sub}")
            except RuntimeError as e:
                if "FAIL to generate CWL" in str(e) or "not found in Docker image" in str(e):
                    raise
                logger.warning(f"Could not get help for {base_command} {sub}: {e}")
                continue
            except Exception as e:
                logger.warning(f"Could not get help for {base_command} {sub}: {e}")
                continue
            tool_name = f"{base_command}_{sub}"
            logger.info(f"Generating CWL for {base_command} {sub} -> {tool_name}")
            result = await self.generate_async(
                sub_help,
                tool_name,
                docker_image=docker_image,
                tool_homepage=tool_homepage,
            )
            results.append(result)
        if docker_image and self.remove_docker_after_use:
            self._remove_docker_image(docker_image)
        return results

    def generate_multi(
        self,
        command: str,
        default_docker_image: Optional[str] = None,
    ) -> list[AgentResult]:
        """Synchronous wrapper for generate_multi_async."""
        return asyncio.run(self.generate_multi_async(command, default_docker_image))

    @staticmethod
    def get_help_text(command: str) -> str:
        """
        Get help text from a command by running it locally with --help.

        Args:
            command: The command to get help for (e.g., "md5sum", "samtools view")

        Returns:
            The help text output
        """
        parts = command.split()
        cmd = parts + ["--help"]

        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=10,
            )
            # Some tools output help to stderr
            return result.stdout or result.stderr
        except subprocess.TimeoutExpired:
            raise RuntimeError(f"Command timed out: {' '.join(cmd)}")
        except Exception as e:
            raise RuntimeError(f"Failed to get help text: {e}")

    @staticmethod
    def _alternative_first_token(token: str) -> list[str]:
        """
        Suggest alternative first token by stripping package-style prefix (e.g. 10x_bamtofastq -> bamtofastq).
        Used when docker run reports executable not found.
        """
        if not token or "_" not in token:
            return []
        candidates = []
        after_first = token.split("_", 1)[-1]
        if after_first and after_first != token:
            candidates.append(after_first)
        if "_" in after_first:
            after_last = token.rsplit("_", 1)[-1]
            if after_last and after_last != token and after_last not in candidates:
                candidates.append(after_last)
        return candidates

    @staticmethod
    def get_help_text_from_docker(
        image: str, command: str, timeout: int = 30, use_singularity: bool = False
    ) -> str:
        """
        Get help text by running the command inside a Docker (or Singularity) container (not local).

        If the executable is not found (e.g. container has bamtofastq but command is 10x_bamtofastq),
        retries with the first token's prefix stripped (e.g. bamtofastq --help).
        """
        parts = command.split() + ["--help"]
        if use_singularity:
            # singularity exec docker://...
            if "/" not in image and ":" not in image:
                # Simple image name -> assume docker hub
                s_image = f"docker://{image}"
            elif image.startswith("quay.io/"):
                s_image = f"docker://{image}"
            else:
                s_image = f"docker://{image}" if "://" not in image else image
            cmd = ["singularity", "exec", s_image] + parts
        else:
            cmd = ["docker", "run", "--rm", image] + parts

        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=timeout,
            )
            out = result.stdout or result.stderr or ""
            stderr = result.stderr or ""
            combined = (out + "\n" + stderr).lower()

            if result.returncode == 0:
                return (result.stdout or result.stderr or "").strip()

            # Executable not found (e.g. 10x_bamtofastq in container is actually bamtofastq)
            if (
                ("not found" in combined or "no such file" in combined)
                and len(parts) >= 1
                and "_" in parts[0]
            ):
                for alt in CWLAgent._alternative_first_token(parts[0]):
                    retry_parts = [alt] + parts[1:]
                    if use_singularity:
                        retry_cmd = ["singularity", "exec", s_image] + retry_parts
                    else:
                        retry_cmd = ["docker", "run", "--rm", image] + retry_parts
                    try:
                        retry_result = subprocess.run(
                            retry_cmd,
                            capture_output=True,
                            text=True,
                            timeout=timeout,
                        )
                        retry_out = retry_result.stdout or retry_result.stderr or ""
                        retry_lower = retry_out.lower()
                        # Do not treat "command not found" from retry as valid help
                        if "not found" in retry_lower or "no such file" in retry_lower:
                            continue
                        if retry_result.returncode == 0 or retry_out.strip():
                            logger.info(
                                "Got help after retrying with baseCommand %s -> %s",
                                parts[0],
                                alt,
                            )
                            return retry_out
                    except Exception:
                        continue

            if not out and not stderr:
                engine = "Singularity" if use_singularity else "docker run"
                raise RuntimeError(
                    f"{engine} exited {result.returncode}: {result.stderr or result.stdout}"
                )
            # Do not return "command not found" as help text; fail generation instead.
            combined_return = (out or stderr).strip()
            if ("not found" in combined_return.lower() or "no such file" in combined_return.lower()) and len(combined_return) < 500:
                exec_name = parts[0] if parts else "command"
                engine = "Singularity" if use_singularity else "Docker"
                raise RuntimeError(
                    f"FAIL to generate CWL: {exec_name} not found in {engine} image. "
                    "The image may not provide this executable."
                )
            return out or stderr
        except subprocess.TimeoutExpired:
            raise RuntimeError(f"Docker run timed out: {' '.join(cmd)}")
        except FileNotFoundError:
            engine = "Singularity" if use_singularity else "Docker"
            raise RuntimeError(f"{engine} not found; install {engine} or use local help.")
        except Exception as e:
            engine = "Singularity" if use_singularity else "Docker"
            raise RuntimeError(f"Failed to get help from {engine}: {e}") from e

    @staticmethod
    def _pull_docker_image(image: str, use_singularity: bool = False) -> None:
        """Pull the image once so subsequent docker run / singularity exec use cache."""
        if use_singularity:
            # Singularity caches on first exec; no separate pull API for docker://
            return
        try:
            subprocess.run(
                ["docker", "pull", image],
                capture_output=True,
                text=True,
                timeout=600,
            )
            logger.info(f"Pulled Docker image: {image}")
        except Exception as e:
            logger.warning(f"Could not pull Docker image {image}: {e}")

    @staticmethod
    def _remove_docker_image(image: str) -> None:
        """Remove a Docker image after use. Skips common base images to avoid breaking other use."""
        skip_rmi = any(
            image.startswith(p)
            for p in ("ubuntu:", "debian:", "busybox:", "alpine:")
        )
        if skip_rmi:
            logger.debug(f"Skipping docker rmi for base image: {image}")
            return
        try:
            subprocess.run(
                ["docker", "rmi", image],
                capture_output=True,
                text=True,
                timeout=60,
            )
            logger.info(f"Removed Docker image: {image}")
        except Exception as e:
            logger.warning(f"Could not remove Docker image {image}: {e}")

    @classmethod
    def from_command(
        cls,
        command: str,
        api_key: Optional[str] = None,
        model: str = "gemini-3-flash-preview",
        **kwargs: Any,
    ) -> AgentResult:
        """
        Generate CWL directly from a command.

        Args:
            command: The command to generate CWL for (e.g., "md5sum")
            api_key: Google API key for Gemini
            model: Gemini model name
            **kwargs: Additional arguments for CWLAgent

        Returns:
            AgentResult with generated CWL
        """
        agent = cls(api_key=api_key, model=model, **kwargs)
        help_text = agent.get_help_text(command)
        return agent.generate(help_text, command.split()[0])
