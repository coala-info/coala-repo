"""
CLI help text parser using LLM-based extraction.

This module provides functionality to parse unstructured CLI help text
and extract structured information about command-line arguments.
"""

from __future__ import annotations

import json
import logging
import os
import re
from abc import ABC, abstractmethod
from typing import Any, Optional

from pydantic import BaseModel

# Pattern: "Commands:" or "Subcommands:" or "Usage: ... <command>"
SUBCOMMANDS_SECTION_RE = re.compile(
    r"^(?:Commands|Subcommands|usage:.*<command>)\s*:\s*$",
    re.IGNORECASE | re.MULTILINE,
)
# Indented line whose first token looks like a subcommand (word or word-word, not --option)
SUBCOMMAND_LINE_RE = re.compile(r"^\s{2,}([\w-]+)(?:\s|$)")

from cwlagent.models import ArgumentType, CLIArgument, CLIToolInfo, CWLType
from cwlagent.skill_loader import get_cwl_commandlinetool_skill

logger = logging.getLogger(__name__)


# Few-shot examples for LLM prompting
FEW_SHOT_EXAMPLES = [
    {
        "help_text": """Usage: grep [OPTION]... PATTERN [FILE]...
Search for PATTERN in each FILE.
Example: grep -i 'hello world' menu.h main.c

Pattern selection and interpretation:
  -E, --extended-regexp     PATTERN is an extended regular expression
  -i, --ignore-case         ignore case distinctions

Output control:
  -c, --count               print only a count of matching lines per FILE
  -o, --only-matching       show only the part of a line matching PATTERN
  -n, --line-number         print line number with output lines

  -r, --recursive           like --directories=recurse
  -v, --invert-match        select non-matching lines""",
        "parsed": {
            "name": "grep",
            "base_command": "grep",
            "description": "Search for PATTERN in each FILE",
            "arguments": [
                {
                    "name": "pattern",
                    "arg_type": "positional",
                    "position": 1,
                    "value_type": "string",
                    "is_required": True,
                    "description": "Pattern to search for",
                },
                {
                    "name": "files",
                    "arg_type": "positional",
                    "position": 2,
                    "value_type": "File",
                    "is_required": False,
                    "is_array": True,
                    "description": "Files to search in",
                },
                {
                    "name": "extended_regexp",
                    "arg_type": "flag",
                    "short_flag": "-E",
                    "long_flag": "--extended-regexp",
                    "value_type": "boolean",
                    "description": "PATTERN is an extended regular expression",
                },
                {
                    "name": "ignore_case",
                    "arg_type": "flag",
                    "short_flag": "-i",
                    "long_flag": "--ignore-case",
                    "value_type": "boolean",
                    "description": "ignore case distinctions",
                },
                {
                    "name": "count",
                    "arg_type": "flag",
                    "short_flag": "-c",
                    "long_flag": "--count",
                    "value_type": "boolean",
                    "description": "print only a count of matching lines per FILE",
                },
                {
                    "name": "only_matching",
                    "arg_type": "flag",
                    "short_flag": "-o",
                    "long_flag": "--only-matching",
                    "value_type": "boolean",
                    "description": "show only the part of a line matching PATTERN",
                },
                {
                    "name": "line_number",
                    "arg_type": "flag",
                    "short_flag": "-n",
                    "long_flag": "--line-number",
                    "value_type": "boolean",
                    "description": "print line number with output lines",
                },
                {
                    "name": "recursive",
                    "arg_type": "flag",
                    "short_flag": "-r",
                    "long_flag": "--recursive",
                    "value_type": "boolean",
                    "description": "like --directories=recurse",
                },
                {
                    "name": "invert_match",
                    "arg_type": "flag",
                    "short_flag": "-v",
                    "long_flag": "--invert-match",
                    "value_type": "boolean",
                    "description": "select non-matching lines",
                },
            ],
        },
    },
    {
        "help_text": """Usage: samtools view [options] <in.bam>|<in.sam>|<in.cram> [region ...]

Options:
  -b       output BAM
  -C       output CRAM
  -h       include header in SAM output
  -H       print SAM header only (no alignments)
  -o FILE  output file name [stdout]
  -@ INT   number of threads [0]
  -q INT   minimum mapping quality [0]
  -f INT   required flag [0]
  -F INT   filtered flag [0]
  -L FILE  only include reads overlapping this BED FILE""",
        "parsed": {
            "name": "samtools_view",
            "base_command": ["samtools", "view"],
            "description": "View and convert SAM/BAM/CRAM files",
            "subcommand": "view",
            "arguments": [
                {
                    "name": "input_file",
                    "arg_type": "positional",
                    "position": 1,
                    "value_type": "File",
                    "is_required": True,
                    "description": "Input BAM/SAM/CRAM file",
                },
                {
                    "name": "region",
                    "arg_type": "positional",
                    "position": 2,
                    "value_type": "string",
                    "is_required": False,
                    "is_array": True,
                    "description": "Region(s) to extract",
                },
                {
                    "name": "output_bam",
                    "arg_type": "flag",
                    "short_flag": "-b",
                    "value_type": "boolean",
                    "description": "output BAM",
                },
                {
                    "name": "output_cram",
                    "arg_type": "flag",
                    "short_flag": "-C",
                    "value_type": "boolean",
                    "description": "output CRAM",
                },
                {
                    "name": "include_header",
                    "arg_type": "flag",
                    "short_flag": "-h",
                    "value_type": "boolean",
                    "description": "include header in SAM output",
                },
                {
                    "name": "header_only",
                    "arg_type": "flag",
                    "short_flag": "-H",
                    "value_type": "boolean",
                    "description": "print SAM header only (no alignments)",
                },
                {
                    "name": "output_file",
                    "arg_type": "option",
                    "short_flag": "-o",
                    "value_type": "File",
                    "is_output": True,
                    "description": "output file name",
                },
                {
                    "name": "threads",
                    "arg_type": "option",
                    "short_flag": "-@",
                    "value_type": "int",
                    "default_value": 0,
                    "description": "number of threads",
                },
                {
                    "name": "min_mapping_quality",
                    "arg_type": "option",
                    "short_flag": "-q",
                    "value_type": "int",
                    "default_value": 0,
                    "description": "minimum mapping quality",
                },
                {
                    "name": "required_flag",
                    "arg_type": "option",
                    "short_flag": "-f",
                    "value_type": "int",
                    "default_value": 0,
                    "description": "required flag",
                },
                {
                    "name": "filtered_flag",
                    "arg_type": "option",
                    "short_flag": "-F",
                    "value_type": "int",
                    "default_value": 0,
                    "description": "filtered flag",
                },
                {
                    "name": "bed_file",
                    "arg_type": "option",
                    "short_flag": "-L",
                    "value_type": "File",
                    "description": "only include reads overlapping this BED FILE",
                },
            ],
        },
    },
]


SYSTEM_PROMPT = """You are an expert at parsing command-line tool help text and extracting structured information.

Your task is to analyze CLI help text and extract:
1. Tool name and base command (including subcommands if present)
2. Description of the tool
3. All arguments with their:
   - name (identifier, snake_case)
   - arg_type: "flag" (boolean), "option" (takes value), or "positional"
   - short_flag (e.g., "-v")
   - long_flag (e.g., "--verbose")
   - value_type: "boolean", "string", "int", "float", "File", "Directory"
   - is_required: whether the argument is required
   - is_array: whether multiple values are accepted
   - default_value: if specified in help text
   - position: for positional arguments (1-indexed)
   - is_output: true if this is an output file/directory
   - description: from help text

Guidelines for type inference:
- Arguments like FILE, PATH, FILENAME → "File"
- Arguments like DIR, DIRECTORY, FOLDER → "Directory"
- Arguments like INT, NUM, COUNT, NUMBER → "int"
- Arguments like FLOAT, DECIMAL → "float"
- Arguments that are clearly flags (no value) → "boolean"
- Output files (with words like "output", "out", "write to") → is_output: true
- Arguments in [brackets] in usage are optional
- Arguments in <angle brackets> are required
- Arguments with ... suffix accept multiple values (is_array: true)
- Do NOT include --help, -h (help), or --version in the arguments list; they are meta-options for display only and should not appear as CWL inputs.

Return a JSON object with the structure shown in the examples."""


DIRECT_CWL_SYSTEM_PROMPT_BASE = """You are an expert at writing Common Workflow Language (CWL) CommandLineTool documents.

Your task is to generate a complete, valid CWL v1.2 CommandLineTool YAML document from the given CLI tool help text.

- Do NOT add inputs for --help, -h, or --version; they are meta-options for display only and are not used in CWL workflows.

Output only the CWL YAML document. Wrap it in a fenced code block with ```yaml and ```. Do not include any text before or after the YAML."""


def _build_direct_cwl_system_prompt(include_skill: bool = True) -> str:
    """Build system prompt for direct CWL generation, optionally including CWL CommandLineTool skill."""
    prompt = DIRECT_CWL_SYSTEM_PROMPT_BASE
    if include_skill:
        skill_content = get_cwl_commandlinetool_skill(include_references=True)
        if skill_content.strip():
            prompt = (
                prompt
                + "\n\n---\n\nFollow the CWL CommandLineTool skill below for structure, inputs/outputs, "
                "inputBinding, staging, and best practices:\n\n"
                + skill_content
            )
    return prompt


def _extract_yaml_from_response(response: str) -> str:
    """Extract YAML from LLM response, handling ```yaml ... ``` or ``` ... ``` blocks."""
    text = response.strip()
    if "```yaml" in text:
        start = text.index("```yaml") + 7
        end = text.index("```", start)
        return text[start:end].strip()
    if "```" in text:
        parts = text.split("```")
        for i, part in enumerate(parts):
            if i > 0 and part.strip() and not part.strip().startswith("yaml"):
                candidate = part.strip().lstrip("yaml").strip()
                if candidate.startswith("cwlVersion:") or candidate.startswith("cwlversion:"):
                    return candidate
        # Fallback: first code block
        if len(parts) >= 2:
            block = parts[1].strip().lstrip("yaml").strip()
            return block
    return text


def extract_subcommands_from_help(help_text: str) -> list[str]:
    """
    Parse help text for subcommand names (e.g. samtools -> dict, faidx, view, ...).

    Looks for "Commands:" / "Subcommands:" sections and indented lines whose first
    word is a subcommand. Returns empty list if no subcommands detected.
    """
    lines = help_text.splitlines()
    subcommands: list[str] = []
    in_commands_section = False

    for line in lines:
        stripped = line.strip()
        # Start of Commands/Subcommands section
        if re.match(r"^(?:Commands|Subcommands|Sub-commands)\s*:?\s*$", stripped, re.IGNORECASE):
            in_commands_section = True
            continue
        # Header line like "The bedtools sub-commands include:" starts the section
        if re.search(r"sub-commands?\s*:?\s*(?:include)?\s*$", stripped, re.IGNORECASE) and not subcommands:
            in_commands_section = True
            continue
        # Usage with <command> or <subcommand> indicates subcommands
        if re.search(r"usage:.*<(?:sub)?command>", line, re.IGNORECASE) and not subcommands:
            in_commands_section = True
        if not in_commands_section:
            continue
        # Category line like "  -- Indexing" or "  -- Viewing" - skip (don't treat as subcommand)
        if re.match(r"^\s*--", line):
            continue
        # Category header like "[ Genome arithmetic ]" (bedtools-style) - skip but stay in section
        if re.match(r"^\s*\[.+\]\s*$", line):
            continue
        # Blank line: do not end section; many tools (e.g. samtools) use blank lines between categories
        if not line.strip():
            continue
        # Non-indented line that is not a subcommand: end of Commands section
        if re.match(r"^\S", line) and not SUBCOMMAND_LINE_RE.match(line):
            if subcommands:
                break
            continue
        # Indented line: first word may be subcommand (skip "help", "version" if desired; we include all)
        match = SUBCOMMAND_LINE_RE.match(line)
        if match:
            name = match.group(1).lower()
            # Skip common meta-commands to avoid duplicate CWL with main help
            if name in ("help", "version") and subcommands:
                continue
            if name not in subcommands:
                subcommands.append(match.group(1))

    return subcommands


SUBCOMMANDS_LLM_SYSTEM = """You are analyzing CLI help text to detect if the tool uses subcommands.

If the tool has subcommands (e.g. "samtools" has dict, faidx, view, ...), respond with a JSON object:
{"has_subcommands": true, "subcommands": ["dict", "faidx", "view", ...]}

List only the subcommand names (lowercase), one per tool. Skip "help" and "version" if they just show help/version.
If the tool does NOT have subcommands, respond: {"has_subcommands": false, "subcommands": []}

Respond with only the JSON object, no other text."""


class LLMProvider(ABC):
    """Abstract base class for LLM providers."""

    @abstractmethod
    async def complete(self, prompt: str, system_prompt: str) -> str:
        """Complete a prompt and return the response."""
        pass


class OpenAIProvider(LLMProvider):
    """OpenAI LLM provider."""

    def __init__(
        self,
        api_key: Optional[str] = None,
        model: str = "gpt-4o",
        base_url: Optional[str] = None,
    ):
        import openai

        self.client = openai.AsyncOpenAI(api_key=api_key, base_url=base_url)
        self.model = model

    async def complete(self, prompt: str, system_prompt: str) -> str:
        response = await self.client.chat.completions.create(
            model=self.model,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": prompt},
            ],
            response_format={"type": "json_object"},
            temperature=0,
        )
        return response.choices[0].message.content or ""


class AnthropicProvider(LLMProvider):
    """Anthropic Claude LLM provider."""

    def __init__(
        self,
        api_key: Optional[str] = None,
        model: str = "claude-sonnet-4-20250514",
    ):
        import anthropic

        self.client = anthropic.AsyncAnthropic(api_key=api_key)
        self.model = model

    async def complete(self, prompt: str, system_prompt: str) -> str:
        response = await self.client.messages.create(
            model=self.model,
            max_tokens=4096,
            system=system_prompt,
            messages=[{"role": "user", "content": prompt}],
        )
        # Extract text from response
        text = ""
        for block in response.content:
            if hasattr(block, "text"):
                text += block.text
        return text


def _mask_key(key: str) -> str:
    """Mask key for debug logging (e.g. AIzaSy...Qs9)."""
    if not key or len(key) < 10:
        return "***"
    return f"{key[:6]}...{key[-3:]}"


def _normalize_api_key(api_key: Optional[str]) -> Optional[str]:
    """Remove first and last character (key stored as 1 + 39-char key + 1). Idempotent: if already 39 chars starting with AIza, return as-is."""
    if not api_key:
        return api_key
    key = api_key.strip()
    if len(key) == 39 and key.startswith("AIza"):
        return key
    if len(key) < 2:
        return key
    return key[1:-1].strip() or key


class GeminiProvider(LLMProvider):
    """Google Gemini LLM provider using langchain-google-genai."""

    def __init__(
        self,
        api_key: Optional[str] = None,
        model: str = "gemini-3-flash-preview",
    ):
        """
        Initialize Gemini provider.

        Args:
            api_key: Google API key. If None, uses GOOGLE_API_KEY env var.
            model: Model name (default: gemini-3-flash-preview)
        """
        from langchain_google_genai import ChatGoogleGenerativeAI

        # Normalize key before feeding to API (and ensure env is set for SDK)
        raw = api_key or os.environ.get("GOOGLE_API_KEY")
        logger.debug("GeminiProvider raw API key before normalize: len=%d, value=%s", len(raw) if raw else 0, raw)
        key = _normalize_api_key(raw) if raw else None
        if key:
            os.environ["GOOGLE_API_KEY"] = key
            logger.debug("GeminiProvider using API key: len=%d %s", len(key), _mask_key(key))
            logger.debug("GeminiProvider API key (full): %s", key)
        else:
            logger.warning("GeminiProvider: no API key (api_key=%s, env=%s)", "set" if api_key else "None", "set" if os.environ.get("GOOGLE_API_KEY") else "unset")

        self.model_name = model
        self.llm = ChatGoogleGenerativeAI(
            model=model,
            google_api_key=key,
            temperature=0,
            convert_system_message_to_human=True,
            # Minimize thinking for faster, lower-latency parse/generate (Gemini 3+).
            thinking_level="low",
        )

    async def complete(self, prompt: str, system_prompt: str) -> str:
        """Complete a prompt using Gemini."""
        from langchain_core.messages import HumanMessage, SystemMessage

        messages = [
            SystemMessage(content=system_prompt),
            HumanMessage(content=prompt),
        ]

        # Use ainvoke for async
        response = await self.llm.ainvoke(messages)
        content = getattr(response, "content", response)
        if isinstance(content, list):
            # Handle list of content parts (common in Gemini 3 or newer LangChain versions)
            parts = []
            for part in content:
                if isinstance(part, dict) and "text" in part:
                    parts.append(part["text"])
                elif isinstance(part, str):
                    parts.append(part)
                else:
                    parts.append(str(part))
            return "".join(parts)
        return str(content)


class HelpTextParser:
    """Parser for CLI help text using LLM-based extraction."""

    def __init__(
        self,
        llm_provider: Optional[LLMProvider] = None,
        use_few_shot: bool = True,
    ):
        """
        Initialize the parser.

        Args:
            llm_provider: LLM provider for text extraction. If None, uses OpenAI.
            use_few_shot: Whether to include few-shot examples in prompts.
        """
        self.llm_provider = llm_provider
        self.use_few_shot = use_few_shot
        self._provider_initialized = False

    def _ensure_provider(self) -> LLMProvider:
        """Ensure LLM provider is initialized."""
        if self.llm_provider is None:
            self.llm_provider = OpenAIProvider()
        return self.llm_provider

    def _build_prompt(self, help_text: str, tool_name: Optional[str] = None) -> str:
        """Build the prompt for LLM extraction."""
        parts = []

        if self.use_few_shot:
            parts.append("Here are examples of how to parse CLI help text:\n")
            for i, example in enumerate(FEW_SHOT_EXAMPLES, 1):
                parts.append(f"Example {i}:")
                parts.append(f"Help text:\n```\n{example['help_text']}\n```")
                parts.append(f"Parsed result:\n```json\n{json.dumps(example['parsed'], indent=2)}\n```\n")

        parts.append("Now parse the following help text:")
        if tool_name:
            parts.append(f"Tool name hint: {tool_name}")
        parts.append(f"```\n{help_text}\n```")
        parts.append("\nReturn the parsed result as a JSON object.")

        return "\n".join(parts)

    async def parse_async(
        self,
        help_text: str,
        tool_name: Optional[str] = None,
    ) -> CLIToolInfo:
        """
        Parse CLI help text asynchronously.

        Args:
            help_text: The help text to parse.
            tool_name: Optional hint for the tool name.

        Returns:
            Parsed CLI tool information.
        """
        provider = self._ensure_provider()
        prompt = self._build_prompt(help_text, tool_name)

        logger.debug("Sending help text to LLM for parsing")
        response = await provider.complete(prompt, SYSTEM_PROMPT)

        # Parse JSON response
        try:
            # Extract JSON from response (handle markdown code blocks)
            json_str = response
            if "```json" in response:
                json_str = response.split("```json")[1].split("```")[0]
            elif "```" in response:
                json_str = response.split("```")[1].split("```")[0]

            parsed = json.loads(json_str)
        except json.JSONDecodeError as e:
            logger.error(f"Failed to parse LLM response as JSON: {e}")
            logger.debug(f"Response was: {response}")
            raise ValueError(f"LLM returned invalid JSON: {e}") from e

        return self._build_tool_info(parsed, help_text)

    def parse(
        self,
        help_text: str,
        tool_name: Optional[str] = None,
    ) -> CLIToolInfo:
        """
        Parse CLI help text synchronously.

        Args:
            help_text: The help text to parse.
            tool_name: Optional hint for the tool name.

        Returns:
            Parsed CLI tool information.
        """
        import asyncio

        return asyncio.run(self.parse_async(help_text, tool_name))

    async def extract_subcommands_async(
        self,
        help_text: str,
        base_command: Optional[str] = None,
    ) -> list[str]:
        """
        Detect subcommands from main help text (e.g. samtools -> dict, faidx, view).

        Tries parsing first; if format suggests subcommands but none parsed, uses LLM.
        """
        subcommands = extract_subcommands_from_help(help_text)
        if subcommands:
            return subcommands
        # Check if help suggests subcommands (Usage: tool <command> or <subcommand>)
        if re.search(r"usage:.*<(?:sub)?command>", help_text, re.IGNORECASE) or re.search(
            r"sub-commands?\s*:?\s*(?:include)?", help_text, re.IGNORECASE
        ) or re.search(
            r"^\s*Commands?\s*:?\s*$", help_text, re.IGNORECASE | re.MULTILINE
        ):
            try:
                provider = self._ensure_provider()
                prompt = f"Does this CLI have subcommands? Extract them from the help.\n\n```\n{help_text[:4000]}\n```"
                response = await provider.complete(prompt, SUBCOMMANDS_LLM_SYSTEM)
                json_str = response
                if "```json" in response:
                    json_str = response.split("```json")[1].split("```")[0]
                elif "```" in response:
                    json_str = response.split("```")[1].split("```")[0]
                data = json.loads(json_str)
                if data.get("has_subcommands") and data.get("subcommands"):
                    return [str(s).strip().lower() for s in data["subcommands"]]
            except Exception as e:
                logger.debug(f"LLM subcommand extraction failed: {e}")
        return []

    def _build_prompt_direct_cwl(self, help_text: str, tool_name: Optional[str] = None) -> str:
        """Build the user prompt for direct CWL generation."""
        parts = [
            "Generate a CWL v1.2 CommandLineTool from the following CLI help text.",
        ]
        if tool_name:
            parts.append(f"Tool name hint: {tool_name}")
        parts.append("Help text:")
        parts.append("```")
        parts.append(help_text.strip())
        parts.append("```")
        parts.append("\nOutput the complete CWL YAML in a ```yaml code block.")
        return "\n".join(parts)

    async def generate_cwl_direct_async(
        self,
        help_text: str,
        tool_name: Optional[str] = None,
    ) -> tuple[str, str]:
        """
        Generate CWL YAML directly from help text using the LLM (single prompt).

        Args:
            help_text: The CLI tool's help text.
            tool_name: Optional hint for the tool name.

        Returns:
            Tuple of (cwl_yaml, tool_name). tool_name is derived from baseCommand if not provided.
        """
        provider = self._ensure_provider()
        prompt = self._build_prompt_direct_cwl(help_text, tool_name)
        system_prompt = _build_direct_cwl_system_prompt(include_skill=True)
        logger.debug("Sending help text to LLM for direct CWL generation (with CWL skill context)")
        response = await provider.complete(prompt, system_prompt)
        cwl_yaml = _extract_yaml_from_response(response)
        # Derive tool name from generated CWL (baseCommand) if we need it later
        derived_name = tool_name or self._derive_tool_name_from_cwl(cwl_yaml)
        return cwl_yaml, derived_name

    def _derive_tool_name_from_cwl(self, cwl_yaml: str) -> str:
        """Extract tool name from CWL YAML (baseCommand) for metadata."""
        try:
            import io

            from ruamel.yaml import YAML

            yaml_loader = YAML()
            data = yaml_loader.load(io.StringIO(cwl_yaml))
            if not data:
                return "unknown"
            bc = data.get("baseCommand")
            if isinstance(bc, list) and bc:
                return str(bc[0])
            if isinstance(bc, str):
                return bc
            return data.get("label") or data.get("id") or "unknown"
        except Exception:
            return "unknown"

    def _build_tool_info(self, parsed: dict[str, Any], original_help: str) -> CLIToolInfo:
        """Build CLIToolInfo from parsed JSON."""
        arguments = []
        for arg_data in parsed.get("arguments", []):
            arg = CLIArgument(
                name=arg_data.get("name", "unknown"),
                arg_type=ArgumentType(arg_data.get("arg_type", "option")),
                short_flag=arg_data.get("short_flag"),
                long_flag=arg_data.get("long_flag"),
                description=arg_data.get("description"),
                value_type=self._map_type(arg_data.get("value_type", "string")),
                is_required=arg_data.get("is_required", False),
                is_array=arg_data.get("is_array", False),
                default_value=arg_data.get("default_value"),
                position=arg_data.get("position"),
                is_output=arg_data.get("is_output", False),
                choices=arg_data.get("choices"),
            )
            arguments.append(arg)

        base_command = parsed.get("base_command", parsed.get("name", "unknown"))

        return CLIToolInfo(
            name=parsed.get("name", "unknown"),
            base_command=base_command,
            description=parsed.get("description"),
            version=parsed.get("version"),
            arguments=arguments,
            subcommand=parsed.get("subcommand"),
            usage_pattern=self._extract_usage(original_help),
        )

    def _map_type(self, type_str: str) -> CWLType:
        """Map string type to CWLType enum."""
        type_map = {
            "boolean": CWLType.BOOLEAN,
            "bool": CWLType.BOOLEAN,
            "string": CWLType.STRING,
            "str": CWLType.STRING,
            "int": CWLType.INT,
            "integer": CWLType.INT,
            "long": CWLType.LONG,
            "float": CWLType.FLOAT,
            "double": CWLType.DOUBLE,
            "file": CWLType.FILE,
            "File": CWLType.FILE,
            "directory": CWLType.DIRECTORY,
            "Directory": CWLType.DIRECTORY,
            "dir": CWLType.DIRECTORY,
        }
        return type_map.get(type_str, CWLType.STRING)

    def _extract_usage(self, help_text: str) -> Optional[str]:
        """Extract usage pattern from help text."""
        lines = help_text.split("\n")
        for line in lines:
            if line.lower().startswith("usage:"):
                return line.strip()
        return None


class RuleBasedParser:
    """
    Rule-based parser for simple cases or as fallback.

    Uses regex patterns to extract common CLI patterns without LLM.
    """

    # Common patterns for CLI arguments
    FLAG_PATTERN = re.compile(
        r"^\s*(-[a-zA-Z]),?\s*(--[\w-]+)?\s*(.*)$"
    )
    LONG_FLAG_PATTERN = re.compile(
        r"^\s*(--[\w-]+)(?:\s*[=\s]\s*(\w+))?\s*(.*)$"
    )
    OPTION_PATTERN = re.compile(
        r"^\s*(-[a-zA-Z]),?\s*(--[\w-]+)?\s*[=\s]?\s*(\w+)?\s*(.*)$"
    )

    def parse(self, help_text: str, tool_name: Optional[str] = None) -> CLIToolInfo:
        """
        Parse help text using rule-based extraction.

        This is a simpler fallback that handles common patterns.
        """
        lines = help_text.split("\n")
        arguments: list[CLIArgument] = []
        description = None

        # Extract usage line
        usage_pattern = None
        for line in lines:
            if line.lower().startswith("usage:"):
                usage_pattern = line.strip()
                break

        # Try to extract tool name from usage
        if not tool_name and usage_pattern:
            match = re.search(r"usage:\s*(\w+)", usage_pattern, re.IGNORECASE)
            if match:
                tool_name = match.group(1)

        # Parse arguments from help text
        for line in lines:
            arg = self._parse_line(line)
            if arg:
                arguments.append(arg)

        return CLIToolInfo(
            name=tool_name or "unknown",
            base_command=tool_name or "unknown",
            description=description,
            arguments=arguments,
            usage_pattern=usage_pattern,
        )

    def _parse_line(self, line: str) -> Optional[CLIArgument]:
        """Parse a single line for argument information."""
        line = line.strip()
        if not line or not line.startswith("-"):
            return None

        # Try to match common patterns
        # Pattern: -x, --long-option VALUE  Description
        match = re.match(
            r"^\s*(-[a-zA-Z])(?:,\s*)?(--[\w-]+)?(?:\s+(\w+))?\s{2,}(.+)?$",
            line,
        )
        if match:
            short_flag, long_flag, value_hint, description = match.groups()
            name = (long_flag or short_flag).lstrip("-").replace("-", "_")

            # Determine if it's a flag or option
            if value_hint:
                arg_type = ArgumentType.OPTION
                value_type = self._infer_type(value_hint)
            else:
                arg_type = ArgumentType.FLAG
                value_type = CWLType.BOOLEAN

            return CLIArgument(
                name=name,
                arg_type=arg_type,
                short_flag=short_flag,
                long_flag=long_flag,
                value_type=value_type,
                description=description.strip() if description else None,
            )

        return None

    def _infer_type(self, hint: str) -> CWLType:
        """Infer CWL type from value hint."""
        hint_upper = hint.upper()
        if hint_upper in ("FILE", "PATH", "FILENAME", "INPUT", "OUTPUT"):
            return CWLType.FILE
        elif hint_upper in ("DIR", "DIRECTORY", "FOLDER"):
            return CWLType.DIRECTORY
        elif hint_upper in ("INT", "NUM", "NUMBER", "COUNT", "N"):
            return CWLType.INT
        elif hint_upper in ("FLOAT", "DECIMAL"):
            return CWLType.FLOAT
        else:
            return CWLType.STRING
