from __future__ import annotations

import logging
import re
from pathlib import Path
from typing import Optional, List, Set, Dict
from urllib.parse import urljoin, urlparse

import httpx

from cwlagent.parser import GeminiProvider
from cwlagent.skill_loader import load_skill

logger = logging.getLogger(__name__)

class SkillGenerator:
    """Generates a specialized skill for a tool using LLM and online documentation."""

    def __init__(self, api_key: Optional[str] = None, model: str = "gemini-3-flash-preview"):
        self.llm = GeminiProvider(api_key=api_key, model=model)

    async def generate_skill(
        self,
        tool_name: str,
        urls: List[str],
        output_dir: Path,
        report_content: Optional[str] = None,
    ) -> bool:
        """
        Generate a skill for the tool by crawling multiple documentation URLs.

        Args:
            tool_name: Name of the tool (e.g. "bedtools").
            urls: List of starting URLs to crawl.
            output_dir: Directory to save the skill to (e.g. tool_dir/skills).
            report_content: Optional content from report.md to use as fallback.

        Returns:
            True if skill was generated, False otherwise.
        """
        output_dir.mkdir(parents=True, exist_ok=True)
        skill_file = output_dir / "SKILL.md"

        pages: Dict[str, str] = {}
        if urls:
            logger.info(f"Crawling documentation from: {', '.join(urls)}")
            pages = await self._fetch_all_docs(urls)
        
        if not pages and report_content:
            logger.info(f"No online documentation found for {tool_name}. Falling back to report.md content.")
            docs_content = report_content
        elif pages:
            self._save_references(output_dir, pages)
            docs_content = "\n\n".join(pages.values())
        else:
            logger.warning(f"No documentation sources available for {tool_name}.")
            return False

        logger.info(f"Generating skill content for {tool_name} (context size: {len(docs_content)} chars)...")
        skill_content = await self._generate_skill_content(tool_name, docs_content)

        if not skill_content or "not generated" in skill_content.lower():
             logger.warning(f"LLM failed to generate a useful skill for {tool_name}.")
             return False

        skill_file.write_text(skill_content, encoding="utf-8")
        logger.info(f"Skill saved to {skill_file}")
        return True

    async def _fetch_all_docs(self, base_urls: List[str]) -> Dict[str, str]:
        """Fetch and crawl multiple base URLs, returning a mapping of URL to content."""
        all_pages = {}
        visited = set()
        
        async with httpx.AsyncClient(follow_redirects=True, timeout=30.0) as client:
            for url in base_urls:
                # For each base URL, we crawl subpages starting with the same prefix
                prefix = url
                if not prefix.endswith('/'):
                    parsed = urlparse(url)
                    path = parsed.path
                    if '.' in path.split('/')[-1]:
                        prefix = urljoin(url, './')
                
                pages = await self._crawl(client, url, prefix, visited, depth=0)
                all_pages.update(pages)
        
        return all_pages

    async def _crawl(self, client: httpx.AsyncClient, url: str, prefix: str, visited: Set[str], depth: int) -> Dict[str, str]:
        """Recursive crawl helper returning Dict[url, content]."""
        if url in visited or depth > 1:
            return {}
        
        visited.add(url)
        logger.info(f"Fetching: {url} (depth {depth})")
        
        results = {}
        try:
            response = await client.get(url)
            if response.status_code != 200:
                return {}
            
            final_url = str(response.url)
            html = response.text
            clean_text = self._clean_html(html)
            
            results[final_url] = clean_text
            
            if depth < 1:
                current_prefix = prefix
                if final_url.startswith(prefix) and final_url != prefix:
                     current_prefix = final_url
                
                links = self._extract_links(html, final_url, current_prefix)
                for link in links:
                    sub_pages = await self._crawl(client, link, current_prefix, visited, depth + 1)
                    results.update(sub_pages)
            
            return results
        except Exception as e:
            logger.warning(f"Error crawling {url}: {e}")
            return {}

    def _clean_html(self, html: str) -> str:
        """Basic HTML text extraction and cleaning."""
        # Remove script and style tags
        text = re.sub(r'<(script|style)[^>]*>.*?</\1>', '', html, flags=re.DOTALL | re.IGNORECASE)
        # Remove comments
        text = re.sub(r'<!--.*?-->', '', text, flags=re.DOTALL)
        # Strip all other tags
        text = re.sub(r'<[^>]+>', ' ', text)
        # Collapse whitespace
        text = re.sub(r'\s+', ' ', text).strip()
        # Limit extraction per page to avoid massive bloat
        return text[:10000]

    def _extract_links(self, html: str, current_url: str, prefix: str) -> List[str]:
        """Extract links that stay within the same documentation prefix."""
        links = re.findall(r'href=["\'](.*?)["\']', html)
        valid_links = []
        
        for link in links:
            # Normalize to absolute URL
            absolute_url = urljoin(current_url, link)
            # Remove fragments
            absolute_url = absolute_url.split('#')[0]
            
            # Check if it starts with the prefix and isn't already visited
            if absolute_url.startswith(prefix):
                # Avoid files that are clearly not documentation (e.g. .zip, .gz)
                if not any(absolute_url.endswith(ext) for ext in ['.zip', '.gz', '.pdf', '.docx']):
                    valid_links.append(absolute_url)
        
        # Return unique links, limited to top 15 subpages to avoid massive crawl
        return list(dict.fromkeys(valid_links))[:15]

    async def _generate_skill_content(self, tool_name: str, docs: str) -> str:
        """Generate SKILL.md content using LLM."""
        
        # Load the skill-creator skill to guide the LLM
        skill_creator_guide = load_skill("skill-creator", include_references=True)
        
        system_prompt = f"""You are an expert AI assistant capable of creating "Skills" for other AI agents.
Your task is to create a specific skill for the tool "{tool_name}".

Follow the guidelines provided in the "Skill Creator" skill below:

{skill_creator_guide}
"""
        
        # Truncate documentation if it's too large for the context window (though Gemini handles a lot)
        # 100k chars is usually plenty and safe.
        doc_context = docs[:100000]
        if len(docs) > 100000:
            doc_context += "... (truncated)"

        prompt = f"""
The user has provided the following documentation content (crawled from {tool_name}'s homepage and subpages):
---
{doc_context}
---

Specific requirements:
1. The skill name should be "{tool_name}".
2. The description should explain *when* to use this skill.
3. The body should provide concise, high-utility instructions for using {tool_name}.
4. Focus solely on tool-specific best practices, common CLI patterns, and expert tips.
5. **CRITICAL**: Do NOT include any CWL (Common Workflow Language) integration guidance or YAML examples. Focus only on the tool's native command line usage.
6. **CRITICAL fallback**: If you determine that the provided documentation and examples are insufficient to create a useful skill (e.g., they contain no actual CLI or functional details), output only: "Skill: not generated"
7. Format the output as a valid Markdown file with YAML frontmatter if generated.
8. Do NOT output markdown code fences around the result; output the raw file content directly.
"""
        # Call the provider's complete method
        response = await self.llm.complete(prompt, system_prompt)
        
        # Strip markdown fences if present
        cleaned = response.strip()
        if cleaned.startswith("```markdown"):
            cleaned = cleaned[11:]
        elif cleaned.startswith("```"):
            cleaned = cleaned[3:]
        if cleaned.endswith("```"):
            cleaned = cleaned[:-3]
            
        return cleaned.strip()

    def _save_references(self, output_dir: Path, pages: Dict[str, str]) -> None:
        """Save the fetched documentation pages as separate files."""
        try:
            ref_dir = output_dir / "references"
            ref_dir.mkdir(parents=True, exist_ok=True)
            
            for url, content in pages.items():
                # Create a filename from the URL
                parsed = urlparse(url)
                name = parsed.path.strip("/").replace("/", "_") or "index.html"
                if not name.endswith(".md"):
                    name += ".md"
                
                ref_file = ref_dir / name
                ref_file.write_text(content, encoding="utf-8")
                logger.debug(f"Saved reference: {ref_file}")
            
            logger.info(f"Saved {len(pages)} reference documentation files to {ref_dir}")
        except Exception as e:
            logger.warning(f"Failed to save reference documentation: {e}")
