"""
Runtime validation of CWL tools with real examples.

Searches for test data (local testdata/ or generated minimal files),
builds a simple job, runs cwltool, and records pass/fail with example and reason.
"""

from __future__ import annotations

import asyncio
import io
import json
import logging
import re
import subprocess
import tempfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

from cwlagent.generator import load_cwl_yaml
from cwlagent.skill_loader import get_cwl_commandlinetool_skill

logger = logging.getLogger(__name__)

# LLM plan strategies for File inputs
PLAN_ANY_FILE = "any_file"
PLAN_FASTA = "fasta"
PLAN_FASTQ = "fastq"
PLAN_BAM = "bam"
PLAN_SAM = "sam"
PLAN_VCF = "vcf"
PLAN_BED = "bed"
PLAN_SKIP = "skip"

# Manifest filename and format keys
TESTDATA_MANIFEST_FILENAME = "manifest.json"
_PACKAGE_TESTDATA_DIR = Path(__file__).resolve().parent / "data" / "testdata"
_TEMPLATES_DIR = _PACKAGE_TESTDATA_DIR / "templates"


def _load_testdata_manifest(testdata_dir: Path) -> Optional[dict[str, Any]]:
    """Load manifest.json from a testdata directory. Returns None if missing or invalid."""
    path = Path(testdata_dir) / TESTDATA_MANIFEST_FILENAME
    if not path.is_file():
        return None
    try:
        data = json.loads(path.read_text())
        if isinstance(data, dict) and "entries" in data:
            return data
        return None
    except Exception:
        return None


def ensure_testdata_manifest(testdata_dir: Path) -> Path:
    """
    Ensure testdata_dir has a manifest and default template files.
    If manifest.json is missing, copy default manifest and templates from package data.
    Returns testdata_dir.
    """
    testdata_dir = Path(testdata_dir).resolve()
    testdata_dir.mkdir(parents=True, exist_ok=True)
    manifest_path = testdata_dir / TESTDATA_MANIFEST_FILENAME
    if manifest_path.is_file():
        return testdata_dir
    default_manifest = _PACKAGE_TESTDATA_DIR / TESTDATA_MANIFEST_FILENAME
    if default_manifest.is_file():
        manifest_path.write_text(default_manifest.read_text())
    if _TEMPLATES_DIR.is_dir():
        for f in _TEMPLATES_DIR.iterdir():
            if f.is_file() and not f.name.startswith("."):
                dest = testdata_dir / f.name
                if not dest.exists():
                    dest.write_bytes(f.read_bytes())
    return testdata_dir


def append_manifest_entry(
    manifest_dir: Path,
    file_path: Path,
    format_key: str,
    description: str,
    source: str = "local",
) -> None:
    """
    Append an entry to testdata/manifest.json so the file is reusable.
    If file_path is outside manifest_dir, copy it in first (store by basename).
    """
    manifest_dir = Path(manifest_dir).resolve()
    manifest_path = manifest_dir / TESTDATA_MANIFEST_FILENAME
    data = _load_testdata_manifest(manifest_dir) if manifest_path.is_file() else {"format": "1.0", "entries": []}
    if "entries" not in data:
        data["entries"] = []
    entries = data["entries"]
    path_resolved = Path(file_path).resolve()
    if not path_resolved.is_file():
        return
    # If file is outside manifest_dir, copy into manifest_dir so it's in the shared folder
    if manifest_dir not in path_resolved.parents and path_resolved.parent != manifest_dir:
        dest = manifest_dir / path_resolved.name
        if not dest.exists() or dest.stat().st_size != path_resolved.stat().st_size:
            import shutil
            shutil.copy2(path_resolved, dest)
        path_resolved = dest
    rel = path_resolved.name if path_resolved.parent == manifest_dir else path_resolved.relative_to(manifest_dir)
    rel_str = str(rel).replace("\\", "/")
    for e in entries:
        if (e.get("path") or "").replace("\\", "/") == rel_str:
            return
    entries.append({
        "path": rel_str,
        "format": format_key,
        "description": description or f"Test data ({source})",
        "source": source,
        "tags": [source],
    })
    manifest_path.parent.mkdir(parents=True, exist_ok=True)
    manifest_path.write_text(json.dumps(data, indent=2))


def _extension_to_format(ext: str) -> str:
    """Map file extension to manifest format key."""
    ext = (ext or "").lower()
    if ext in (".fa", ".fasta"):
        return "fasta"
    if ext in (".fq", ".fastq", ".fq.gz", ".fastq.gz"):
        return "fastq"
    if ext == ".bam":
        return "bam"
    if ext in (".sam",):
        return "sam"
    if ext in (".vcf", ".vcf.gz"):
        return "vcf"
    if ext in (".bed", ".bed.gz"):
        return "bed"
    return "any_file"


def _extract_homepage_from_cwl(cwl_path: Path) -> Optional[str]:
    """Extract project homepage URL from CWL doc or label (e.g. 'Tool homepage: https://...')."""
    try:
        content = cwl_path.read_text()
        data = load_cwl_yaml(content)
        doc = getattr(data, "doc", None) or ""
        if not doc:
            return None
        match = re.search(r"homepage[:\s]+(https?://[^\s\)\]\"]+)", doc, re.I)
        if match:
            return match.group(1).rstrip(".,;")
        match = re.search(r"(https?://[a-zA-Z0-9./?#_-]+)", doc)
        if match:
            return match.group(1).rstrip(".,;")
        return None
    except Exception:
        return None


def _extract_testdata_urls_from_cwl(cwl_path: Path) -> list[str]:
    """
    Return URLs to try for discovering test data: explicit test URL from doc,
    then GitHub repo + /tree/master/test derived from homepage.
    """
    urls: list[str] = []
    try:
        content = cwl_path.read_text()
        data = load_cwl_yaml(content)
        doc = getattr(data, "doc", None) or ""
        if not doc:
            return urls
        # Explicit: "test data: URL", "test: URL", "test data URL: ..."
        for pattern in (
            r"test\s*data\s*[:\s]+\s*(https?://[^\s\)\]\"]+)",
            r"test\s*[:\s]+\s*(https?://[^\s\)\]\"]+)",
            r"test\s*data\s*url\s*[:\s]+\s*(https?://[^\s\)\]\"]+)",
        ):
            match = re.search(pattern, doc, re.I)
            if match:
                u = match.group(1).rstrip(".,;")
                if u not in urls:
                    urls.append(u)
        # Derived: homepage is GitHub repo -> add /tree/master/test
        homepage = _extract_homepage_from_cwl(cwl_path)
        if homepage and "github.com" in homepage:
            # https://github.com/ORG/REPO or .../REPO/
            m = re.search(r"(https?://github\.com/[^/]+/[^/?#]+)", homepage)
            if m:
                base = m.group(1).rstrip("/")
                test_url = f"{base}/tree/master/test"
                if test_url not in urls:
                    urls.append(test_url)
    except Exception:
        pass
    return urls


def _github_blob_to_raw(url: str) -> str:
    """Convert GitHub blob URL to raw.githubusercontent.com URL for direct download."""
    # https://github.com/ORG/REPO/blob/BRANCH/path -> https://raw.githubusercontent.com/ORG/REPO/BRANCH/path
    m = re.search(
        r"https?://github\.com/([^/]+)/([^/]+)/blob/([^/]+)/(.+)",
        url,
        re.I,
    )
    if m:
        org, repo, branch, path = m.groups()
        return f"https://raw.githubusercontent.com/{org}/{repo}/{branch}/{path}"
    return url


def _discover_testdata_from_homepage(
    homepage_url: str,
    format_key: str,
    testdata_dir: Path,
    timeout: int = 15,
    max_size_mb: int = 50,
) -> Optional[tuple[Path, str]]:
    """
    Fetch page, find links to test/sample files by extension, download first match into testdata_dir.
    For GitHub tree pages (e.g. .../tree/master/test), converts blob links to raw for download.
    Adds manifest entry (source=homepage), returns (path, label) or None.
    """
    import urllib.parse
    try:
        import httpx
    except ImportError:
        return None
    ext_map = {
        "fasta": [".fa", ".fasta"],
        "fastq": [".fq", ".fastq"],
        "bam": [".bam"],
        "sam": [".sam"],
        "vcf": [".vcf", ".vcf.gz"],
        "bed": [".bed", ".bed.gz"],
    }
    exts = ext_map.get(format_key, [])
    if not exts:
        return None
    try:
        with httpx.Client(follow_redirects=True, timeout=timeout) as client:
            r = client.get(homepage_url)
            r.raise_for_status()
            html = r.text
    except Exception as e:
        logger.debug("Failed to fetch %s for test data: %s", homepage_url, e)
        return None
    link_re = re.compile(r'href\s*=\s*["\']([^"\']+)["\']', re.I)
    base = urllib.parse.urljoin(homepage_url + "/", ".")
    candidates: list[tuple[str, str]] = []
    for m in link_re.finditer(html):
        href = m.group(1).strip()
        if not href or href.startswith("#") or href.startswith("mailto:"):
            continue
        full_url = urllib.parse.urljoin(base, href)
        lower = href.lower()
        for ext in exts:
            if ext in lower or lower.endswith(ext):
                name = urllib.parse.unquote(Path(href).name or "download" + ext)
                candidates.append((full_url, name))
                break
    if not candidates:
        return None
    testdata_dir = Path(testdata_dir).resolve()
    testdata_dir.mkdir(parents=True, exist_ok=True)
    max_bytes = max_size_mb * 1024 * 1024
    for url, name in candidates[:10]:
        if not name or name.startswith("."):
            name = "download" + (exts[0] if exts else "")
        # GitHub tree pages link to blob; use raw for download
        download_url = _github_blob_to_raw(url) if "github.com" in url and "/blob/" in url else url
        dest = testdata_dir / name
        if dest.exists():
            append_manifest_entry(testdata_dir, dest, format_key, f"From {homepage_url}", "homepage")
            return (dest, f"homepage:{name}")
        try:
            with httpx.Client(follow_redirects=True, timeout=timeout) as client:
                r = client.get(download_url)
                r.raise_for_status()
                if int(r.headers.get("content-length", 0) or 0) > max_bytes:
                    continue
                content = r.content
                if len(content) > max_bytes:
                    continue
                dest.write_bytes(content)
        except Exception as e:
            logger.debug("Failed to download %s: %s", download_url, e)
            continue
        append_manifest_entry(testdata_dir, dest, format_key, f"From {homepage_url}", "homepage")
        return (dest, f"homepage:{name}")
    return None


@dataclass
class RuntimeValidationResult:
    """Result of running a CWL tool with a concrete example."""

    passed: bool
    example_job: Optional[dict[str, Any]] = None
    example_job_path: Optional[Path] = None
    data_used: list[str] = field(default_factory=list)
    fail_reason: Optional[str] = None
    stdout: Optional[str] = None
    stderr: Optional[str] = None
    cwl_path: Optional[Path] = None
    duration_seconds: Optional[float] = None
    fix_rounds: int = 0
    cwl_modified: bool = False

    @property
    def label(self) -> str:
        return "PASS" if self.passed else "FAIL"

    def to_report_dict(self) -> dict[str, Any]:
        return {
            "label": self.label,
            "example_job": self.example_job,
            "example_job_path": str(self.example_job_path) if self.example_job_path else None,
            "data_used": self.data_used,
            "fail_reason": self.fail_reason,
            "stdout_preview": (self.stdout or "")[:500],
            "stderr_preview": (self.stderr or "")[:500] if self.stderr else None,
        }


def _resolve_type_to_primitive(type_spec: Any) -> Optional[str]:
    """Resolve CWL type spec to a primitive: 'File', 'Directory', 'string', etc."""
    if type_spec is None:
        return None
    if isinstance(type_spec, str):
        return type_spec if type_spec != "null" else None
    if isinstance(type_spec, list):
        for t in type_spec:
            if t != "null":
                return _resolve_type_to_primitive(t)
        return None
    if isinstance(type_spec, dict):
        if type_spec.get("type") == "array":
            return _resolve_type_to_primitive(type_spec.get("items"))
        return type_spec.get("type")
    return None


def _is_array_type(type_spec: Any) -> bool:
    """True if the type is array (e.g. array of File)."""
    if type_spec is None:
        return False
    if isinstance(type_spec, list):
        for t in type_spec:
            if t != "null" and _is_array_type(t):
                return True
        return False
    if isinstance(type_spec, dict):
        return type_spec.get("type") == "array"
    return False


def _is_required_input(inp: dict[str, Any]) -> bool:
    """True if input has no default and is not optional (null) type."""
    type_spec = inp.get("type")
    if isinstance(type_spec, list):
        if "null" in type_spec and len(type_spec) == 2:
            return False
    return True


def _infer_file_extensions(input_id: str, doc: Optional[str]) -> list[str]:
    """Infer likely file extensions from input id and doc (e.g. FASTA -> .fa, .fasta)."""
    doc_lower = (doc or "").lower()
    id_lower = input_id.lower()
    exts: list[str] = []

    # From doc
    if "fasta" in doc_lower or "fa " in doc_lower or ".fa" in doc_lower:
        exts.extend([".fa", ".fasta", ".fa.gz"])
    if "fastq" in doc_lower or "fq " in doc_lower or ".fq" in doc_lower:
        exts.extend([".fq", ".fastq", ".fq.gz"])
    if "bam" in doc_lower:
        exts.extend([".bam"])
    if "sam" in doc_lower:
        exts.extend([".sam", ".bam"])
    if "cram" in doc_lower:
        exts.extend([".cram"])
    if "vcf" in doc_lower:
        exts.extend([".vcf", ".vcf.gz"])
    if "bed" in doc_lower:
        exts.extend([".bed", ".bed.gz"])
    if "index" in doc_lower or "dict" in doc_lower:
        exts.extend([".fai", ".dict", ".bai", ".crai"])

    # From id
    if "bam" in id_lower or "alignment" in id_lower:
        exts.extend([".bam"])
    if "fasta" in id_lower or "fa" in id_lower or "reference" in id_lower:
        exts.extend([".fa", ".fasta"])
    if "fastq" in id_lower or "fq" in id_lower:
        exts.extend([".fq", ".fastq"])
    if "vcf" in id_lower:
        exts.extend([".vcf"])

    # Deduplicate preserving order
    seen: set[str] = set()
    out = []
    for e in exts:
        if e not in seen:
            seen.add(e)
            out.append(e)
    return out if out else [".dat"]


class TestDataFinder:
    """
    Find test data for CWL File/Directory inputs.

    Search order:
    1. Local testdata/ or test_data/ next to CWL or in search_dirs
    2. Generated minimal files (FASTA, FASTQ) in generated_dir or a temp dir
    """

    def __init__(
        self,
        cwl_dir: Optional[Path] = None,
        search_dirs: Optional[list[Path]] = None,
        use_generated_minimal: bool = True,
        generated_dir: Optional[Path] = None,
    ):
        self.cwl_dir = Path(cwl_dir) if cwl_dir else None
        self.search_dirs = list(search_dirs or [])
        if self.cwl_dir and self.cwl_dir not in self.search_dirs:
            self.search_dirs.insert(0, self.cwl_dir)
        self.use_generated_minimal = use_generated_minimal
        self._generated_dir: Optional[Path] = None
        self._generated_dir_persist: Optional[Path] = Path(generated_dir).resolve() if generated_dir else None
        self._generated_dir_is_temp: bool = True

    def _testdata_dirs(self) -> list[Path]:
        dirs: list[Path] = []
        seen: set[Path] = set()
        # Project-level data dirs: parent and grandparent of CWL dir (e.g. project/data, project/testdata)
        if self.cwl_dir:
            cwd = Path(self.cwl_dir).resolve()
            for parent in (cwd.parent, cwd.parent.parent):
                if not parent or parent == cwd:
                    continue
                parent = parent.resolve()
                for name in ("testdata", "test_data", "examples", "data"):
                    p = parent / name
                    if p.is_dir() and p not in seen:
                        seen.add(p)
                        dirs.append(p)
                if parent.is_dir() and parent not in seen:
                    seen.add(parent)
                    dirs.append(parent)
        for d in self.search_dirs:
            d = Path(d).resolve()
            for name in ("testdata", "test_data", "examples", "data"):
                p = d / name
                if p.is_dir() and p not in seen:
                    seen.add(p)
                    dirs.append(p)
            if d.is_dir() and d not in seen:
                seen.add(d)
                dirs.append(d)
        return dirs

    def _get_file_by_format_from_manifest(self, format_key: str) -> Optional[tuple[Path, str]]:
        """
        Find a test file by format from manifest.json in any testdata dir.
        format_key: fasta, fastq, bam, sam, vcf, bed, any_file.
        Returns (path, label) or None.
        """
        dirs_to_try = list(self._testdata_dirs())
        if self._generated_dir_persist and self._generated_dir_persist not in dirs_to_try:
            dirs_to_try.insert(0, self._generated_dir_persist)
        for td in dirs_to_try:
            manifest = _load_testdata_manifest(td)
            if not manifest:
                continue
            for entry in manifest.get("entries") or []:
                if (entry.get("format") or "").lower() != format_key.lower():
                    continue
                rel = entry.get("path")
                if not rel:
                    continue
                path = (td / rel).resolve()
                if path.is_file():
                    desc = entry.get("description") or rel
                    return (path, f"manifest:{rel} ({desc})")
        return None

    def _find_file_by_extensions(self, extensions: list[str]) -> Optional[tuple[Path, str]]:
        """Return (path, source_label) for first match in testdata dirs."""
        for td in self._testdata_dirs():
            for ext in extensions:
                for f in td.rglob(f"*{ext}"):
                    if f.is_file() and not f.name.startswith("."):
                        return (f, f"local:{f.relative_to(td)}")
        return None

    def _ensure_generated_dir(self) -> Path:
        if self._generated_dir_persist is not None:
            self._generated_dir = Path(ensure_testdata_manifest(self._generated_dir_persist))
            self._generated_dir_is_temp = False
            return self._generated_dir
        if self._generated_dir is None or not self._generated_dir.exists():
            self._generated_dir = Path(tempfile.mkdtemp(prefix="cwlagent_testdata_"))
            ensure_testdata_manifest(self._generated_dir)
            self._generated_dir_is_temp = True
        return self._generated_dir

    def _generate_minimal_file(self, extensions: list[str]) -> Optional[tuple[Path, str]]:
        """Resolve a test file from manifest (templates in testdata). No hardcoded content."""
        if not self.use_generated_minimal:
            return None
        unsupported = (".bam", ".sam", ".vcf", ".vcf.gz", ".bed", ".bed.gz")
        if extensions and all(ext in unsupported for ext in extensions):
            return None
        base = self._ensure_generated_dir()
        ensure_testdata_manifest(base)
        for ext in extensions:
            if ext in (".fa", ".fasta"):
                found = self._get_file_by_format_from_manifest("fasta")
                if found:
                    return found
                break
            if ext in (".fq", ".fastq", ".fq.gz", ".fastq.gz"):
                found = self._get_file_by_format_from_manifest("fastq")
                if found:
                    return found
                break
        found = self._get_file_by_format_from_manifest("any_file")
        if found:
            return found
        return None

    def get_any_file(self) -> Optional[tuple[Path, str]]:
        """Return a single arbitrary file from manifest (e.g. for md5sum)."""
        base = self._ensure_generated_dir()
        ensure_testdata_manifest(base)
        return self._get_file_by_format_from_manifest("any_file")

    def find_file_for_input(
        self, input_id: str, doc: Optional[str], is_required: bool
    ) -> Optional[tuple[Path, str]]:
        """
        Find or generate a file for this input.
        Returns (path, source_label) or None.
        """
        doc_lower = (doc or "").lower()
        # Tools like md5sum, checksum, cat: "any file" / "files to process"
        if any(
            phrase in doc_lower
            for phrase in (
                "files to process",
                "file to process",
                "any file",
                "any files",
                "input file",
                "file(s) to",
            )
        ) or (doc_lower.strip().startswith("file") and "format" not in doc_lower):
            any_f = self.get_any_file()
            if any_f:
                return any_f
        exts = _infer_file_extensions(input_id, doc)
        found = self._find_file_by_extensions(exts)
        if found:
            return found
        if self.use_generated_minimal:
            return self._generate_minimal_file(exts)
        return None

    def cleanup_generated(self) -> None:
        """Remove generated temp dir if it was temporary (not when using output folder)."""
        if self._generated_dir_is_temp and self._generated_dir and self._generated_dir.exists():
            import shutil
            try:
                shutil.rmtree(self._generated_dir, ignore_errors=True)
            except Exception:
                pass
            self._generated_dir = None


async def _plan_job_with_llm_async(
    cwl_content: str,
    api_key: Optional[str] = None,
    model: str = "gemini-3-flash-preview",
) -> Optional[dict[str, str]]:
    """
    Use LLM to plan a minimal, common example run: which inputs to include only.
    Returns dict mapping input_id -> strategy (e.g. fastq, fasta, any_file).
    Only inputs in the plan are added to the job; all others are omitted.
    """
    try:
        from cwlagent.parser import GeminiProvider

        provider = GeminiProvider(api_key=api_key, model=model)
    except Exception as e:
        logger.debug("LLM planner unavailable: %s", e)
        return None

    inputs = []
    label = ""
    base_command = ""
    try:
        model_obj = load_cwl_yaml(cwl_content)
        label = getattr(model_obj, "label", None) or ""
        base_command = getattr(model_obj, "base_command", None)
        if isinstance(base_command, list):
            base_command = " ".join(base_command)
        else:
            base_command = str(base_command or "")
        for inp in model_obj.inputs:
            prim = _resolve_type_to_primitive(inp.type_)
            required = not (
                isinstance(inp.type_, list) and "null" in inp.type_
            )
            inputs.append({
                "id": inp.id,
                "type": prim or "string",
                "required": required,
                "doc": (getattr(inp, "doc", None) or "")[:200],
            })
    except Exception as e:
        logger.debug("Could not parse CWL for planner: %s", e)
        return None

    if not inputs:
        return None

    system = (
        "You are a CWL run planner. Given a tool and its inputs, decide the MINIMAL set of inputs "
        "needed for the most common, simple example run. Return a JSON object with ONLY the inputs "
        "that should be provided; omit all optional flags and options that are not essential.\n"
        "For File inputs use the EXACT data type the tool expects. Allowed values: fasta, fastq, bam, sam, vcf, bed, any_file.\n"
        "- Use the input id and doc to choose: e.g. input id 'bam' or doc 'Input BAM file' -> use \"bam\" (NOT any_file).\n"
        "- Use fasta for reference/sequence inputs, fastq for read inputs, bam/sam for alignment inputs, vcf/bed when clearly needed.\n"
        "- Use any_file ONLY for tools that accept arbitrary files (e.g. md5sum, checksum, cat).\n"
        "Do NOT include optional boolean flags, optional integers, or optional strings unless necessary.\n"
        "Example: bam-to-fastq tool with input 'bam' -> {\"bam\": \"bam\"}. Example: samtools faidx -> {\"reference\": \"fasta\"}. Example: md5sum -> {\"files\": \"any_file\"}.\n"
        "Reply with only the JSON object, no markdown or explanation."
    )
    prompt = (
        f"Tool: {label or base_command}\n"
        f"Plan a minimal example run. Include ONLY the inputs needed. Use the correct data type for each File input (bam, fasta, fastq, etc.) from its id and doc.\n\n"
        "Inputs:\n"
        + json.dumps(inputs, indent=2)
        + "\n\nReturn JSON with only the input ids to include and their strategy, e.g. {\"bam\": \"bam\"} or {\"reference\": \"fasta\"}:"
    )

    try:
        reply = await provider.complete(prompt, system)
        reply = reply.strip()
        if reply.startswith("```"):
            reply = re.sub(r"^```\w*\n?", "", reply)
            reply = re.sub(r"\n?```\s*$", "", reply)
        plan = json.loads(reply)
        if isinstance(plan, dict):
            return {str(k): str(v).lower() for k, v in plan.items()}
    except Exception as e:
        logger.debug("LLM plan parse failed: %s", e)
    return None


def plan_job_with_llm(
    cwl_content: str,
    api_key: Optional[str] = None,
    model: str = "gemini-3-flash-preview",
) -> Optional[dict[str, str]]:
    """Sync wrapper for _plan_job_with_llm_async."""
    return asyncio.run(_plan_job_with_llm_async(cwl_content, api_key, model))


async def _fix_cwl_with_llm_async(
    cwl_content: str,
    job: dict[str, Any],
    stderr: Optional[str],
    stdout: Optional[str],
    fail_reason: Optional[str],
    api_key: Optional[str],
    model: str = "gemini-3-flash-preview",
) -> Optional[str]:
    """
    Ask LLM to fix the CWL given the run failure. Returns fixed CWL YAML or None.
    """
    try:
        from cwlagent.parser import GeminiProvider

        provider = GeminiProvider(api_key=api_key, model=model)
    except Exception as e:
        logger.debug("LLM fixer unavailable: %s", e)
        return None

    err_snippet = (fail_reason or "")[:1500]
    if stderr:
        err_snippet += "\n\nstderr:\n" + (stderr[:2000] if len(stderr) > 2000 else stderr)
    if stdout:
        err_snippet += "\n\nstdout:\n" + (stdout[:1000] if len(stdout) > 1000 else stdout)

    fix_system_base = (
        "You are a CWL (Common Workflow Language) expert. A CommandLineTool CWL was run with a job and failed. "
        "Your task is to fix the CWL so it runs successfully. Common issues and fixes:\n"
        "(1) outputBinding glob references an input that does not exist (e.g. inputs.output) - use a concrete glob like '*.fai' or '*.out' or capture stdout.\n"
        "(2) Read-only file system / tool writes output next to input (e.g. samtools faidx writes .fai next to .fa): "
        "Use InitialWorkDirRequirement ONLY in that case. Put it first in requirements with listing (e.g. entryname: $(inputs.<input_id>.basename), entry: $(inputs.<input_id>)). "
        "On the input's inputBinding use position and optionally valueFrom: $(self.basename). "
        "Do NOT add a top-level 'arguments' entry with the same position as an input—that would pass the same value twice. "
        "Do NOT add InitialWorkDirRequirement when the tool does not write next to the input; CWL stages File inputs automatically.\n"
        "(3) missing required inputs; (4) wrong types.\n"
        "Return ONLY the complete fixed CWL document as YAML. No markdown fences, no explanation before or after."
    )
    skill_content = get_cwl_commandlinetool_skill(include_references=True)
    if skill_content.strip():
        fix_system_base += (
            "\n\n---\n\nFollow the CWL CommandLineTool skill below for correct structure, inputs/outputs, "
            "inputBinding, and best practices. Do not add redundant arguments or InitialWorkDirRequirement.\n\n"
            + skill_content
        )
    system = fix_system_base
    prompt = (
        "Fix this CWL. It failed when run with the given job.\n\n"
        "Error / stderr / stdout:\n"
        + err_snippet
        + "\n\nJob used:\n"
        + json.dumps(job, indent=2)[:1500]
        + "\n\nCurrent CWL (fix it):\n"
        + cwl_content[:8000]
        + "\n\nReturn the complete fixed CWL YAML only:"
    )

    try:
        reply = await provider.complete(prompt, system)
        reply = reply.strip()
        if reply.startswith("```"):
            reply = re.sub(r"^```\w*\n?", "", reply)
            reply = re.sub(r"\n?```\s*$", "", reply)
        if reply and ("cwlVersion" in reply or "class:" in reply):
            return reply
    except Exception as e:
        logger.debug("LLM fix parse failed: %s", e)
    return None


def fix_cwl_with_llm(
    cwl_content: str,
    job: dict[str, Any],
    stderr: Optional[str],
    stdout: Optional[str],
    fail_reason: Optional[str],
    api_key: Optional[str],
    model: str = "gemini-3-flash-preview",
) -> Optional[str]:
    """Sync wrapper for _fix_cwl_with_llm_async."""
    return asyncio.run(
        _fix_cwl_with_llm_async(
            cwl_content, job, stderr, stdout, fail_reason, api_key, model
        )
    )


def _inputs_from_cwl(cwl_path: Path) -> list[dict[str, Any]]:
    """Parse CWL and return list of input definitions (id, type, doc, default)."""
    try:
        content = cwl_path.read_text()
        model = load_cwl_yaml(content)
    except Exception:
        return []
    inputs = []
    for inp in model.inputs:
        type_ = inp.type_
        prim = _resolve_type_to_primitive(type_)
        doc = getattr(inp, "doc", None) or None
        default = getattr(inp, "default", None)
        required = default is None and not (
            isinstance(type_, list) and "null" in type_
        )
        inputs.append({
            "id": inp.id,
            "type": type_,
            "primitive": prim,
            "is_array": _is_array_type(type_),
            "doc": doc,
            "default": default,
            "required": required,
        })
    return inputs


def _finder_strategy_to_extensions(strategy: str) -> list[str]:
    """Map LLM plan strategy to file extensions for TestDataFinder."""
    s = (strategy or "").lower()
    if s == PLAN_ANY_FILE:
        return [".dat"]
    if s == PLAN_FASTA:
        return [".fa", ".fasta"]
    if s == PLAN_FASTQ:
        return [".fq", ".fastq"]
    if s in (PLAN_BAM, "bam"):
        return [".bam"]
    if s in (PLAN_SAM, "sam"):
        return [".sam", ".bam"]
    if s == PLAN_VCF:
        return [".vcf", ".vcf.gz"]
    if s == PLAN_BED:
        return [".bed", ".bed.gz"]
    return [".dat"]


def _build_job(
    cwl_path: Path,
    finder: TestDataFinder,
    work_dir: Path,
    plan: Optional[dict[str, str]] = None,
) -> tuple[Optional[dict[str, Any]], list[str], Optional[str]]:
    """
    Build a CWL job dict for the tool at cwl_path.
    When plan is provided (from LLM), include ONLY inputs listed in the plan
    (minimal common example run). Otherwise use heuristics and include required + defaults.
    Returns (job, data_used_labels, fail_reason).
    """
    inputs = _inputs_from_cwl(cwl_path)
    if not inputs:
        return None, [], "Could not parse CWL inputs"

    job: dict[str, Any] = {}
    data_used: list[str] = []
    # Inputs the plan says to include (value != skip)
    plan_includes = {
        k for k, v in (plan or {}).items()
        if str(v).lower() != PLAN_SKIP
    }
    use_minimal_plan = bool(plan)

    for inp in inputs:
        input_id = inp["id"]
        prim = inp.get("primitive")
        doc = inp.get("doc")
        default = inp.get("default")
        required = inp.get("required", True)

        # CWL-defined required parameters are always included in the job; plan only filters optional inputs.
        if use_minimal_plan:
            strategy = (plan or {}).get(input_id)
            if strategy == PLAN_SKIP and not required:
                continue
            if input_id not in plan_includes and not required:
                continue
            if required and input_id not in plan_includes and strategy is None:
                # Required but not in plan: still need to provide (e.g. LLM forgot)
                pass

        if prim not in ("File", "Directory"):
            if prim in ("string", "int", "float", "boolean", "long", "double"):
                # Always include required inputs (e.g. output_path); skip optional only when not in plan
                if use_minimal_plan and input_id not in plan_includes and not required:
                    continue
                if default is not None:
                    job[input_id] = default
                elif prim == "string" and not required:
                    continue
                elif prim == "int":
                    job[input_id] = 1
                elif prim == "boolean":
                    job[input_id] = False
                elif prim == "string":
                    job[input_id] = "example"
            continue

        if prim == "Directory":
            if not required:
                continue
            return None, [], "Directory input required; no test directory provided"

        # File: resolve from plan or heuristic (manifest first, then scan, then generate from templates)
        strategy = (plan or {}).get(input_id) if plan else None
        if strategy == PLAN_SKIP and not required:
            continue
        format_key = (strategy or "").lower() if strategy else None
        if format_key == PLAN_ANY_FILE:
            found = finder._get_file_by_format_from_manifest("any_file") or finder.get_any_file()
        elif format_key and format_key in (
            PLAN_FASTA, PLAN_FASTQ, PLAN_BAM, PLAN_SAM, PLAN_VCF, PLAN_BED,
            "bam", "sam",
        ):
            found = finder._get_file_by_format_from_manifest(format_key)
            if not found:
                exts = _finder_strategy_to_extensions(strategy)
                found = finder._find_file_by_extensions(exts)
            if not found and finder.use_generated_minimal:
                exts = _finder_strategy_to_extensions(strategy)
                found = finder._generate_minimal_file(exts)
            # Try homepage then project test-data URL(s) when still missing (e.g. BAM from repo test/)
            if not found:
                testdata_dir = finder._ensure_generated_dir()
                candidate_urls: list[str] = []
                homepage_url = _extract_homepage_from_cwl(cwl_path)
                if homepage_url:
                    candidate_urls.append(homepage_url)
                for u in _extract_testdata_urls_from_cwl(cwl_path):
                    if u not in candidate_urls:
                        candidate_urls.append(u)
                for url in candidate_urls:
                    found = _discover_testdata_from_homepage(
                        url, format_key, testdata_dir
                    )
                    if found:
                        break
        else:
            found = finder.find_file_for_input(input_id, doc, required)

        if not found:
            if required:
                strategy_hint = (plan or {}).get(input_id, "")
                if strategy_hint in ("bam", "sam"):
                    return (
                        None,
                        [],
                        f"Missing .{strategy_hint}: add file to testdata/, list in manifest.json, re-run.",
                    )
                return None, [], f"Data not available for required input '{input_id}'"
            continue
        path, label = found
        path = path.resolve()
        # Annotate for reuse: register locally-found or homepage-downloaded files in manifest
        if label.startswith("local:"):
            manifest_dir = None
            for td in finder._testdata_dirs():
                try:
                    if path.is_relative_to(td) or td in path.parents:
                        manifest_dir = td
                        break
                except ValueError:
                    continue
            if manifest_dir is None:
                manifest_dir = finder._ensure_generated_dir()
            fmt = format_key if format_key else _extension_to_format(path.suffix)
            append_manifest_entry(
                manifest_dir, path, fmt, "Found in project", "local"
            )
        file_binding = {"class": "File", "path": str(path)}
        if inp.get("is_array"):
            job[input_id] = [file_binding]
        else:
            job[input_id] = file_binding
        data_used.append(label)

    return job, data_used, None


def _cwl_has_docker_requirement(cwl_path: Path) -> bool:
    """True if the CWL has DockerRequirement in requirements or hints (so it expects container)."""
    try:
        content = cwl_path.read_text()
        if "dockerPull" not in content and "DockerRequirement" not in content:
            return False
        data = load_cwl_yaml(content)
        if not hasattr(data, "requirements") and not hasattr(data, "hints"):
            return False
        for key in ("requirements", "hints"):
            reqs = getattr(data, key, None) or []
            for req in reqs:
                cls = getattr(req, "class_", None) or (req.get("class") if isinstance(req, dict) else None)
                if cls == "DockerRequirement":
                    return True
                if isinstance(req, dict) and "dockerPull" in req:
                    return True
        return False
    except Exception:
        return False


# Patterns that indicate the container/runner could not find the baseCommand executable
_EXEC_NOT_FOUND_PATTERNS = (
    re.compile(r"exec:\s*\S+:\s*not found", re.I),
    re.compile(r"not found", re.I),
    re.compile(r"command not found", re.I),
    re.compile(r"no such file or directory", re.I),
)


def _is_executable_not_found(stderr: str, stdout: str = "") -> bool:
    """True if stderr/stdout indicate the baseCommand executable was not found (e.g. in container)."""
    combined = (stderr or "") + "\n" + (stdout or "")
    return any(p.search(combined) for p in _EXEC_NOT_FOUND_PATTERNS)


def _get_base_command_from_cwl(cwl_path: Path) -> Optional[Any]:
    """Return the raw baseCommand from the CWL (str or list). None if missing or parse error."""
    try:
        content = cwl_path.read_text()
        data = load_cwl_yaml(content)
        bc = getattr(data, "base_command", None)
        if bc is None:
            return None
        return bc
    except Exception:
        return None


def _get_label_from_cwl(cwl_path: Path) -> Optional[str]:
    """Return the CWL label (tool name) if set. Used as alternative baseCommand when executable not found."""
    try:
        content = cwl_path.read_text()
        data = load_cwl_yaml(content)
        label = getattr(data, "label", None)
        return str(label).strip() if label else None
    except Exception:
        return None


def _alternative_base_commands(current: str, label: Optional[str] = None) -> list[str]:
    """
    Suggest alternative baseCommand values: strip package-style prefixes from current,
    and include CWL label when it differs (e.g. baseCommand 'cartesian' vs label '2pg_cartesian').
    """
    candidates: list[str] = []
    if current and "_" in current:
        after_first = current.split("_", 1)[-1]
        if after_first and after_first != current:
            candidates.append(after_first)
        if "_" in after_first:
            after_last = current.rsplit("_", 1)[-1]
            if after_last and after_last != current and after_last not in candidates:
                candidates.append(after_last)
    if label and label != current and label not in candidates:
        candidates.append(label)
    return candidates


def _write_cwl_with_base(cwl_path: Path, new_base: str | list[str], out_path: Path) -> bool:
    """Write a copy of the CWL with baseCommand set to new_base. Returns True on success."""
    try:
        from ruamel.yaml import YAML

        content = cwl_path.read_text()
        yaml = YAML()
        data = yaml.load(io.StringIO(content))
        if data is None:
            return False
        data["baseCommand"] = new_base
        out_path.parent.mkdir(parents=True, exist_ok=True)
        with out_path.open("w") as f:
            yaml.dump(data, f)
        return True
    except Exception as e:
        logger.warning("Failed to write CWL with baseCommand %s: %s", new_base, e)
        return False


def _patch_cwl_base_command(cwl_path: Path, new_base: str | list[str]) -> bool:
    """Update baseCommand in the CWL file to new_base. Returns True on success."""
    try:
        from ruamel.yaml import YAML

        content = cwl_path.read_text()
        yaml = YAML()
        data = yaml.load(io.StringIO(content))
        if data is None:
            return False
        data["baseCommand"] = new_base
        buf = io.StringIO()
        yaml.dump(data, buf)
        cwl_path.write_text(buf.getvalue())
        return True
    except Exception as e:
        logger.warning("Failed to patch CWL baseCommand: %s", e)
        return False


class RuntimeValidator:
    """
    Validate CWL tools by running them with a simple example job.
    """

    def __init__(
        self,
        cwltool_path: str = "cwltool",
        timeout: int = 120,
        use_container: bool = True,
        leave_container: bool = False,
        use_singularity: bool = False,
    ):
        self.cwltool_path = cwltool_path
        self.timeout = timeout
        self.use_container = use_container
        self.leave_container = leave_container
        self.use_singularity = use_singularity

    def run(
        self,
        cwl_path: Path,
        work_dir: Optional[Path] = None,
        testdata_dirs: Optional[list[Path]] = None,
        out_dir: Optional[Path] = None,
        plan: Optional[dict[str, str]] = None,
        testdata_out_dir: Optional[Path] = None,
    ) -> RuntimeValidationResult:
        """
        Run the CWL tool with a generated or found example job.

        Args:
            cwl_path: Path to the .cwl file
            work_dir: Working directory for run (default: same dir as CWL)
            testdata_dirs: Extra dirs to search for test data
            out_dir: If set, write example job JSON here
            testdata_out_dir: If set, keep generated test data (minimal.fa, etc.) here

        Returns:
            RuntimeValidationResult with pass/fail, example, data_used, fail_reason
        """
        cwl_path = Path(cwl_path).resolve()
        if not cwl_path.exists():
            return RuntimeValidationResult(
                passed=False,
                fail_reason="CWL file not found",
                cwl_path=cwl_path,
            )

        work_dir = work_dir or cwl_path.parent
        work_dir = Path(work_dir).resolve()
        search_dirs = [work_dir]
        if testdata_dirs:
            search_dirs.extend(Path(d).resolve() for d in testdata_dirs)
        # Prioritize shared testdata folder so we reuse generated files across tools
        if testdata_out_dir:
            shared = Path(testdata_out_dir).resolve()
            if shared not in search_dirs:
                search_dirs.insert(0, shared)

        finder = TestDataFinder(
            cwl_dir=cwl_path.parent,
            search_dirs=search_dirs,
            use_generated_minimal=True,
            generated_dir=Path(testdata_out_dir) if testdata_out_dir else None,
        )

        job, data_used, fail_reason = _build_job(cwl_path, finder, work_dir, plan)
        if fail_reason or job is None:
            return RuntimeValidationResult(
                passed=False,
                data_used=data_used,
                fail_reason=fail_reason or "Could not build job",
                cwl_path=cwl_path,
            )

        # Write job to temp or out_dir
        import time
        t0 = time.perf_counter()
        job_path = None
        if out_dir:
            out_dir = Path(out_dir)
            out_dir.mkdir(parents=True, exist_ok=True)
            job_path = out_dir / f"{cwl_path.stem}_job.json"
            job_path.write_text(json.dumps(job, indent=2))

        with tempfile.NamedTemporaryFile(
            mode="w", suffix=".json", delete=False
        ) as f:
            f.write(json.dumps(job))
            tmp_job = Path(f.name)

        try:
            cmd = [self.cwltool_path]
            # If CWL has DockerRequirement, use container so the tool runs as intended
            use_container_effective = self.use_container or _cwl_has_docker_requirement(cwl_path)
            if not use_container_effective:
                cmd.append("--no-container")
            if use_container_effective and self.leave_container:
                cmd.append("--leave-container")
            if use_container_effective and self.use_singularity:
                cmd.append("--singularity")
            cmd.extend([str(cwl_path), str(tmp_job)])

            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=self.timeout,
                cwd=str(work_dir),
            )
            duration = time.perf_counter() - t0
            passed = result.returncode == 0

            # When baseCommand is not found in container, do not auto-patch: report failure.
            # The image may not provide this executable; CWL generation/validation should fail.

            if not passed and not result.stderr and result.stdout:
                fail_reason = result.stdout[:200].strip() or f"Exit code {result.returncode}"
            elif not passed and _is_executable_not_found(result.stderr or "", result.stdout or ""):
                bc = _get_base_command_from_cwl(cwl_path)
                current = bc if isinstance(bc, str) else (bc[0] if (isinstance(bc, list) and bc) else "?")
                err_snippet = (result.stderr or result.stdout or "").strip()[:120]
                fail_reason = (
                    f"baseCommand '{current}' not found in container; the image may not provide this executable. "
                    f"CWL generation/validation failed. Original error: {err_snippet}"
                )
            elif not passed:
                fail_reason = (result.stderr or result.stdout or "").strip().split("\n")[-1][:200]
                if not fail_reason:
                    fail_reason = f"Exit code {result.returncode}"

            return RuntimeValidationResult(
                passed=passed,
                example_job=job,
                example_job_path=job_path,
                data_used=data_used,
                fail_reason=None if passed else fail_reason,
                stdout=result.stdout,
                stderr=result.stderr,
                cwl_path=cwl_path,
                duration_seconds=round(duration, 2),
            )
        except subprocess.TimeoutExpired:
            return RuntimeValidationResult(
                passed=False,
                example_job=job,
                data_used=data_used,
                fail_reason=f"Execution timed out after {self.timeout}s",
                cwl_path=cwl_path,
            )
        except FileNotFoundError:
            return RuntimeValidationResult(
                passed=False,
                example_job=job,
                data_used=data_used,
                fail_reason=f"cwltool not found: {self.cwltool_path}",
                cwl_path=cwl_path,
            )
        except Exception as e:
            return RuntimeValidationResult(
                passed=False,
                example_job=job,
                data_used=data_used,
                fail_reason=str(e)[:200],
                cwl_path=cwl_path,
            )
        finally:
            if tmp_job.exists():
                try:
                    tmp_job.unlink()
                except Exception:
                    pass


def run_with_fix_loop(
    validator: RuntimeValidator,
    cwl_path: Path,
    plan: Optional[dict[str, str]] = None,
    work_dir: Optional[Path] = None,
    testdata_dirs: Optional[list[Path]] = None,
    out_dir: Optional[Path] = None,
    testdata_out_dir: Optional[Path] = None,
    api_key: Optional[str] = None,
    model: str = "gemini-3-flash-preview",
    max_rounds: int = 5,
) -> RuntimeValidationResult:
    """
    Run the CWL tool; on failure use LLM to fix the CWL and re-run, up to max_rounds.
    Returns the last result, with fix_rounds and cwl_modified set.
    """
    cwl_path = Path(cwl_path).resolve()
    last: Optional[RuntimeValidationResult] = None
    fixes_applied = 0

    for round_num in range(1, max_rounds + 1):
        result = validator.run(
            cwl_path,
            work_dir=work_dir,
            testdata_dirs=testdata_dirs,
            out_dir=out_dir,
            plan=plan,
            testdata_out_dir=testdata_out_dir,
        )
        last = result

        if result.passed:
            if fixes_applied > 0:
                last = RuntimeValidationResult(
                    passed=result.passed,
                    example_job=result.example_job,
                    example_job_path=result.example_job_path,
                    data_used=result.data_used,
                    fail_reason=result.fail_reason,
                    stdout=result.stdout,
                    stderr=result.stderr,
                    cwl_path=result.cwl_path,
                    duration_seconds=result.duration_seconds,
                    fix_rounds=fixes_applied,
                    cwl_modified=True,
                )
            return last

        if not api_key or round_num >= max_rounds:
            if fixes_applied > 0:
                last = RuntimeValidationResult(
                    passed=result.passed,
                    example_job=result.example_job,
                    example_job_path=result.example_job_path,
                    data_used=result.data_used,
                    fail_reason=result.fail_reason,
                    stdout=result.stdout,
                    stderr=result.stderr,
                    cwl_path=result.cwl_path,
                    duration_seconds=result.duration_seconds,
                    fix_rounds=fixes_applied,
                    cwl_modified=True,
                )
            return last

        fixed = fix_cwl_with_llm(
            cwl_path.read_text(),
            job=result.example_job or {},
            stderr=result.stderr,
            stdout=result.stdout,
            fail_reason=result.fail_reason,
            api_key=api_key,
            model=model,
        )
        if not fixed:
            logger.debug("LLM returned no fix for %s after round %s", cwl_path.name, round_num)
            return last

        cwl_path.write_text(fixed)
        fixes_applied += 1
        logger.info("Applied LLM fix to %s (round %s), re-running", cwl_path.name, round_num)

    return last or RuntimeValidationResult(
        passed=False,
        fail_reason="Max fix rounds reached",
        cwl_path=cwl_path,
        fix_rounds=fixes_applied,
        cwl_modified=fixes_applied > 0,
    )


def validate_cwl_directory(
    cwl_dir: Path,
    cwltool_path: str = "cwltool",
    timeout: int = 120,
    use_container: bool = True,
    out_dir: Optional[Path] = None,
    testdata_dir: Optional[Path] = None,
    api_key: Optional[str] = None,
    use_llm: bool = True,
    model: str = "gemini-3-flash-preview",
    keep_docker_image: bool = False,
    use_singularity: bool = False,
) -> dict[str, RuntimeValidationResult]:
    """
    Run runtime validation on every .cwl file in a directory.
    When use_llm is True and api_key is set, uses LLM to plan test data per input.
    Test data is generated into and reused from a shared folder (testdata_dir or out_dir/testdata).
    When keep_docker_image is True, pass --leave-container to cwltool so the container is not removed.
    Returns dict mapping tool name (stem) -> RuntimeValidationResult.
    """
    cwl_dir = Path(cwl_dir)
    if not cwl_dir.is_dir():
        return {}
    validator = RuntimeValidator(
        cwltool_path=cwltool_path,
        timeout=timeout,
        use_container=use_container,
        leave_container=keep_docker_image,
        use_singularity=use_singularity,
    )
    results: dict[str, RuntimeValidationResult] = {}
    job_out = Path(out_dir or cwl_dir)
    testdata_out = Path(testdata_dir).resolve() if testdata_dir else (job_out / "testdata")
    ensure_testdata_manifest(testdata_out)
    for cwl_file in sorted(cwl_dir.glob("*.cwl")):
        name = cwl_file.stem
        plan = None
        if use_llm and api_key:
            try:
                plan = plan_job_with_llm(
                    cwl_file.read_text(),
                    api_key=api_key,
                    model=model,
                )
                if plan:
                    logger.debug("LLM plan for %s: %s", name, plan)
            except Exception as e:
                logger.debug("LLM plan failed for %s: %s", name, e)

        if use_llm and api_key:
            results[name] = run_with_fix_loop(
                validator,
                cwl_file,
                plan=plan,
                work_dir=cwl_dir,
                out_dir=job_out,
                testdata_out_dir=testdata_out,
                api_key=api_key,
                model=model,
                max_rounds=5,
            )
        else:
            results[name] = validator.run(
                cwl_file,
                work_dir=cwl_dir,
                out_dir=job_out,
                plan=plan,
                testdata_out_dir=testdata_out,
            )
    return results
