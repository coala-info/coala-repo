"""
CWL document validator using cwltool.

This module provides validation of generated CWL documents using
the official cwltool reference implementation.
"""

from __future__ import annotations

import logging
import subprocess
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)


@dataclass
class ValidationResult:
    """Result of CWL validation."""

    is_valid: bool
    errors: list[str]
    warnings: list[str]
    cwl_path: Optional[Path] = None

    @property
    def error_summary(self) -> str:
        """Get a summary of all errors."""
        if not self.errors:
            return "No errors"
        return "\n".join(self.errors)

    @property
    def has_warnings(self) -> bool:
        """Check if there are any warnings."""
        return len(self.warnings) > 0


class CWLValidator:
    """
    Validator for CWL documents using cwltool.

    Uses the cwltool --validate command to check CWL documents.
    """

    def __init__(
        self,
        cwltool_path: str = "cwltool",
        strict: bool = True,
        enable_dev: bool = False,
    ):
        """
        Initialize the validator.

        Args:
            cwltool_path: Path to cwltool executable
            strict: Whether to use strict validation
            enable_dev: Whether to enable dev mode in cwltool
        """
        self.cwltool_path = cwltool_path
        self.strict = strict
        self.enable_dev = enable_dev

    def validate(self, cwl_yaml: str) -> ValidationResult:
        """
        Validate a CWL document.

        Args:
            cwl_yaml: CWL document as YAML string

        Returns:
            ValidationResult with status and any errors/warnings
        """
        # Write to temp file
        with tempfile.NamedTemporaryFile(
            mode="w", suffix=".cwl", delete=False
        ) as f:
            f.write(cwl_yaml)
            temp_path = Path(f.name)

        try:
            result = self.validate_file(temp_path)
            result.cwl_path = temp_path
            return result
        finally:
            # Clean up temp file on success
            if temp_path.exists():
                try:
                    temp_path.unlink()
                except Exception:
                    pass

    def validate_file(self, cwl_path: Path) -> ValidationResult:
        """
        Validate a CWL file.

        Args:
            cwl_path: Path to CWL file

        Returns:
            ValidationResult with status and any errors/warnings
        """
        cmd = [self.cwltool_path, "--validate"]

        if not self.strict:
            cmd.append("--non-strict")
        if self.enable_dev:
            cmd.append("--enable-dev")

        cmd.append(str(cwl_path))

        logger.debug(f"Running validation: {' '.join(cmd)}")

        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=30,
            )

            errors = []
            warnings = []

            # Parse output for errors and warnings
            for line in result.stderr.split("\n"):
                line = line.strip()
                if not line:
                    continue
                if "ERROR" in line or "error" in line.lower():
                    errors.append(line)
                elif "WARNING" in line or "warning" in line.lower():
                    warnings.append(line)

            # Also check stdout for errors
            for line in result.stdout.split("\n"):
                line = line.strip()
                if not line:
                    continue
                if "ERROR" in line:
                    errors.append(line)
                elif "WARNING" in line:
                    warnings.append(line)

            is_valid = result.returncode == 0

            # If return code is non-zero but no errors captured, add generic error
            if not is_valid and not errors:
                errors.append(f"Validation failed with return code {result.returncode}")
                if result.stderr:
                    errors.append(result.stderr)
                if result.stdout:
                    errors.append(result.stdout)

            return ValidationResult(
                is_valid=is_valid,
                errors=errors,
                warnings=warnings,
                cwl_path=cwl_path,
            )

        except subprocess.TimeoutExpired:
            return ValidationResult(
                is_valid=False,
                errors=["Validation timed out after 30 seconds"],
                warnings=[],
                cwl_path=cwl_path,
            )
        except FileNotFoundError:
            return ValidationResult(
                is_valid=False,
                errors=[f"cwltool not found at {self.cwltool_path}"],
                warnings=[],
                cwl_path=cwl_path,
            )
        except Exception as e:
            return ValidationResult(
                is_valid=False,
                errors=[f"Validation error: {str(e)}"],
                warnings=[],
                cwl_path=cwl_path,
            )

    def check_cwltool_available(self) -> bool:
        """Check if cwltool is available."""
        try:
            result = subprocess.run(
                [self.cwltool_path, "--version"],
                capture_output=True,
                text=True,
                timeout=10,
            )
            return result.returncode == 0
        except Exception:
            return False

    def get_cwltool_version(self) -> Optional[str]:
        """Get the version of cwltool."""
        try:
            result = subprocess.run(
                [self.cwltool_path, "--version"],
                capture_output=True,
                text=True,
                timeout=10,
            )
            if result.returncode == 0:
                return result.stdout.strip() or result.stderr.strip()
        except Exception:
            pass
        return None


class SchemaValidator:
    """
    Schema-based validator for CWL documents.

    Uses cwl-utils for schema validation without running cwltool.
    """

    def __init__(self) -> None:
        """Initialize the schema validator."""
        self._schema = None

    def validate(self, cwl_yaml: str) -> ValidationResult:
        """
        Validate CWL document against schema.

        Args:
            cwl_yaml: CWL document as YAML string

        Returns:
            ValidationResult
        """
        try:
            from ruamel.yaml import YAML

            yaml = YAML()
            data = yaml.load(cwl_yaml)

            # Basic structure validation
            errors = []
            warnings = []

            # Check required fields
            if "cwlVersion" not in data:
                errors.append("Missing required field: cwlVersion")
            if "class" not in data:
                errors.append("Missing required field: class")
            if data.get("class") == "CommandLineTool":
                if "baseCommand" not in data:
                    errors.append("Missing required field: baseCommand")
                if "inputs" not in data:
                    warnings.append("Missing inputs field (will be empty)")
                if "outputs" not in data:
                    warnings.append("Missing outputs field (will be empty)")

            # Validate cwlVersion
            valid_versions = ["v1.0", "v1.1", "v1.2", "draft-2", "draft-3"]
            if data.get("cwlVersion") not in valid_versions:
                warnings.append(
                    f"Unknown cwlVersion: {data.get('cwlVersion')}. "
                    f"Expected one of: {valid_versions}"
                )

            # Validate inputs structure
            inputs = data.get("inputs", [])
            if isinstance(inputs, list):
                for i, inp in enumerate(inputs):
                    if isinstance(inp, dict):
                        if "id" not in inp and "type" not in inp:
                            errors.append(f"Input {i}: missing 'id' or 'type'")
            elif isinstance(inputs, dict):
                # Map format is valid
                pass
            else:
                errors.append(f"Invalid inputs format: expected list or dict")

            # Validate outputs structure
            outputs = data.get("outputs", [])
            if isinstance(outputs, list):
                for i, out in enumerate(outputs):
                    if isinstance(out, dict):
                        if "id" not in out and "type" not in out:
                            errors.append(f"Output {i}: missing 'id' or 'type'")
            elif isinstance(outputs, dict):
                # Map format is valid
                pass
            else:
                errors.append(f"Invalid outputs format: expected list or dict")

            return ValidationResult(
                is_valid=len(errors) == 0,
                errors=errors,
                warnings=warnings,
            )

        except Exception as e:
            return ValidationResult(
                is_valid=False,
                errors=[f"Schema validation error: {str(e)}"],
                warnings=[],
            )
