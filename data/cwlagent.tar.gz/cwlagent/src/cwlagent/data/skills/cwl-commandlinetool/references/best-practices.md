# CWL best practices (summary)

- **File/Directory types**: Use `type: File` or `type: Directory` for input/reference files; avoid `type: string` for file/directory paths.
- **Licensing**: Add a license (e.g. SPDX identifier in metadata). Prefer existing licenses (e.g. Apache-2.0).
- **Attribution**: Include author/attribution (e.g. ORCID) in metadata.
- **Dependencies**: List under **SoftwareRequirement**; include version(s) known to work; use SciCrunch RRID where applicable.
- **Naming**: Use clear input/output ids (e.g. `reference_genome`, `aligned_sequences`) instead of generic names like `input`, `output`, `foo_file`.
- **Formats**: Specify **format** for input/output Files. Use EDAM for bioinformatics; IANA media types (e.g. `iana:text/plain`) where appropriate.
- **Streaming**: Mark streamable inputs/outputs with `streamable: true` when read/written once in a streaming way.
- **Single operation**: One CommandLineTool per operation; don't pack every subcommand into one tool.
- **Custom types**: Define in separate YAML for reuse.
- **Label and doc**: Use top-level **label** (short) and **doc** (longer) for discovery and documentation.
- **Enums**: Use `type: enum` with **symbols** instead of free-form string when values are fixed.
- **JavaScript**: Prefer built-in File properties and parameter references over custom JavaScript; add InlineJavascriptRequirement only when needed.
- **Testing**: Have someone else run the tool (e.g. different institution) and iterate on feedback.
- **Containers**: Follow recommendations for packaging/containerizing bioinformatics software when using DockerRequirement.
