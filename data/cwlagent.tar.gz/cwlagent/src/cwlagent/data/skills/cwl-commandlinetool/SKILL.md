---
name: cwl-commandlinetool
description: Write and fix Common Workflow Language (CWL) CommandLineTool descriptions. Use when creating or editing .cwl files that wrap command-line tools (baseCommand, inputs, outputs), when a tool needs a config file as input or a customized script with parameters at runtime, when debugging cwltool runs, when handling read-only input staging or sidecar outputs, or when applying CWL best practices. Covers inputs/outputs, inputBinding, expressions, InitialWorkDirRequirement for staging and for creating files at runtime (configs, scripts), and the CWL User Guide patterns.
---

# CWL CommandLineTool

Write portable CWL CommandLineTool wrappers for CLI tools. Run with `cwltool <tool.cwl> [job.json]`.

## Quick start

Minimal CommandLineTool: `class: CommandLineTool`, `baseCommand`, `inputs`, `outputs`. Inputs and outputs are required.

```yaml
cwlVersion: v1.2
class: CommandLineTool
baseCommand: echo
inputs:
  message:
    type: string
    default: "Hello World"
    inputBinding:
      position: 1
outputs: []
```

Job file (JSON or YAML) supplies input values. Run: `cwltool tool.cwl` (uses defaults) or `cwltool tool.cwl job.json`.

## Core structure

- **baseCommand**: string or array (e.g. `[tar, --extract]`). First element is the executable; rest are fixed args.
- **inputs**: Map of id → parameter (type, optional `inputBinding`). Omit `inputBinding` if the input must not appear on the command line. Do not include `--help`, `-h`, or `--version` as inputs; they are meta-options for display only.
- **outputs**: Map of id → parameter (type, `outputBinding` with `glob` or `type: stdout`). Results must be produced under the run's output directory.

Use **arguments** for non-input args (e.g. `["-d", $(runtime.outdir)]`). See [references/expressions-runtime.md](references/expressions-runtime.md).

## Input binding

- **position**: Order on command line (relative; need not be sequential).
- **prefix**: Optional flag/option before the value (e.g. `--file=`, `-f`). Omit for positional args.
- **separate**: If `false`, prefix and value are one argv (e.g. `-i42`, `--file=/path`).
- **type** and binding: `boolean` → flag (prefix only when true). `string`/`int`/`float` → value. `File` → path. Optional: use `?` (e.g. `File?`).

Prefer `type: File` or `type: Directory` for input/reference files; avoid `type: string` for file paths. See [references/inputs-outputs.md](references/inputs-outputs.md) for arrays, records, and optional/required.

## Outputs

- **glob**: Pattern for files in the output directory (e.g. `"*.class"`, `$(inputs.extractfile)`). Use **stdout**: `stdout: output.txt` and `type: stdout` to capture stdout.
- **outputEval**: For transforming content (e.g. `$(self[0].contents)`). See [references/inputs-outputs.md](references/inputs-outputs.md).

## Read-only inputs and sidecar outputs

If the tool writes next to the input (e.g. `.fai` beside a FASTA), the runner may stage inputs read-only and the tool will fail. Use **InitialWorkDirRequirement** to put a writable copy in the job directory:

1. Add `InitialWorkDirRequirement` (list it first in `requirements`).
2. In `listing`, add a Dirent that copies the input into the work dir (e.g. copy by reference or content).
3. Bind the main file input with `position` and no `valueFrom`, so the runner passes the path to the staged copy.

See [references/staging-files.md](references/staging-files.md) for exact patterns (staging vs creating files at runtime).

## Creating config files or scripts at runtime

When a tool expects a **config file** as input (rather than CLI flags), or when you need a **custom wrapper script** that takes parameters: use **InitialWorkDirRequirement** to create that file at runtime. In **listing**, add a Dirent with **entryname** (e.g. `config.yaml`, `run.sh`) and **entry** (inline content). CWL expands `$(inputs.x)` in the content; escape literal `$` as `\$` so shell variables in generated scripts are preserved. Set **baseCommand** to run the tool with the generated config, or to execute the generated script. See [references/staging-files.md](references/staging-files.md) and [CWL User Guide: Creating Files at Runtime](https://www.commonwl.org/user_guide/topics/creating-files-at-runtime.html).

## Requirements and hints

- **NetworkAccess**: If the process needs network: `requirements: { NetworkAccess: { networkAccess: true } }`. Default in v1.1+ is no network.
- **DockerRequirement**: Under `hints:` (or `requirements:`) for container image (e.g. `dockerPull: image:tag`).
- **InlineJavascriptRequirement**: Required when using `$(...)` expressions that are JavaScript (e.g. `valueFrom`, `glob` with expressions). Prefer built-in File properties over JS when possible.

## When to load references

- **inputs-outputs**: Array inputs, record/union types, optional vs required, `outputBinding` details, `format`, `secondaryFiles`.
- **expressions-runtime**: Parameter refs `$(inputs.x)`, `$(runtime.outdir)`, `valueFrom`, InlineJavascriptRequirement, expressionLib, where expressions are allowed.
- **staging-files**: InitialWorkDirRequirement for staging input files into the output dir and for creating files at runtime (config files or customized scripts with parameters).
- **best-practices**: Naming, licensing, formats, single-operation focus, avoiding unnecessary JavaScript.

## Testing

- Generate a job template: `cwltool --make-template tool.cwl`.
- Run: `cwltool tool.cwl job.json`. Use `--no-container` to run without Docker when the tool doesn't require it.

Source: [CWL User Guide](https://www.commonwl.org/user_guide/) (Quick Start, Command Line Tool, Inputs, Outputs, Expressions, Staging, Best Practices).
