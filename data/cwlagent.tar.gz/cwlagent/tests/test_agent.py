"""
Tests for CWL Agent components.
"""

from __future__ import annotations

import pytest

# Test data
MD5SUM_HELP = """Usage: md5sum [OPTION]... [FILE]...
Print or check MD5 (128-bit) checksums.

With no FILE, or when FILE is -, read standard input.

  -b, --binary         read in binary mode
  -c, --check          read MD5 sums from the FILEs and check them
      --tag            create a BSD-style checksum
  -t, --text           read in text mode (default)
  -z, --zero           end each output line with NUL, not newline,
                         and disable file name escaping

The following five options are useful only when verifying checksums:
      --ignore-missing  don't fail or report status for missing files
      --quiet          don't print OK for each successfully verified file
      --status         don't output anything, status code shows success
      --strict         exit non-zero for improperly formatted checksum lines
  -w, --warn           warn about improperly formatted checksum lines

      --help     display this help and exit
      --version  output version information and exit

The sums are computed as described in RFC 1321.  When checking, the input
should be a former output of this program.  The default mode is to print a
line with: checksum, a space, a character indicating input mode ('*' for
binary, ' ' for text or where binary is insignificant), and name for each
FILE.

GNU coreutils online help: <https://www.gnu.org/software/coreutils/>
Report any translation bugs to <https://translationproject.org/team/>
Full documentation <https://www.gnu.org/software/coreutils/md5sum>
or available locally via: info '(coreutils) md5sum invocation'
"""


class TestModels:
    """Test Pydantic models."""

    def test_cli_argument_cwl_id(self):
        """Test CLIArgument.cwl_id property."""
        from cwlagent.models import ArgumentType, CLIArgument, CWLType

        arg = CLIArgument(
            name="input-file",
            arg_type=ArgumentType.OPTION,
            value_type=CWLType.FILE,
        )
        assert arg.cwl_id == "input_file"

    def test_cwl_command_line_tool_to_yaml_dict(self):
        """Test CWLCommandLineTool serialization."""
        from cwlagent.models import CWLCommandLineTool, CWLInputParameter

        tool = CWLCommandLineTool(
            base_command="echo",
            inputs=[
                CWLInputParameter(id="message", type_="string")
            ],
            outputs=[],
            label="Echo Tool",
        )

        data = tool.to_yaml_dict()
        assert data["cwlVersion"] == "v1.2"
        assert data["class"] == "CommandLineTool"
        assert data["baseCommand"] == "echo"
        assert len(data["inputs"]) == 1


class TestValidator:
    """Test CWL validation."""

    def test_schema_validator_valid_cwl(self):
        """Test schema validation with valid CWL."""
        from cwlagent.validator import SchemaValidator

        cwl_yaml = """
cwlVersion: v1.2
class: CommandLineTool
baseCommand: echo
inputs:
  - id: message
    type: string
outputs: []
"""
        validator = SchemaValidator()
        result = validator.validate(cwl_yaml)

        assert result.is_valid
        assert len(result.errors) == 0

    def test_schema_validator_missing_version(self):
        """Test schema validation catches missing cwlVersion."""
        from cwlagent.validator import SchemaValidator

        cwl_yaml = """
class: CommandLineTool
baseCommand: echo
inputs: []
outputs: []
"""
        validator = SchemaValidator()
        result = validator.validate(cwl_yaml)

        assert not result.is_valid
        assert any("cwlVersion" in e for e in result.errors)


class TestGenerator:
    """Test CWL generation."""

    def test_generate_simple_tool(self):
        """Test generating CWL for a simple tool."""
        from cwlagent.generator import CWLGenerator
        from cwlagent.models import ArgumentType, CLIArgument, CLIToolInfo, CWLType

        tool_info = CLIToolInfo(
            name="echo",
            base_command="echo",
            description="Print a message",
            arguments=[
                CLIArgument(
                    name="message",
                    arg_type=ArgumentType.POSITIONAL,
                    position=1,
                    value_type=CWLType.STRING,
                    is_required=True,
                    description="Message to print",
                )
            ],
        )

        generator = CWLGenerator()
        cwl = generator.generate(tool_info)

        assert cwl.base_command == "echo"
        assert len(cwl.inputs) == 1
        assert cwl.inputs[0].id == "message"

    def test_generate_yaml_output(self):
        """Test YAML output generation."""
        from cwlagent.generator import CWLGenerator
        from cwlagent.models import CLIToolInfo

        tool_info = CLIToolInfo(
            name="test",
            base_command="test",
            arguments=[],
        )

        generator = CWLGenerator()
        yaml_output = generator.generate_yaml(tool_info)

        assert "cwlVersion: v1.2" in yaml_output
        assert "class: CommandLineTool" in yaml_output

    def test_load_cwl_yaml_map_form(self):
        """load_cwl_yaml accepts map-form inputs/outputs (LLM-style) and normalizes to list."""
        from cwlagent.generator import load_cwl_yaml

        cwl_map_form = """
cwlVersion: v1.2
class: CommandLineTool
baseCommand: md5sum
inputs:
  binary:
    type: boolean
    inputBinding:
      prefix: -b
      separate: false
  file:
    type: File
    inputBinding:
      position: 1
outputs:
  checksum_output:
    type: stdout
"""
        tool = load_cwl_yaml(cwl_map_form)
        assert tool.base_command == "md5sum"
        assert len(tool.inputs) == 2
        ids = [inp.id for inp in tool.inputs]
        assert "binary" in ids
        assert "file" in ids
        assert len(tool.outputs) == 1
        assert tool.outputs[0].id == "checksum_output"


class TestBioContainersSearch:
    """Test BioContainers search functionality."""

    @pytest.mark.asyncio
    async def test_search_known_tool(self):
        """Test searching for a known tool."""
        from cwlagent.agent import BioContainersSearch

        search = BioContainersSearch(timeout=10.0)
        result = await search.search("samtools")

        # Should find samtools (TRS or Quay when network available)
        if result:
            assert "biocontainers" in result or "samtools" in result

    @pytest.mark.asyncio
    async def test_search_md5sum_returns_ubuntu_fallback(self):
        """md5sum has no BioContainers image; fallback is ubuntu:latest."""
        from cwlagent.agent import BioContainersSearch

        search = BioContainersSearch(timeout=5.0)
        result = await search.search("md5sum")
        assert result == "ubuntu:latest"


class TestToolHomepageSearch:
    """Test tool homepage search functionality."""

    @pytest.mark.asyncio
    async def test_search_known_tool(self):
        """Test searching for known tools."""
        from cwlagent.agent import ToolHomepageSearch

        search = ToolHomepageSearch()

        # Test md5sum (coreutils)
        result = await search.search("md5sum")
        assert result is not None
        assert "gnu.org" in result


class TestSkillLoader:
    """Test CWL CommandLineTool skill loading for LLM context."""

    def test_get_cwl_commandlinetool_skill_returns_non_empty_when_bundled(self):
        """When package data is present, skill content is non-empty."""
        from cwlagent.skill_loader import get_cwl_commandlinetool_skill

        content = get_cwl_commandlinetool_skill(include_references=False)
        # May be empty if CWLAGENT_SKILLS_DIR not set and package not installed with data
        if content:
            assert "CommandLineTool" in content
            assert "cwlVersion" in content or "baseCommand" in content

    def test_get_cwl_commandlinetool_skill_with_references_includes_refs_when_present(self):
        """With include_references=True, reference docs are appended when present."""
        from cwlagent.skill_loader import get_cwl_commandlinetool_skill

        content = get_cwl_commandlinetool_skill(include_references=True)
        if content:
            assert "CommandLineTool" in content or "CWL" in content

    def test_build_direct_cwl_system_prompt_includes_skill_when_available(self):
        """Direct CWL system prompt includes skill section when skill loads."""
        from cwlagent.parser import _build_direct_cwl_system_prompt

        prompt = _build_direct_cwl_system_prompt(include_skill=True)
        assert "CWL" in prompt
        assert "CommandLineTool" in prompt
        # If skill loaded, we have the "Follow the CWL CommandLineTool skill" line
        if "Follow the CWL CommandLineTool skill" in prompt:
            assert "inputBinding" in prompt or "inputs" in prompt


# Integration test (requires API key)
@pytest.mark.skipif(
    True,  # Skip by default - requires GOOGLE_API_KEY
    reason="Integration test requires GOOGLE_API_KEY",
)
class TestCWLAgentIntegration:
    """Integration tests for CWLAgent."""

    def test_generate_from_help_text(self):
        """Test full generation workflow."""
        from cwlagent.agent import CWLAgent

        agent = CWLAgent(use_docker=False, run_demo=False)
        result = agent.generate(MD5SUM_HELP, "md5sum")

        assert result.tool_name == "md5sum"
        assert result.cwl_yaml is not None
        assert "cwlVersion: v1.2" in result.cwl_yaml
        assert result.validation_passed
