# Test data for CWL runtime validation

The `manifest.json` in this directory (or in your project’s `testdata/` folder) lists test files used by `cwlagent validate-run`.

## Manifest format

- **format**: Schema version (e.g. `"1.0"`).
- **entries**: List of objects with:
  - **path**: File path relative to the manifest directory (e.g. `minimal.fa`, `sample.bam`).
  - **format**: One of `fasta`, `fastq`, `bam`, `sam`, `vcf`, `bed`, `any_file`.
  - **description**: Short description (optional).
  - **tags**: Optional list of tags (e.g. `["minimal"]`).

## Adding your own data

1. Put the file in the same directory as `manifest.json` (e.g. `testdata/sample.bam`).
2. Add an entry to `manifest.json`:
   ```json
   {
     "path": "sample.bam",
     "format": "bam",
     "description": "Small BAM for 10x bamtofastq",
     "tags": []
   }
   ```
3. Re-run `cwlagent validate-run <cwl_dir>`. Tools that need that format will use your file.

The default manifest is created from package templates when a testdata directory has no manifest. You can edit the copied `manifest.json` to add or change entries.
