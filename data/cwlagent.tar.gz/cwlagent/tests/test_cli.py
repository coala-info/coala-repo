"""
Tests for CLI.
"""
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
from typer.testing import CliRunner

from cwlagent.cli import app
from cwlagent.agent import AgentResult
from cwlagent.models import CWLCommandLineTool

runner = CliRunner()

@pytest.fixture
def mock_agent_result():
    cwl_model = CWLCommandLineTool(base_command="test", inputs=[], outputs=[])
    return AgentResult(
        tool_name="test_tool",
        help_text="Original Help",
        cwl_yaml="cwlVersion: v1.2\nclass: CommandLineTool\nbaseCommand: test\n",
        cwl_model=cwl_model,
        validation_result=None,
        validation_passed=True,
        docker_image="quay.io/biocontainers/test",
        tool_homepage="http://example.com",
        tool_description="A test tool",
        demo_executed=False
    )

def test_generate_output_structure(tmp_path, mock_agent_result):
    """Test that generate command creates folder and files."""
    
    with patch("cwlagent.agent.CWLAgent.generate", return_value=mock_agent_result), \
         patch("cwlagent.agent.CWLAgent.get_help_text", return_value="Help"):
        
        # We need to mock the API key check or provide one
        # The CLI checks for api_key arg or env var.
        # We can pass --api-key dummy
        
        # Run command in tmp_path
        # We want the output folder to be created in tmp_path
        
        output_arg = tmp_path / "my_tool_folder"
        
        result = runner.invoke(app, [
            "generate", 
            "test_cmd", 
            "--api-key", "dummy", 
            "-o", str(output_arg)
        ])
        
        assert result.exit_code == 0
        
        # Check folder exists
        assert output_arg.exists()
        assert output_arg.is_dir()
        
        # Check files
        cwl_file = output_arg / "test_tool.cwl"
        assert cwl_file.exists()
        assert "cwlVersion: v1.2" in cwl_file.read_text()
        
        report_file = output_arg / "report.md"
        assert report_file.exists()
        content = report_file.read_text()
        assert "# test_tool Report" in content
        assert "Original Help Text" in content
        assert "Original Help" in content # From mock_agent_result.help_text

def test_generate_default_output(tmp_path, mock_agent_result):
    """Test default output directory (tool name)."""
    
    # We run from tmp_path to isolate output
    import os
    cwd = os.getcwd()
    os.chdir(tmp_path)
    
    try:
        with patch("cwlagent.agent.CWLAgent.generate", return_value=mock_agent_result), \
             patch("cwlagent.agent.CWLAgent.get_help_text", return_value="Help"):
            
            result = runner.invoke(app, [
                "generate", 
                "test_cmd", 
                "--api-key", "dummy"
            ])
            
            assert result.exit_code == 0
            
            output_dir = tmp_path / "test_tool"
            assert output_dir.exists()
            assert (output_dir / "test_tool.cwl").exists()
            assert (output_dir / "report.md").exists()
            
    finally:
        os.chdir(cwd)
