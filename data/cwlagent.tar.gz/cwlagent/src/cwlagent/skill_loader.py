"""
Load CWL CommandLineTool skill content for LLM context.

Loads skills/cwl-commandlinetool/SKILL.md (and optional reference docs) so the
LLM can follow CWL best practices when generating CommandLineTool documents.
Supports progressive disclosure: load main SKILL only, or SKILL + references.

See: https://docs.langchain.com/oss/python/langchain/multi-agent/skills
"""

from __future__ import annotations

import logging
import os
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)

# Skill name and reference files (without .md) to load when include_references=True
CWL_COMMANDLINETOOL_SKILL = "cwl-commandlinetool"
REFERENCE_FILES = [
    "inputs-outputs",
    "expressions-runtime",
    "staging-files",
    "best-practices",
]


def _skills_root() -> Optional[Path]:
    """Resolve skills root: CWLAGENT_SKILLS_DIR/skills or package-bundled data."""
    env_dir = os.getenv("CWLAGENT_SKILLS_DIR")
    if env_dir:
        root = Path(env_dir).resolve() / "skills"
        if root.is_dir():
            return root
        logger.debug("CWLAGENT_SKILLS_DIR %s has no skills/ subdir", env_dir)
    # Package-bundled: cwlagent/data/skills
    try:
        from importlib.resources import files

        pkg = files("cwlagent")
        bundled = pkg / "data" / "skills"
        path = Path(str(bundled))
        if path.is_dir():
            return path
    except Exception as e:
        logger.debug("Could not resolve bundled skills: %s", e)
    return None


def load_skill(
    skill_name: str = CWL_COMMANDLINETOOL_SKILL,
    include_references: bool = True,
) -> str:
    """
    Load skill content for the given skill name.

    Used to inject CWL CommandLineTool guidance into the LLM system prompt
    (progressive disclosure: the skill text is the "specialized prompt" the
    model follows when generating CWL).

    Args:
        skill_name: Name of the skill directory (e.g. "cwl-commandlinetool").
        include_references: If True, append reference .md files from
            skill's references/ subdir (inputs-outputs, expressions-runtime,
            staging-files, best-practices).

    Returns:
        Combined markdown content (SKILL.md + optional references). Empty string
        if the skill cannot be found.
    """
    root = _skills_root()
    if not root:
        logger.warning("No skills root found; CWL skill context will be empty")
        return ""

    skill_dir = root / skill_name
    if not skill_dir.is_dir():
        logger.warning("Skill directory not found: %s", skill_dir)
        return ""

    parts: list[str] = []

    # Main SKILL.md
    skill_md = skill_dir / "SKILL.md"
    if skill_md.is_file():
        parts.append(skill_md.read_text(encoding="utf-8"))
    else:
        logger.warning("SKILL.md not found in %s", skill_dir)
        return ""

    if not include_references:
        return parts[0].strip()

    ref_dir = skill_dir / "references"
    for ref_name in REFERENCE_FILES:
        ref_path = ref_dir / f"{ref_name}.md"
        if ref_path.is_file():
            parts.append(f"\n\n---\n\n# {ref_name}\n\n")
            parts.append(ref_path.read_text(encoding="utf-8"))

    return "\n".join(p).strip() if (p := parts) else ""


def get_cwl_commandlinetool_skill(
    include_references: bool = True,
) -> str:
    """
    Load the CWL CommandLineTool skill content for use in LLM prompts.

    Call this when building the system prompt for CWL generation (e.g. direct
    help-text → CWL YAML) so the model follows the skill's structure and
    best practices.

    Args:
        include_references: If True, include reference docs (inputs-outputs,
            expressions-runtime, staging-files, best-practices).

    Returns:
        Full skill markdown, or empty string if not found.
    """
    return load_skill(
        skill_name=CWL_COMMANDLINETOOL_SKILL,
        include_references=include_references,
    )
