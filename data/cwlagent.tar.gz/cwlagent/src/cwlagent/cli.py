"""
CLI interface for CWL Agent.

Provides a command-line interface for generating CWL from CLI help text.
"""

from __future__ import annotations

import json
import logging
import os
import sys
from pathlib import Path
from typing import Optional

import typer
import asyncio
import re
from dotenv import load_dotenv

# Load .env so GOOGLE_API_KEY (and other vars) are available to envvar options
load_dotenv()

# Normalize GOOGLE_API_KEY in env as soon as .env is loaded (SDK and typer read env)
def _normalize_api_key(api_key: Optional[str]) -> Optional[str]:
    """Remove first and last character (key stored as 1 + 39-char key + 1). Idempotent: if already 39 chars starting with AIza, return as-is."""
    if not api_key:
        return api_key
    key = api_key.strip()
    if len(key) == 39 and key.startswith("AIza"):
        return key
    if len(key) < 2:
        return key
    return key[1:-1].strip() or key

_env_key = os.environ.get("GOOGLE_API_KEY")
if _env_key:
    _normalized = _normalize_api_key(_env_key)
    if _normalized:
        os.environ["GOOGLE_API_KEY"] = _normalized
    del _normalized
del _env_key

def update_report_metadata(report_path: Path, key: str, value: str) -> None:
    """Update or add a metadata entry in report.md."""
    if not report_path.exists():
        return
    
    content = report_path.read_text(encoding="utf-8")
    lines = content.splitlines()
    
    # Find Metadata section
    start_idx = -1
    for i, line in enumerate(lines):
        if line.strip().lower() == "## metadata":
            start_idx = i
            break
    
    if start_idx == -1:
        # Create metadata section if not exists
        lines.append("\n## Metadata")
        lines.append(f"- **{key}**: {value}")
    else:
        # Check if key exists in the current list
        found = False
        meta_end_idx = len(lines)
        for j in range(start_idx + 1, len(lines)):
            if lines[j].startswith("##") or (j > start_idx + 1 and not lines[j].strip()):
                meta_end_idx = j
                break
            if f"**{key}**:" in lines[j]:
                lines[j] = re.sub(rf"- \*\*{key}\*\*: .*", f"- **{key}**: {value}", lines[j])
                found = True
                break
        
        if not found:
            # Insert before the end of the metadata list or next section
            lines.insert(meta_end_idx, f"- **{key}**: {value}")

    report_path.write_text("\n".join(lines) + "\n", encoding="utf-8")

from rich.console import Console
from rich.panel import Panel
from rich.syntax import Syntax
from rich.table import Table

from cwlagent import __version__

app = typer.Typer(
    name="cwlagent",
    help="AI-powered CWL CommandLineTool generator from CLI help text.",
    add_completion=False,
)

console = Console()


def setup_logging(verbose: bool = False) -> None:
    """Setup logging configuration."""
    level = logging.DEBUG if verbose else logging.INFO
    logging.basicConfig(
        level=level,
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        handlers=[logging.StreamHandler()],
    )


def version_callback(value: bool) -> None:
    """Print version and exit."""
    if value:
        console.print(f"cwlagent version {__version__}")
        raise typer.Exit()


@app.callback()
def main(
    version: Optional[bool] = typer.Option(
        None,
        "--version",
        "-v",
        help="Show version and exit.",
        callback=version_callback,
        is_eager=True,
    ),
) -> None:
    """
    CWL Agent - AI-powered CWL CommandLineTool generator from CLI help text.
    """
    pass


@app.command()
def generate(
    command: Optional[str] = typer.Argument(
        None,
        help="Command to generate CWL for (e.g., 'md5sum', 'samtools view'). "
        "If not provided, reads help text from stdin.",
    ),
    output: Optional[Path] = typer.Option(
        None,
        "-o",
        "--output",
        help="Output directory path. If not specified, uses tool name.",
    ),
    api_key: Optional[str] = typer.Option(
        None,
        "--api-key",
        envvar="GOOGLE_API_KEY",
        help="Google API key for Gemini. Set GOOGLE_API_KEY in .env or environment.",
    ),
    model: str = typer.Option(
        "gemini-3-flash-preview",
        "--model",
        "-m",
        help="Gemini model to use.",
    ),
    no_docker: bool = typer.Option(
        False,
        "--no-docker",
        help="Skip searching for Docker images from BioContainers.",
    ),
    docker_image: Optional[str] = typer.Option(
        None,
        "--docker-image",
        help="Use this Docker image for all tools (skip BioContainers search). E.g. ubuntu:latest for linux_tools.txt.",
    ),
    keep_docker_image: bool = typer.Option(
        False,
        "--keep-docker-image",
        help="Do not remove the Docker image after generation (keeps image for faster validate-run).",
    ),
    run_demo: bool = typer.Option(
        False,
        "--run-demo",
        help="Run a demo execution of the generated CWL (if possible).",
    ),
    use_singularity: bool = typer.Option(
        False,
        "--singularity",
        help="Use Singularity instead of Docker.",
    ),
    method: str = typer.Option(
        "structured",
        "--method",
        "-M",
        help="Generation method: 'structured' (parse help to JSON then generate CWL) "
        "or 'direct' (single LLM prompt from help text to CWL).",
    ),
    json_output: bool = typer.Option(
        False,
        "--json",
        help="Output full result as JSON instead of just CWL YAML.",
    ),
    verbose: bool = typer.Option(
        False,
        "-v",
        "--verbose",
        help="Enable verbose logging.",
    ),
    version: bool = typer.Option(
        False,
        "--version",
        callback=version_callback,
        is_eager=True,
        help="Show version and exit.",
    ),
) -> None:
    """
    Generate CWL CommandLineTool from CLI help text.

    Examples:
        # Generate from a command
        cwlagent generate md5sum

        # Generate from a command with subcommand
        cwlagent generate "samtools view"

        # Read help text from stdin
        md5sum --help | cwlagent generate

        # Save to file
        cwlagent generate md5sum -o md5sum.cwl

        # Output as JSON with all metadata
        cwlagent generate md5sum --json

        # Generate CWL in one LLM step (direct method)
        cwlagent generate md5sum --method direct

        # Use ubuntu:latest (e.g. for tools from linux_tools.txt)
        cwlagent generate md5sum --docker-image ubuntu:latest
    """
    setup_logging(verbose)

    api_key = _normalize_api_key(api_key)
    if api_key:
        os.environ["GOOGLE_API_KEY"] = api_key  # SDK may read env; use normalized key

    from cwlagent.agent import CWLAgent

    # When command is provided, the agent will get help from Docker (if use_docker) or local;
    # do not fetch help locally here, so tools like bedtools work via Docker when not installed.
    if command:
        console.print(f"[bold blue]Generating CWL for:[/] {command}")
        help_text = None
        tool_name = command.split()[0]
    else:
        # Read from stdin
        if sys.stdin.isatty():
            console.print(
                "[bold yellow]No command provided. Reading help text from stdin...[/]"
            )
            console.print("Paste the help text and press Ctrl+D when done:")
        help_text = sys.stdin.read()
        tool_name = None

        if not help_text.strip():
            console.print("[bold red]Error:[/] No help text provided.")
            raise typer.Exit(code=1)

    # Check API key
    if not api_key:
        console.print(
            "[bold red]Error:[/] Google API key is required. "
            "Set GOOGLE_API_KEY in .env, or in the environment, or use --api-key."
        )
        raise typer.Exit(code=1)

    # Validate method
    if method not in ("structured", "direct"):
        console.print(
            f"[bold red]Error:[/] --method must be 'structured' or 'direct', got {method!r}"
        )
        raise typer.Exit(code=1)

    # Create agent and generate (with subcommand detection when command is provided)
    try:
        with console.status("[bold green]Generating CWL...") as status:
            agent = CWLAgent(
                api_key=api_key,
                model=model,
                use_docker=not no_docker,
                run_demo=run_demo,
                generation_method=method,
                remove_docker_after_use=not keep_docker_image,
                use_singularity=use_singularity,
            )

            if command:
                status.update("[bold green]Detecting subcommands and generating CWL...")
                results = agent.generate_multi(command, default_docker_image=docker_image)
            else:
                status.update(
                    "[bold green]Parsing help text with Gemini..."
                    if method == "structured"
                    else "[bold green]Generating CWL directly from help text..."
                )
                results = [agent.generate(help_text, tool_name)]

    except Exception as e:
        console.print(f"[bold red]Error during generation:[/] {e}")
        if verbose:
            import traceback
            console.print(traceback.format_exc())
        raise typer.Exit(code=1)

    if not results:
        console.print("[bold red]No CWL generated.[/]")
        raise typer.Exit(code=1)

    # Display results
    if json_output:
        output_data = json.dumps(
            [r.to_dict() for r in results] if len(results) != 1 else results[0].to_dict(),
            indent=2,
        )
        if output:
            Path(output).write_text(output_data)
            console.print(f"[bold green]Saved JSON to:[/] {output}")
        else:
            console.print(output_data)
        return

    # Standard output with folder structure
    base_name = command.split()[0] if command else results[0].tool_name
    if output:
        output_dir = Path(output)
    else:
        output_dir = Path(base_name)

    try:
        if not output_dir.exists():
            output_dir.mkdir(parents=True)
    except Exception as e:
        console.print(f"[bold red]Error creating directory {output_dir}:[/] {e}")
        raise typer.Exit(code=1)

    report_sections: list[str] = []
    for result in results:
        failed = getattr(result, "generation_failed", False)
        if not failed:
            cwl_file = output_dir / f"{result.tool_name}.cwl"
            cwl_file.write_text(result.cwl_yaml)
            console.print(f"[bold green]Saved CWL to:[/] {cwl_file}")
        else:
            console.print(f"[bold red]Generation FAIL:[/] {result.tool_name} — {getattr(result, 'fail_reason', '')[:80]}...")

        report_sections.append(f"""## {result.tool_name}

### Tool Description
{result.tool_description or "N/A"}

### Metadata
- **Docker Image**: {result.docker_image or "Not found"}
- **Homepage**: {result.tool_homepage or "Not found"}
- **Validation**: {"FAIL (generation failed)" if failed else "PASS" if result.validation_passed else "FAIL"}
""")
        if failed and getattr(result, "fail_reason", None):
            report_sections.append(f"### Generation Failed\n\n{result.fail_reason}\n\n")
        if not result.validation_passed and result.validation_result:
            report_sections.append("### Validation Errors\n")
            for error in result.validation_result.errors:
                report_sections.append(f"- {error}\n")
            report_sections.append("\n")
        trunc = "..." if len(result.help_text) > 2000 else ""
        report_sections.append(f"### Original Help Text\n```text\n{result.help_text[:2000]}{trunc}\n```\n\n")

    report_content = f"# {base_name} CWL Generation Report\n\n" + "\n".join(report_sections)
    report_file = output_dir / "report.md"
    report_file.write_text(report_content)
    console.print(f"[bold green]Saved Report to:[/] {report_file}")

    # Display summary (first result or multi-line)
    if len(results) == 1:
        _display_summary(results[0])
    else:
        _display_summary_multi(results)


def _display_summary(result) -> None:
    """Display a summary table of the result."""
    table = Table(title="Generation Summary", show_header=True)
    table.add_column("Property", style="cyan")
    table.add_column("Value", style="white")

    table.add_row("Tool Name", result.tool_name)
    table.add_row("Description", result.tool_description or "N/A")
    table.add_row("Docker Image", result.docker_image or "Not found")
    table.add_row("Homepage", result.tool_homepage or "Not found")

    # Validation / generation status
    failed = getattr(result, "generation_failed", False)
    validation_style = "red" if failed or not result.validation_passed else "green"
    validation_label = "FAIL (generation failed)" if failed else result.labels.get("validation", "")
    table.add_row(
        "Validation",
        f"[{validation_style}]{validation_label}[/{validation_style}]",
    )

    # Demo status if run
    if result.demo_executed:
        demo_style = "green" if result.demo_passed else "red"
        demo_label = result.labels.get("demo", "")
        table.add_row(
            "Demo Execution",
            f"[{demo_style}]{demo_label}[/{demo_style}]",
        )

    console.print(table)

    # Show validation errors if any
    if not result.validation_passed and result.validation_result:
        console.print("\n[bold red]Validation Errors:[/]")
        for error in result.validation_result.errors:
            console.print(f"  • {error}")

    # Show warnings if any
    if result.validation_result and result.validation_result.warnings:
        console.print("\n[bold yellow]Validation Warnings:[/]")
        for warning in result.validation_result.warnings:
            console.print(f"  • {warning}")


def _strip_ansi(s: str) -> str:
    """Remove ANSI escape sequences (e.g. from cwltool stderr)."""
    import re
    return re.sub(r"\x1b\[[0-9;]*m", "", s or "")


def _runtime_summary_table_md(runtime_results: dict) -> str:
    """Build a markdown table: Tool | Runtime | Data used | Reason (if fail)."""
    def cell(s: str, max_len: int = 80) -> str:
        s = _strip_ansi((s or "").replace("\n", " ").replace("|", "\\|").strip())
        return s[:max_len] + ("…" if len(s) > max_len else "")

    lines = [
        "| Tool | Runtime | Data used | Reason (if fail) |",
        "|------|---------|-----------|------------------|",
    ]
    for name in sorted(runtime_results.keys()):
        r = runtime_results[name]
        data_str = ", ".join(r.data_used) if r.data_used else "—"
        reason = r.fail_reason or "—"
        lines.append(
            f"| {cell(name)} | {r.label} | {cell(data_str, 60)} | {cell(reason, 60)} |"
        )
    return "\n".join(lines)


def _runtime_report_block(
    runtime_results: dict,
    schema_results: dict[str, bool],
) -> str:
    """Build markdown block for runtime validation (standalone report)."""
    sections: list[str] = []
    for name in sorted(runtime_results.keys()):
        r = runtime_results[name]
        schema_ok = schema_results.get(name, True)
        sections.append(f"## {name}\n")
        sections.append(f"- **Schema validation**: {'PASS' if schema_ok else 'FAIL'}\n")
        sections.append(f"- **Runtime validation**: {r.label}\n")
        sections.append(f"- **Data used**: {', '.join(r.data_used) or 'none'}\n")
        if r.example_job_path and r.example_job_path.exists():
            sections.append(f"- **Example job**: `{r.example_job_path.name}`\n")
        if not r.passed and r.fail_reason:
            sections.append(f"- **Reason (not pass)**: {_strip_ansi(r.fail_reason)}\n")
        sections.append("\n")
    return "".join(sections)


def _runtime_block_lines(r: "RuntimeValidationResult") -> list[str]:
    """Build the list of lines for a ### Runtime validation block."""
    lines = [
        "### Runtime validation",
        f"- **Runtime**: {r.label}",
        f"- **Data used**: {', '.join(r.data_used) or 'none'}",
    ]
    fix_rounds = getattr(r, "fix_rounds", 0)
    cwl_modified = getattr(r, "cwl_modified", False)
    if fix_rounds > 0:
        lines.append(f"- **Fix rounds**: {fix_rounds} (CWL modified by LLM)")
    elif cwl_modified:
        lines.append("- **CWL modified**: yes")
    if r.example_job_path and r.example_job_path.exists():
        lines.append(f"- **Example job**: `{r.example_job_path.name}`")
    if not r.passed and r.fail_reason:
        lines.append(f"- **Reason (not pass)**: {_strip_ansi(r.fail_reason)}")
    lines.append("")
    return lines


def _merge_runtime_into_report(
    existing_content: str,
    runtime_results: dict,
    schema_results: dict[str, bool],
) -> str:
    """Insert or update Runtime validation subsection for each ## tool in report."""
    lines = existing_content.split("\n")
    out: list[str] = []
    i = 0
    current_tool: Optional[str] = None
    merged_tools: set[str] = set()

    while i < len(lines):
        line = lines[i]
        stripped = line.strip()
        # Start of a tool section: ## tool_name
        if line.startswith("## ") and not line.startswith("### "):
            # Before starting next section, append runtime block for previous tool (if any)
            if current_tool and current_tool in runtime_results:
                r = runtime_results[current_tool]
                out.extend(_runtime_block_lines(r))
                merged_tools.add(current_tool)
            current_tool = stripped[3:].strip() if len(stripped) > 3 else None
            out.append(line)
            i += 1
            continue
        # Replace existing "### Runtime validation" block with new content
        if current_tool and stripped == "### Runtime validation":
            r = runtime_results.get(current_tool)
            if r is not None:
                out.extend(_runtime_block_lines(r))
                merged_tools.add(current_tool)
            i += 1
            while i < len(lines):
                next_line = lines[i]
                if next_line.startswith("### ") or next_line.startswith("## "):
                    out.append(next_line)
                    i += 1
                    break
                i += 1
            continue
        out.append(line)
        i += 1

    # Append runtime block for the last section (if it matched a tool)
    if current_tool and current_tool in runtime_results:
        r = runtime_results[current_tool]
        out.extend(_runtime_block_lines(r))
        merged_tools.add(current_tool)

    # If report has no ## tool_name sections (e.g. "## Tool Description" / "## Metadata"
    # only), append runtime block at end for each unmerged tool (e.g. single-tool report)
    for tool_name, r in runtime_results.items():
        if tool_name in merged_tools:
            continue
        out.extend(_runtime_block_lines(r))

    return "\n".join(out)


def _display_summary_multi(results: list) -> None:
    """Display a summary table for multiple CWL results (one per subcommand)."""
    from cwlagent.agent import AgentResult

    table = Table(title="Generation Summary (subcommands)", show_header=True)
    table.add_column("Tool / CWL", style="cyan")
    table.add_column("Validation", style="white")
    table.add_column("Docker Image", style="white")
    for r in results:
        if not isinstance(r, AgentResult):
            continue
        v_style = "green" if r.validation_passed else "red"
        v_label = r.labels.get("validation", "")
        table.add_row(
            r.tool_name,
            f"[{v_style}]{v_label}[/{v_style}]",
            r.docker_image or "Not found",
        )
    console.print(table)
    console.print(f"\n[bold green]Generated {len(results)} CWL file(s).[/]")


@app.command()
def validate(
    cwl_file: Path = typer.Argument(
        ...,
        help="Path to CWL file to validate.",
        exists=True,
    ),
    verbose: bool = typer.Option(
        False,
        "-v",
        "--verbose",
        help="Enable verbose logging.",
    ),
) -> None:
    """
    Validate a CWL file using cwltool.

    Example:
        cwlagent validate tool.cwl
    """
    setup_logging(verbose)

    from cwlagent.validator import CWLValidator

    validator = CWLValidator()
    result = validator.validate_file(cwl_file)

    if result.is_valid:
        console.print(f"[bold green]✓ PASS[/] - {cwl_file} is valid CWL.")
    else:
        console.print(f"[bold red]✗ FAIL[/] - {cwl_file} has validation errors:")
        for error in result.errors:
            console.print(f"  • {error}")

    if result.warnings:
        console.print("\n[bold yellow]Warnings:[/]")
        for warning in result.warnings:
            console.print(f"  • {warning}")

    raise typer.Exit(code=0 if result.is_valid else 1)


@app.command()
def validate_run(
    cwl_dir: Path = typer.Argument(
        ...,
        help="Directory containing CWL files to validate with real examples.",
        exists=True,
        file_okay=False,
        dir_okay=True,
    ),
    no_container: bool = typer.Option(
        False,
        "--no-container/--container",
        help="Use Docker (or container runtime) by default. Use --no-container to run without container.",
    ),
    timeout: int = typer.Option(
        120,
        "--timeout",
        "-t",
        help="Execution timeout per tool in seconds.",
    ),
    api_key: Optional[str] = typer.Option(
        None,
        "--api-key",
        envvar="GOOGLE_API_KEY",
        help="Google API key for Gemini. When set, use LLM to plan test data per input.",
    ),
    model: str = typer.Option(
        "gemini-3-flash-preview",
        "--model",
        "-m",
        help="Gemini model to use for LLM planning.",
    ),
    no_llm: bool = typer.Option(
        False,
        "--no-llm",
        help="Disable LLM planning; use heuristics only for test data.",
    ),
    report_only: bool = typer.Option(
        False,
        "--report-only",
        help="Only update report from existing job results (no run).",
    ),
    testdata_dir: Optional[Path] = typer.Option(
        None,
        "--testdata-dir",
        help="Shared folder for test data (generate here and reuse across tools). Default: <cwl_dir>/testdata.",
    ),
    verbose: bool = typer.Option(
        False,
        "-v",
        "--verbose",
        help="Enable verbose logging.",
    ),
    keep_docker_image: bool = typer.Option(
        False,
        "--keep-docker-image",
        help="Do not remove Docker container after each run (pass --leave-container to cwltool).",
    ),
    use_singularity: bool = typer.Option(
        False,
        "--singularity",
        help="Use Singularity instead of Docker.",
    ),
) -> None:
    """
    Validate each CWL in a directory by running it with a simple example.

    When GOOGLE_API_KEY (or --api-key) is set, uses LLM to plan which test
    data to use per input (e.g. any_file for md5sum, fasta for samtools).
    Otherwise uses heuristics. Test data is generated into a shared folder
    (--testdata-dir or <cwl_dir>/testdata) and reused across tools.
    Saves example jobs as <tool>_job.json and report.md with runtime result.
    """
    setup_logging(verbose)

    api_key = _normalize_api_key(api_key)
    if api_key:
        os.environ["GOOGLE_API_KEY"] = api_key  # SDK may read env; use normalized key

    from cwlagent.runtime_validator import (
        RuntimeValidationResult,
        validate_cwl_directory,
    )
    from cwlagent.validator import CWLValidator

    cwl_dir = Path(cwl_dir).resolve()
    cwl_files = sorted(cwl_dir.glob("*.cwl"))
    if not cwl_files:
        console.print(f"[bold yellow]No .cwl files in[/] {cwl_dir}")
        raise typer.Exit(code=0)

    # Schema validation for each (for report)
    schema_validator = CWLValidator()
    schema_results: dict[str, bool] = {}
    for cwl_file in cwl_files:
        r = schema_validator.validate_file(cwl_file)
        schema_results[cwl_file.stem] = r.is_valid

    if report_only:
        # Load existing job results from report or _runtime_results.json if we had saved it
        console.print("[bold yellow]--report-only: run without it to execute.[/]")
        raise typer.Exit(code=0)

    use_llm = bool(api_key) and not no_llm
    if use_llm:
        console.print("[bold blue]Using LLM to plan test data...[/]")
    console.print(f"[bold blue]Running runtime validation for {len(cwl_files)} CWL(s)...[/]")
    runtime_results = validate_cwl_directory(
        cwl_dir,
        timeout=timeout,
        use_container=not no_container,
        out_dir=cwl_dir,
        testdata_dir=testdata_dir,
        api_key=api_key,
        model=model,
        use_llm=use_llm,
        keep_docker_image=keep_docker_image,
        use_singularity=use_singularity,
    )

    report_file = cwl_dir / "report.md"
    base_name = cwl_dir.name
    runtime_block = _runtime_report_block(runtime_results, schema_results)

    if report_file.exists():
        report_content = _merge_runtime_into_report(
            report_file.read_text(), runtime_results, schema_results
        )
    else:
        report_content = (
            f"# {base_name} CWL Runtime Validation Report\n\n"
            + runtime_block
        )

    # Remove existing "## Runtime validation summary" section so we replace it
    report_lines = report_content.split("\n")
    filtered: list[str] = []
    skip = False
    for i, line in enumerate(report_lines):
        if line.strip() == "## Runtime validation summary":
            skip = True
            continue
        if skip:
            if line.startswith("## ") or (line.startswith("#") and not line.startswith("## ")):
                skip = False
                filtered.append(line)
            continue
        filtered.append(line)

    # Insert full summary table after the first line (title)
    table_md = (
        "## Runtime validation summary\n\n"
        + _runtime_summary_table_md(runtime_results)
        + "\n\n"
    )
    if filtered:
        report_content = filtered[0] + "\n\n" + table_md + "\n".join(filtered[1:])
    else:
        report_content = table_md
    report_file.write_text(report_content)
    console.print(f"[bold green]Saved report to[/] {report_file}")

    # Summary table
    table = Table(title="Runtime validation summary", show_header=True)
    table.add_column("Tool", style="cyan")
    table.add_column("Runtime", style="white")
    table.add_column("Data used", style="white")
    table.add_column("Reason (if fail)", style="white")
    for name in sorted(runtime_results.keys()):
        r = runtime_results[name]
        style = "green" if r.passed else "red"
        data_str = ", ".join(r.data_used) or "—"
        reason = (r.fail_reason or "—")[:60]
        table.add_row(name, f"[{style}]{r.label}[/{style}]", data_str, reason)
    console.print(table)

    failed = sum(1 for r in runtime_results.values() if not r.passed)
    if not failed:
        update_report_metadata(report_file, "Validation-run", "PASS")
    
    if failed:
        raise typer.Exit(code=1)
    raise typer.Exit(code=0)


@app.command()
def skill(
    tool_dir: Path = typer.Argument(
        ...,
        help="Directory of the tool (must contain report.md or be formatted as a tool directory).",
        exists=True,
        file_okay=False,
        dir_okay=True,
    ),
    api_key: Optional[str] = typer.Option(
        None,
        "--api-key",
        envvar="GOOGLE_API_KEY",
        help="Google API key for Gemini.",
    ),
    model: str = typer.Option(
        "gemini-3-flash-preview",
        "--model",
        "-m",
        help="Gemini model to use.",
    ),
    verbose: bool = typer.Option(
        False,
        "-v",
        "--verbose",
        help="Enable verbose logging.",
    ),
) -> None:
    """
    Generate a SKILL.md for a tool based on its documentation.

    Looks for report.md in the tool directory to find the homepage URL.
    Generates the skill into <tool_dir>/skills/SKILL.md.
    """
    setup_logging(verbose)

    api_key = _normalize_api_key(api_key)
    if api_key:
        os.environ["GOOGLE_API_KEY"] = api_key

    from cwlagent.skill_generator import SkillGenerator

    # 1. Deduce tool name
    tool_name = tool_dir.name

    # 2. Find homepages from report.md (all metadata sections)
    homepages = []
    report_file = tool_dir / "report.md"
    if report_file.exists():
        content = report_file.read_text()
        # Look for "- **Homepage**: https://..." in Metadata sections
        matches = re.findall(r"- \*\*Homepage\*\*: (https?://[^\s]+)", content)
        if matches:
            # Use unique URLs only
            homepages = list(dict.fromkeys(matches))
            console.print(f"[bold green]Found homepages in report.md:[/] {', '.join(homepages)}")
    
    if not homepages:
        console.print(f"[bold yellow]No homepages found in report.md. Agent will use general knowledge.[/]")

    # 3. Generate Skill
    console.print(f"[bold blue]Generating skill for {tool_name}...[/]")
    
    output_dir = tool_dir / "skills"
    
    async def _run():
        generator = SkillGenerator(api_key=api_key, model=model)
        # Pass report content as fallback for examples
        report_content = report_file.read_text(encoding="utf-8") if report_file.exists() else None
        success = await generator.generate_skill(tool_name, homepages, output_dir, report_content=report_content)
        return success

    try:
        success = asyncio.run(_run())
        if success:
            console.print(f"[bold green]Skill generated successfully at[/] {output_dir}/SKILL.md")
            update_report_metadata(report_file, "Skill", "generated")
        else:
            console.print(f"[bold yellow]Skill not generated for {tool_name} (no useful documentation or examples found).[/]")
            update_report_metadata(report_file, "Skill", "not generated")
    except Exception as e:
        console.print(f"[bold red]Error generating skill:[/] {e}")
        update_report_metadata(report_file, "Skill", "not generated")
        if verbose:
            import traceback
            console.print(traceback.format_exc())
        raise typer.Exit(code=1)


@app.command()
def info() -> None:
    """
    Show information about the CWL Agent installation.
    """
    from cwlagent.validator import CWLValidator

    console.print(Panel(
        f"[bold]CWL Agent[/] version {__version__}\n\n"
        "AI-powered CWL CommandLineTool generator from CLI help text.\n"
        "Uses Google Gemini for intelligent parsing of CLI help documents.",
        title="About",
        border_style="blue",
    ))

    # Check cwltool
    validator = CWLValidator()
    cwltool_available = validator.check_cwltool_available()
    cwltool_version = validator.get_cwltool_version() if cwltool_available else None

    table = Table(title="Dependencies", show_header=True)
    table.add_column("Component", style="cyan")
    table.add_column("Status", style="white")

    if cwltool_available:
        table.add_row("cwltool", f"[green]✓ Available[/] ({cwltool_version})")
    else:
        table.add_row("cwltool", "[red]✗ Not found[/]")

    console.print(table)


if __name__ == "__main__":
    app()
