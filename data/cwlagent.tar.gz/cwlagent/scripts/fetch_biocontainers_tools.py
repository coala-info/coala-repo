#!/usr/bin/env python3
"""
Fetch the full list of tools from the BioContainers GA4GH TRS API.

API: https://api.biocontainers.pro/ga4gh/trs/v2/ui/
Uses GET /tools with pagination (limit, offset) until all tools are retrieved.
"""

from __future__ import annotations

import argparse
import asyncio
import json
import sys
from pathlib import Path

import httpx

TRS_API_BASE = "https://api.biocontainers.pro/ga4gh/trs/v2"
DEFAULT_LIMIT = 1000
DEFAULT_TIMEOUT = 60.0
MAX_RETRIES = 3
RETRY_DELAY = 2.0


async def fetch_all_tools(
    *,
    limit: int = DEFAULT_LIMIT,
    timeout: float = DEFAULT_TIMEOUT,
    organization: str | None = None,
) -> list[dict]:
    """Fetch all tools from TRS API via pagination."""
    all_tools: list[dict] = []
    offset = 0
    url = f"{TRS_API_BASE}/tools"
    params: dict[str, str | int] = {"limit": limit, "offset": str(offset)}
    if organization:
        params["organization"] = organization

    async with httpx.AsyncClient(timeout=timeout) as client:
        while True:
            params["offset"] = str(offset)
            last_error: Exception | None = None
            for attempt in range(MAX_RETRIES):
                try:
                    resp = await client.get(url, params=params)
                    resp.raise_for_status()
                except httpx.HTTPError as e:
                    last_error = e
                    if attempt < MAX_RETRIES - 1:
                        print(f"Request failed (attempt {attempt + 1}/{MAX_RETRIES}): {e}; retrying...", file=sys.stderr)
                        await asyncio.sleep(RETRY_DELAY)
                        continue
                    print(f"Request failed: {e}", file=sys.stderr)
                    raise
                # Parse JSON; API may return empty body or non-JSON on errors
                try:
                    if not resp.content:
                        data = []
                    else:
                        data = resp.json()
                except json.JSONDecodeError as e:
                    last_error = e
                    if attempt < MAX_RETRIES - 1:
                        print(f"Invalid JSON at offset {offset} (attempt {attempt + 1}/{MAX_RETRIES}): {e}; retrying...", file=sys.stderr)
                        await asyncio.sleep(RETRY_DELAY)
                        continue
                    print(f"Invalid JSON at offset {offset}: {e}. Saving {len(all_tools)} tools so far.", file=sys.stderr)
                    return all_tools
                break  # success: exit retry loop
            if isinstance(data, dict):
                data = [data]
            if not isinstance(data, list):
                print(f"Unexpected response type: {type(data)}", file=sys.stderr)
                break
            if not data:
                break
            all_tools.extend(data)
            print(f"Fetched offset {offset}: {len(data)} tools (total so far: {len(all_tools)})", file=sys.stderr)
            offset += limit
    return all_tools


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Fetch full list of tools from BioContainers TRS API"
    )
    parser.add_argument(
        "-o",
        "--output",
        type=Path,
        default=None,
        help="Output JSON file (default: print to stdout)",
    )
    parser.add_argument(
        "--limit",
        type=int,
        default=DEFAULT_LIMIT,
        help=f"Page size (default: {DEFAULT_LIMIT})",
    )
    parser.add_argument(
        "--timeout",
        type=float,
        default=DEFAULT_TIMEOUT,
        help=f"HTTP timeout in seconds (default: {DEFAULT_TIMEOUT})",
    )
    parser.add_argument(
        "--organization",
        type=str,
        default=None,
        help="Filter by organization (e.g. biocontainers)",
    )
    args = parser.parse_args()

    tools = asyncio.run(
        fetch_all_tools(
            limit=args.limit,
            timeout=args.timeout,
            organization=args.organization,
        )
    )
    out = json.dumps(tools, indent=2)
    if args.output:
        args.output.write_text(out)
        print(f"Wrote {len(tools)} tools to {args.output}", file=sys.stderr)
    else:
        print(out)
    return 0


if __name__ == "__main__":
    sys.exit(main())
