"""
Pydantic data models for CLI parsing and CWL generation.

This module defines the intermediate data structures used to represent
parsed CLI information and CWL CommandLineTool structures.
"""

from __future__ import annotations

from enum import Enum
from typing import Any, Optional, Union

from pydantic import BaseModel, Field


class ArgumentType(str, Enum):
    """Type of CLI argument."""

    FLAG = "flag"  # Boolean flag (--verbose)
    OPTION = "option"  # Option with value (--output FILE)
    POSITIONAL = "positional"  # Positional argument


class CWLType(str, Enum):
    """CWL primitive types."""

    NULL = "null"
    BOOLEAN = "boolean"
    INT = "int"
    LONG = "long"
    FLOAT = "float"
    DOUBLE = "double"
    STRING = "string"
    FILE = "File"
    DIRECTORY = "Directory"


class CLIArgument(BaseModel):
    """Represents a parsed CLI argument from help text."""

    name: str = Field(..., description="Argument identifier (e.g., 'input_file', 'verbose')")
    arg_type: ArgumentType = Field(..., description="Type of argument")
    short_flag: Optional[str] = Field(None, description="Short flag (e.g., '-v')")
    long_flag: Optional[str] = Field(None, description="Long flag (e.g., '--verbose')")
    description: Optional[str] = Field(None, description="Argument description from help text")
    value_type: CWLType = Field(CWLType.STRING, description="Inferred CWL type for the value")
    is_required: bool = Field(False, description="Whether the argument is required")
    is_array: bool = Field(False, description="Whether multiple values are accepted")
    default_value: Optional[Any] = Field(None, description="Default value if specified")
    position: Optional[int] = Field(None, description="Position for positional arguments")
    is_output: bool = Field(False, description="Whether this is an output file/directory")
    choices: Optional[list[str]] = Field(None, description="Allowed values for enum-like args")

    @property
    def cwl_id(self) -> str:
        """Generate a valid CWL identifier."""
        # Convert to snake_case and remove invalid characters
        name = self.name.replace("-", "_").replace(" ", "_")
        # Remove leading digits
        while name and name[0].isdigit():
            name = name[1:]
        return name or "arg"

    @property
    def prefix(self) -> Optional[str]:
        """Get the command-line prefix to use."""
        return self.long_flag or self.short_flag


class CLIToolInfo(BaseModel):
    """Represents parsed information about a CLI tool."""

    name: str = Field(..., description="Tool name")
    base_command: Union[str, list[str]] = Field(..., description="Base command to invoke the tool")
    description: Optional[str] = Field(None, description="Tool description")
    version: Optional[str] = Field(None, description="Tool version if detected")
    arguments: list[CLIArgument] = Field(default_factory=list, description="Parsed arguments")
    subcommand: Optional[str] = Field(None, description="Subcommand if applicable")
    usage_pattern: Optional[str] = Field(None, description="Usage pattern from help text")

    @property
    def input_arguments(self) -> list[CLIArgument]:
        """Get arguments that are inputs."""
        return [arg for arg in self.arguments if not arg.is_output]

    @property
    def output_arguments(self) -> list[CLIArgument]:
        """Get arguments that are outputs."""
        return [arg for arg in self.arguments if arg.is_output]


class CommandLineBinding(BaseModel):
    """CWL CommandLineBinding specification."""

    position: Optional[int] = Field(None, description="Position in command line")
    prefix: Optional[str] = Field(None, description="Command line prefix")
    separate: bool = Field(True, description="Whether prefix and value are separate")
    item_separator: Optional[str] = Field(None, description="Separator for array values")
    shell_quote: bool = Field(True, description="Whether to shell-quote the value")
    value_from: Optional[str] = Field(None, description="Expression to compute value")


class CommandOutputBinding(BaseModel):
    """CWL CommandOutputBinding specification."""

    glob: Optional[Union[str, list[str]]] = Field(None, description="Glob pattern for output")
    output_eval: Optional[str] = Field(None, description="Expression to evaluate output")
    load_contents: bool = Field(False, description="Whether to load file contents")


class CWLInputParameter(BaseModel):
    """CWL CommandInputParameter specification."""

    id: str = Field(..., alias="id", description="Parameter identifier")
    type_: Union[str, dict[str, Any], list[Union[str, dict[str, Any]]]] = Field(
        ..., alias="type", description="CWL type"
    )
    label: Optional[str] = Field(None, description="Human-readable label")
    doc: Optional[str] = Field(None, description="Documentation string")
    default: Optional[Any] = Field(None, description="Default value")
    input_binding: Optional[CommandLineBinding] = Field(
        None, alias="inputBinding", description="Command line binding"
    )

    model_config = {"populate_by_name": True}


class CWLOutputParameter(BaseModel):
    """CWL CommandOutputParameter specification."""

    id: str = Field(..., alias="id", description="Parameter identifier")
    type_: Union[str, dict[str, Any], list[Union[str, dict[str, Any]]]] = Field(
        ..., alias="type", description="CWL type"
    )
    label: Optional[str] = Field(None, description="Human-readable label")
    doc: Optional[str] = Field(None, description="Documentation string")
    output_binding: Optional[CommandOutputBinding] = Field(
        None, alias="outputBinding", description="Output binding"
    )

    model_config = {"populate_by_name": True}


class DockerRequirement(BaseModel):
    """CWL DockerRequirement."""

    class_: str = Field("DockerRequirement", alias="class")
    docker_pull: Optional[str] = Field(None, alias="dockerPull")
    docker_load: Optional[str] = Field(None, alias="dockerLoad")
    docker_file: Optional[str] = Field(None, alias="dockerFile")
    docker_import: Optional[str] = Field(None, alias="dockerImport")

    model_config = {"populate_by_name": True}


class ResourceRequirement(BaseModel):
    """CWL ResourceRequirement."""

    class_: str = Field("ResourceRequirement", alias="class")
    cores_min: Optional[Union[int, float]] = Field(None, alias="coresMin")
    cores_max: Optional[Union[int, float]] = Field(None, alias="coresMax")
    ram_min: Optional[int] = Field(None, alias="ramMin")
    ram_max: Optional[int] = Field(None, alias="ramMax")
    tmpdir_min: Optional[int] = Field(None, alias="tmpdirMin")
    tmpdir_max: Optional[int] = Field(None, alias="tmpdirMax")
    outdir_min: Optional[int] = Field(None, alias="outdirMin")
    outdir_max: Optional[int] = Field(None, alias="outdirMax")

    model_config = {"populate_by_name": True}


class CWLCommandLineTool(BaseModel):
    """Complete CWL CommandLineTool document."""

    cwl_version: str = Field("v1.2", alias="cwlVersion")
    class_: str = Field("CommandLineTool", alias="class")
    base_command: Union[str, list[str]] = Field(..., alias="baseCommand")
    inputs: list[CWLInputParameter] = Field(default_factory=list)
    outputs: list[CWLOutputParameter] = Field(default_factory=list)
    label: Optional[str] = Field(None)
    doc: Optional[str] = Field(None)
    arguments: Optional[list[Union[str, CommandLineBinding]]] = Field(None)
    requirements: Optional[list[Union[DockerRequirement, ResourceRequirement, dict[str, Any]]]] = (
        Field(None)
    )
    hints: Optional[list[Union[DockerRequirement, ResourceRequirement, dict[str, Any]]]] = Field(
        None
    )
    stdin: Optional[str] = Field(None)
    stdout: Optional[str] = Field(None)
    stderr: Optional[str] = Field(None)
    success_codes: Optional[list[int]] = Field(None, alias="successCodes")
    temporary_fail_codes: Optional[list[int]] = Field(None, alias="temporaryFailCodes")
    permanent_fail_codes: Optional[list[int]] = Field(None, alias="permanentFailCodes")

    model_config = {"populate_by_name": True}

    def to_yaml_dict(self) -> dict[str, Any]:
        """Convert to a dictionary suitable for YAML serialization."""
        result = {}

        # Always include cwlVersion and class first
        result["cwlVersion"] = self.cwl_version
        result["class"] = self.class_

        # Add baseCommand
        result["baseCommand"] = self.base_command

        # Add optional documentation
        if self.label:
            result["label"] = self.label
        if self.doc:
            result["doc"] = self.doc

        # Add inputs
        result["inputs"] = self._serialize_inputs()

        # Add outputs
        result["outputs"] = self._serialize_outputs()

        # Add optional fields
        if self.arguments:
            result["arguments"] = self.arguments
        if self.requirements:
            result["requirements"] = self._serialize_requirements(self.requirements)
        if self.hints:
            result["hints"] = self._serialize_requirements(self.hints)
        if self.stdin:
            result["stdin"] = self.stdin
        if self.stdout:
            result["stdout"] = self.stdout
        if self.stderr:
            result["stderr"] = self.stderr
        if self.success_codes:
            result["successCodes"] = self.success_codes
        if self.temporary_fail_codes:
            result["temporaryFailCodes"] = self.temporary_fail_codes
        if self.permanent_fail_codes:
            result["permanentFailCodes"] = self.permanent_fail_codes

        return result

    def _serialize_inputs(self) -> list[dict[str, Any]]:
        """Serialize input parameters."""
        result = []
        for inp in self.inputs:
            item: dict[str, Any] = {"id": inp.id, "type": inp.type_}
            if inp.label:
                item["label"] = inp.label
            if inp.doc:
                item["doc"] = inp.doc
            if inp.default is not None:
                item["default"] = inp.default
            if inp.input_binding:
                binding: dict[str, Any] = {}
                if inp.input_binding.position is not None:
                    binding["position"] = inp.input_binding.position
                if inp.input_binding.prefix:
                    binding["prefix"] = inp.input_binding.prefix
                if not inp.input_binding.separate:
                    binding["separate"] = False
                if inp.input_binding.item_separator:
                    binding["itemSeparator"] = inp.input_binding.item_separator
                if not inp.input_binding.shell_quote:
                    binding["shellQuote"] = False
                if inp.input_binding.value_from:
                    binding["valueFrom"] = inp.input_binding.value_from
                if binding:
                    item["inputBinding"] = binding
            result.append(item)
        return result

    def _serialize_outputs(self) -> list[dict[str, Any]]:
        """Serialize output parameters."""
        result = []
        for out in self.outputs:
            item: dict[str, Any] = {"id": out.id, "type": out.type_}
            if out.label:
                item["label"] = out.label
            if out.doc:
                item["doc"] = out.doc
            if out.output_binding:
                binding: dict[str, Any] = {}
                if out.output_binding.glob:
                    binding["glob"] = out.output_binding.glob
                if out.output_binding.output_eval:
                    binding["outputEval"] = out.output_binding.output_eval
                if out.output_binding.load_contents:
                    binding["loadContents"] = True
                if binding:
                    item["outputBinding"] = binding
            result.append(item)
        return result

    def _serialize_requirements(
        self, reqs: list[Union[DockerRequirement, ResourceRequirement, dict[str, Any]]]
    ) -> list[dict[str, Any]]:
        """Serialize requirements/hints."""
        result = []
        for req in reqs:
            if isinstance(req, dict):
                result.append(req)
            else:
                item = req.model_dump(by_alias=True, exclude_none=True)
                result.append(item)
        return result
