#!/usr/bin/env python3
"""
List all organizations from the BioContainers GA4GH TRS API.

API: https://api.biocontainers.pro/ga4gh/trs/v2/ui/
Tries GET /facets first; if no organization facet, paginates GET /tools and
collects unique organization values from tool objects.
"""

from __future__ import annotations

import argparse
import asyncio
import sys
from pathlib import Path

import httpx

TRS_API_BASE = "https://api.biocontainers.pro/ga4gh/trs/v2"
DEFAULT_TIMEOUT = 60.0
DEFAULT_LIMIT = 1000


async def fetch_organizations_from_facets(
    client: httpx.AsyncClient, timeout: float = DEFAULT_TIMEOUT
) -> list[str]:
    """Get organization names from GET /facets if the API exposes an organization facet."""
    url = f"{TRS_API_BASE}/facets"
    resp = await client.get(url, timeout=timeout)
    resp.raise_for_status()
    data = resp.json()
    if not isinstance(data, list):
        return []
    for facet in data:
        if isinstance(facet, dict) and (facet.get("facet") or "").lower() == "organization":
            values = facet.get("values") or []
            return [str(v.get("value", "")) for v in values if v.get("value")]
    return []


async def fetch_organizations_from_tools(
    client: httpx.AsyncClient, timeout: float = DEFAULT_TIMEOUT
) -> list[str]:
    """Paginate GET /tools (no org filter) and collect unique organization values."""
    url = f"{TRS_API_BASE}/tools"
    orgs: set[str] = set()
    offset = 0
    limit = DEFAULT_LIMIT
    while True:
        resp = await client.get(
            url, params={"limit": limit, "offset": str(offset)}, timeout=timeout
        )
        resp.raise_for_status()
        data = resp.json()
        if isinstance(data, dict):
            data = [data]
        if not isinstance(data, list) or not data:
            break
        for tool in data:
            if isinstance(tool, dict) and tool.get("organization"):
                orgs.add(str(tool["organization"]).strip())
        if len(data) < limit:
            break
        offset += limit
    return sorted(orgs)


async def fetch_organizations(
    timeout: float = DEFAULT_TIMEOUT, verbose: bool = True
) -> list[str]:
    """Fetch all organization names: try /facets first, then fallback to /tools."""
    async with httpx.AsyncClient() as client:
        orgs = await fetch_organizations_from_facets(client, timeout=timeout)
        if not orgs:
            if verbose:
                print("No organization facet in /facets; collecting from /tools...", file=sys.stderr)
            orgs = await fetch_organizations_from_tools(client, timeout=timeout)
    return sorted(orgs)


def main() -> int:
    parser = argparse.ArgumentParser(
        description="List organizations from BioContainers TRS API /facets"
    )
    parser.add_argument(
        "-o",
        "--output",
        type=Path,
        default=None,
        help="Output txt file (one organization per line); default: print to stdout",
    )
    parser.add_argument(
        "--timeout",
        type=float,
        default=DEFAULT_TIMEOUT,
        help=f"HTTP timeout in seconds (default: {DEFAULT_TIMEOUT})",
    )
    args = parser.parse_args()

    try:
        orgs = asyncio.run(fetch_organizations(timeout=args.timeout))
    except httpx.HTTPError as e:
        print(f"Request failed: {e}", file=sys.stderr)
        return 1
    orgs = sorted(orgs)
    out = "\n".join(orgs)
    if args.output:
        args.output.write_text(out)
        print(f"Wrote {len(orgs)} organizations to {args.output}", file=sys.stderr)
    else:
        print(out)
    return 0


if __name__ == "__main__":
    sys.exit(main())
