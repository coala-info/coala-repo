# Inputs and Outputs (CWL CommandLineTool)

## Input types

- Primitives: `string`, `boolean`, `int`, `long`, `float`, `double`, `null`.
- Complex: `array`, `record`.
- Special: `File`, `Directory`, `Any`.
- Optional: suffix with `?` (e.g. `File?`). Omit from job = not on command line.

File inputs: provide as `{ class: File, path: /path/to/file }` in the job. Input files are read-only; to "update" an input, copy it to the output directory (e.g. via InitialWorkDirRequirement).

## inputBinding

- **position**: Relative order on command line (default 0). Non-sequential is fine (e.g. 1, 3, 5).
- **prefix**: Optional; separate argument before value unless `separate: false`.
- **separate**: If `false`, prefix and value become one argument (e.g. `-i42`, `--file=/path`).
- **valueFrom**: Expression for the value (requires InlineJavascriptRequirement if JavaScript).
- **itemSeparator**: For arrays, join items into one argument (e.g. `","`).
- **inputBinding** on array vs on **items**: Outer binding repeats prefix per item; inner can use `prefix: -B=` and `separate: false` for `-B=one` style.

Boolean: if true, prefix is added; if false, nothing added.

## Array inputs

- Type: `string[]` or `type: array` with `items: string` (etc.).
- Job: YAML list or JSON array.
- Binding on array: each item can get its own prefix/position; use **itemSeparator** to produce one argument.

## Records and unions

- **Record** (dependent fields): `type: record` with `fields:`; all required unless marked optional.
- **Union** (exclusive): `type: [recordA, recordB]`; only one variant provided in job. In expressions, handle which variant is present (types differ).

## Outputs

- **outputBinding**:
  - **glob**: Pattern in output directory (literal or expression, e.g. `$(inputs.name).txt`). Multiple matches → array if output type is array.
  - **loadContents**: true to read file contents into the output object.
  - **outputEval**: Expression to transform (e.g. `$(self[0].contents)`).
- **type: stdout**: Use with top-level `stdout: filename` to capture stdout as a File.
- **format** / **secondaryFiles**: Optional; see CWL spec. Use EDAM for bioinformatics formats.

## Parameter references in outputs

References like `$(inputs.extractfile)` are allowed in **outputBinding** `glob` and `outputEval`. Use `inputs` for job inputs; for File path use `inputs.foo.path`.
