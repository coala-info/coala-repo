# Expressions and runtime (CWL)

## Parameter references

- Syntax: `$(...)`. Subset of JavaScript.
- **inputs**: `$(inputs.id)`, `$(inputs["id"])`, `$(inputs['id'])`. For File: `$(inputs.foo.path)`, `$(inputs.foo.basename)`, etc.
- **runtime**: `$(runtime.outdir)`, `$(runtime.tmpdir)`, `$(runtime.ram)`, `$(runtime.cores)`, `$(runtime.outdirSize)`, `$(runtime.tmpdirSize)`.

Use **arguments** for fixed or runtime-derived args, e.g. `arguments: ["-d", $(runtime.outdir)]`.

## Where references are allowed

- CommandLineTool: **arguments** (valueFrom), **stdin**, **stdout**, **stderr**; CommandInputParameter **format**, **secondaryFiles**, inputBinding **valueFrom**; CommandOutputParameter **format**, **secondaryFiles**; outputBinding **glob**, **outputEval**.
- ResourceRequirement: coresMin/Max, ramMin/Max, tmpdirMin/Max, outdirMin/Max.
- InitialWorkDirRequirement: **listing**, Dirent **entry**, **entryname**.
- EnvVarRequirement: envDef **envValue**.

## Inline JavaScript (InlineJavascriptRequirement)

Add `requirements: InlineJavascriptRequirement: {}` when using JavaScript in expressions (e.g. `.split()`, conditionals). Only ECMAScript 5.1 is guaranteed.

Use **valueFrom** in arguments or inputBinding for expressions. Prefer built-in File properties (`basename`, `nameroot`, `nameext`, etc.) over JavaScript when possible.

## expressionLib

- **expressionLib**: List of inline strings or `{ $include: path/to/file.js }` to define functions/variables used in expressions. Inline and external can be combined.
- Expressions in the CWL document can then call those functions (e.g. `$(myFunc(inputs.msg))`).

## Exclusive inputs and expressions

If an input is a union (e.g. `null | enum`), the value in `inputs` may be `null`. In **outputEval** or other expressions, handle null (e.g. `$(inputs.file_format || 'auto')`) to avoid type errors.
