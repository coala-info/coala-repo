"""
CWL Agent - AI-powered CWL CommandLineTool generator from CLI help text.

This package provides tools to automatically generate valid CWL v1.2 CommandLineTool
documents by parsing command-line tool help text using LLM-based extraction.
"""

__version__ = "0.1.0"

from cwlagent.models import (
    CLIArgument,
    CLIToolInfo,
    CWLCommandLineTool,
)
from cwlagent.parser import HelpTextParser
from cwlagent.generator import CWLGenerator
from cwlagent.validator import CWLValidator
from cwlagent.agent import CWLAgent

__all__ = [
    "CLIArgument",
    "CLIToolInfo",
    "CWLCommandLineTool",
    "HelpTextParser",
    "CWLGenerator",
    "CWLValidator",
    "CWLAgent",
]
