# CWL Agent

AI-powered CWL CommandLineTool generator from CLI help text.

## Overview

CWL Agent uses Google Gemini to intelligently parse command-line tool help documents and generate valid CWL (Common Workflow Language) v1.2 CommandLineTool specifications.

## Features

- **Intelligent Parsing**: Uses Gemini LLM to extract structured information from CLI help text
- **CWL v1.2**: Generates valid CWL v1.2 CommandLineTool documents
- **BioContainers Integration**: Automatically searches for Docker images from BioContainers
- **Tool Homepage Search**: Finds and includes tool homepage URLs
- **Validation**: Validates generated CWL using cwltool
- **Demo Execution**: Optionally runs demo execution of generated CWL
- **Rich CLI**: Beautiful command-line interface with progress indicators

## Installation

```bash
pip install cwlagent
```

Or install from source:

```bash
git clone https://github.com/your-org/cwlagent
cd cwlagent
pip install -e .
```

## Usage

### Generate CWL from a command

```bash
# Set your Google API key
export GOOGLE_API_KEY="your-api-key"

# Generate CWL for md5sum
cwlagent generate md5sum

# Save to file
cwlagent generate md5sum -o md5sum.cwl

# Output as JSON with all metadata
cwlagent generate md5sum --json
```

### Generate from help text via stdin

```bash
md5sum --help | cwlagent generate

# Or for complex tools
samtools view --help | cwlagent generate
```

### Validate a CWL file

```bash
cwlagent validate tool.cwl
```

### Python API

```python
from cwlagent import CWLAgent

# Create agent
agent = CWLAgent(
    api_key="your-google-api-key",  # or set GOOGLE_API_KEY env var
    model="gemini-2.5-flash",
    use_docker=True,  # search BioContainers
    run_demo=False,   # optionally run demo execution
)

# Generate from help text
help_text = """Usage: md5sum [OPTION]... [FILE]...
Print or check MD5 (128-bit) checksums.
..."""

result = agent.generate(help_text, tool_name="md5sum")

# Access results
print(result.cwl_yaml)                    # CWL YAML content
print(result.validation_passed)           # True/False
print(result.labels["validation"])        # "PASS" or "FAIL"
print(result.docker_image)                # e.g., "quay.io/biocontainers/..."
print(result.tool_homepage)               # e.g., "https://www.gnu.org/..."

# Or generate directly from a command
result = CWLAgent.from_command("md5sum", api_key="your-key")
```

## Output Format

The generated CWL includes:

- **cwlVersion**: v1.2
- **class**: CommandLineTool
- **baseCommand**: Detected command
- **inputs**: All parsed input parameters with types and descriptions
- **outputs**: Detected output parameters
- **doc**: Tool description + original help text
- **hints**: DockerRequirement with BioContainers image (if found)

### Example Output

```yaml
cwlVersion: v1.2
class: CommandLineTool
baseCommand: md5sum
label: md5sum
doc: |
  Print or check MD5 (128-bit) checksums.
  
  Tool homepage: https://www.gnu.org/software/coreutils/
  
  Original help text:
  ```
  Usage: md5sum [OPTION]... [FILE]...
  ...
  ```

inputs:
  - id: files
    type:
      - 'null'
      - type: array
        items: File
    doc: Files to compute checksums for
    inputBinding:
      position: 1

  - id: binary
    type:
      - 'null'
      - boolean
    doc: read in binary mode
    inputBinding:
      prefix: --binary
      position: 101

outputs:
  - id: stdout
    type: stdout
    doc: Standard output

hints:
  - class: DockerRequirement
    dockerPull: quay.io/biocontainers/coreutils:8.31

stdout: md5sum.out
```

## CWL skill and LLM context

When using the **direct** generation method (`--method direct`), the agent loads the **CWL CommandLineTool skill** (from `skills/cwl-commandlinetool/SKILL.md` and reference docs) into the LLM system prompt. This gives the model structured guidance on CWL structure, inputs/outputs, `inputBinding`, staging, and best practices, improving generated CWL quality.

- **Skill location**: The package ships a bundled copy under `cwlagent/data/skills/cwl-commandlinetool/`. To override (e.g. use the repo’s `skills/`), set the environment variable **`CWLAGENT_SKILLS_DIR`** to the directory that contains a `skills` subdirectory (e.g. the repo root).
- **LangChain**: The project uses **LangChain** (`langchain-google-genai`, `langchain-core`) for the Gemini LLM only. The [LangChain skills pattern](https://docs.langchain.com/oss/python/langchain/multi-agent/skills) (progressive disclosure via a `load_skill` tool) is applied here by **injecting the skill content into the system prompt** when generating CWL, rather than adding a separate agent loop with tool-calling. This keeps the pipeline simple while still loading the CWL skill into the LLM for generation.

## Requirements

- Python 3.10+
- Google API key for Gemini
- cwltool (for validation and demo execution)

## Development

```bash
# Install with dev dependencies
pip install -e ".[dev]"

# Run tests
pytest

# Run linting
ruff check .
```

## License

MIT License
