# Staging input files and creating files at runtime (CWL)

## Problem: read-only inputs

Runners stage input files in a read-only directory. Tools that write next to the input (e.g. `samtools faidx` writing `.fai`) will fail. Fix: stage a writable copy in the job's working directory using **InitialWorkDirRequirement**. Do **not** use InitialWorkDirRequirement when the tool does not write next to the input—CWL stages File inputs automatically.

## Staging an input into the work dir

1. Add **InitialWorkDirRequirement** (list it first in `requirements`).
2. **listing**: Include the input so it appears in the job directory. Example: a single Dirent that references the input file:
   - `listing: [ $(inputs.src) ]` — stages the file; runner may link or copy.
   - Or use a Dirent with **entry** and **entryname** to control the name (e.g. `entryname: $(inputs.src.basename)`, `entry: $(inputs.src)`).
3. Input binding for the main file: use **position** and **valueFrom: $(self.basename)** (or the **entryname** you chose) on that input's **inputBinding** only—so the command receives the path inside the work dir. Do **not** add a top-level **arguments** entry with the same position; that would pass the same value twice.

Result: the tool sees the file in the current (writable) directory and can create sidecar files (e.g. `.fai`).

## Copy vs link

Listing `$(inputs.src)` typically gives the runner the option to link or copy. For tools that modify in place or expect a writable directory, ensure the requirement is InitialWorkDirRequirement and the bound argument is the path in the work dir.

## Creating files at runtime

Use **InitialWorkDirRequirement** with **listing** entries that are **Dirent** with:
- **entryname**: Filename in the work dir (e.g. `config.yaml`, `run.sh`).
- **entry**: Inline content (multiline with `|-`) or expression. CWL expands `$(inputs.x)` in the content before writing.

**Use cases:**
1. **Config file as input** — Tools that read options from a file (e.g. YAML/JSON config) instead of the command line. Generate the config from CWL inputs via `$(inputs.option1)`, `$(inputs.option2)`, etc., write it with a Dirent, then pass the generated path to **baseCommand** or as an input path.
2. **Custom wrapper script with parameters** — Build a script (e.g. shell) that uses CWL input values; set **baseCommand** to run that script (e.g. `["sh", "run.sh"]`). The script can call the underlying tool with arguments derived from the job.

**Escaping:** CWL expressions are evaluated before the file is created; shell variables in the generated file must not be interpreted by CWL. Escape literal `$` as `\$` (e.g. `\${PREFIX}` in the CWL source becomes `${PREFIX}` in the file, for the shell to expand). See [Creating Files at Runtime](https://www.commonwl.org/user_guide/topics/creating-files-at-runtime.html).

## Order of requirements

Place InitialWorkDirRequirement first in **requirements** so the work dir is prepared before the command runs.
