"""
CWL CommandLineTool generator from parsed CLI information.

This module converts parsed CLI tool information into valid CWL v1.2
CommandLineTool documents.
"""

from __future__ import annotations

import io
import logging
from typing import Any, Optional, Union

from ruamel.yaml import YAML
from ruamel.yaml.comments import CommentedMap, CommentedSeq

from cwlagent.models import (
    ArgumentType,
    CLIArgument,
    CLIToolInfo,
    CommandLineBinding,
    CommandOutputBinding,
    CWLCommandLineTool,
    CWLInputParameter,
    CWLOutputParameter,
    CWLType,
)

logger = logging.getLogger(__name__)

# Meta-options that should not appear as CWL inputs (help/version are for humans, not workflows)
HELP_VERSION_LONG_FLAGS = frozenset({"--help", "--version"})
HELP_VERSION_CWL_IDS = frozenset({"help", "version", "version_info", "usage"})


def _is_help_version_arg(arg: CLIArgument) -> bool:
    """True if this argument is --help / --version or equivalent; omit from CWL inputs."""
    if arg.long_flag and arg.long_flag in HELP_VERSION_LONG_FLAGS:
        return True
    cwl_id = (arg.name or "").replace("-", "_").strip().lower()
    if cwl_id in HELP_VERSION_CWL_IDS:
        return True
    # -h is often --help; only treat as help if description/name suggests it
    if arg.short_flag == "-h" and arg.long_flag == "--help":
        return True
    if arg.short_flag == "-h" and (arg.description or "").lower().find("help") >= 0:
        return True
    return False


class CWLGenerator:
    """
    Generator for CWL CommandLineTool documents.

    Converts parsed CLI information into valid CWL v1.2 YAML.
    """

    def __init__(
        self,
        cwl_version: str = "v1.2",
        add_doc_comments: bool = True,
        stdout_capture: bool = False,
    ):
        """
        Initialize the generator.

        Args:
            cwl_version: CWL version to use (default: v1.2)
            add_doc_comments: Whether to add documentation comments
            stdout_capture: Whether to capture stdout by default if no outputs defined
        """
        self.cwl_version = cwl_version
        self.add_doc_comments = add_doc_comments
        self.stdout_capture = stdout_capture

    def generate(self, tool_info: CLIToolInfo) -> CWLCommandLineTool:
        """
        Generate a CWL CommandLineTool from parsed CLI info.

        Args:
            tool_info: Parsed CLI tool information

        Returns:
            CWL CommandLineTool model
        """
        # Build inputs
        inputs = self._build_inputs(tool_info)

        # Build outputs
        outputs = self._build_outputs(tool_info)

        # If no outputs and stdout_capture is enabled, capture stdout
        if not outputs and self.stdout_capture:
            outputs = [
                CWLOutputParameter(
                    id="stdout",
                    type_="stdout",
                    doc="Standard output",
                )
            ]

        # Build the CommandLineTool
        cwl = CWLCommandLineTool(
            cwl_version=self.cwl_version,
            class_="CommandLineTool",
            base_command=tool_info.base_command,
            inputs=inputs,
            outputs=outputs,
            label=tool_info.name,
            doc=tool_info.description,
        )

        # Add stdout capture if we're using stdout type
        if any(out.type_ == "stdout" for out in outputs):
            cwl.stdout = f"{tool_info.name}.out"

        return cwl

    def _build_inputs(self, tool_info: CLIToolInfo) -> list[CWLInputParameter]:
        """Build CWL input parameters from CLI arguments."""
        inputs = []
        position_counter = 1

        # Sort arguments: positional first (by position), then flags/options
        # Exclude help/version meta-options (not needed in CWL workflows)
        input_args = [a for a in tool_info.input_arguments if not _is_help_version_arg(a)]
        sorted_args = sorted(
            input_args,
            key=lambda a: (
                0 if a.arg_type == ArgumentType.POSITIONAL else 1,
                a.position or 999,
                a.name,
            ),
        )

        for arg in sorted_args:
            cwl_type = self._build_type(arg)
            binding = self._build_input_binding(arg, position_counter)

            if arg.arg_type == ArgumentType.POSITIONAL:
                position_counter += 1

            param = CWLInputParameter(
                id=arg.cwl_id,
                type_=cwl_type,
                doc=arg.description,
                default=arg.default_value,
                input_binding=binding,
            )
            inputs.append(param)

        return inputs

    def _build_outputs(self, tool_info: CLIToolInfo) -> list[CWLOutputParameter]:
        """Build CWL output parameters from CLI arguments marked as outputs."""
        outputs = []

        for arg in tool_info.output_arguments:
            cwl_type = self._build_output_type(arg)

            # Create output binding with glob pattern
            binding = CommandOutputBinding(
                glob=f"$(inputs.{arg.cwl_id})"
                if arg.arg_type != ArgumentType.POSITIONAL
                else f"*.out",  # Generic pattern for positional outputs
            )

            param = CWLOutputParameter(
                id=arg.cwl_id,
                type_=cwl_type,
                doc=arg.description,
                output_binding=binding,
            )
            outputs.append(param)

        return outputs

    def _build_type(self, arg: CLIArgument) -> Union[str, list[str], dict[str, Any]]:
        """Build CWL type specification for an argument."""
        base_type = arg.value_type.value

        # Handle arrays
        if arg.is_array:
            type_def: dict[str, Any] = {"type": "array", "items": base_type}
            if not arg.is_required:
                return ["null", type_def]
            return type_def

        # Handle optional types
        if not arg.is_required:
            return ["null", base_type]

        return base_type

    def _build_output_type(self, arg: CLIArgument) -> Union[str, list[str]]:
        """Build CWL type for output parameter."""
        # Outputs are typically File or Directory
        if arg.value_type == CWLType.DIRECTORY:
            base_type = "Directory"
        else:
            base_type = "File"

        # Handle optional outputs
        if not arg.is_required:
            return ["null", base_type]

        return base_type

    def _build_input_binding(
        self, arg: CLIArgument, position: int
    ) -> Optional[CommandLineBinding]:
        """Build CommandLineBinding for an input parameter."""
        if arg.arg_type == ArgumentType.POSITIONAL:
            return CommandLineBinding(position=position)

        if arg.arg_type == ArgumentType.FLAG:
            # Boolean flags use prefix only when true
            return CommandLineBinding(
                prefix=arg.prefix,
                position=position + 100,  # Flags after positionals
            )

        # Options with values
        return CommandLineBinding(
            prefix=arg.prefix,
            position=position + 100,
        )

    def to_yaml(self, cwl: CWLCommandLineTool) -> str:
        """
        Convert CWL CommandLineTool to YAML string.

        Args:
            cwl: The CWL model to serialize

        Returns:
            YAML string
        """
        yaml = YAML()
        yaml.default_flow_style = False
        yaml.indent(mapping=2, sequence=4, offset=2)
        yaml.preserve_quotes = True

        # Get the dict representation
        data = cwl.to_yaml_dict()

        # Convert to CommentedMap for nice formatting
        result = self._to_commented_map(data)

        # Serialize to string
        import io

        stream = io.StringIO()
        yaml.dump(result, stream)
        return stream.getvalue()

    def _to_commented_map(self, data: Any) -> Any:
        """Convert dict to CommentedMap for ruamel.yaml."""
        if isinstance(data, dict):
            result = CommentedMap()
            for key, value in data.items():
                result[key] = self._to_commented_map(value)
            return result
        elif isinstance(data, list):
            result = CommentedSeq()
            for item in data:
                result.append(self._to_commented_map(item))
            return result
        else:
            return data

    def generate_yaml(self, tool_info: CLIToolInfo) -> str:
        """
        Generate CWL YAML directly from tool info.

        Convenience method combining generate() and to_yaml().

        Args:
            tool_info: Parsed CLI tool information

        Returns:
            CWL YAML string
        """
        cwl = self.generate(tool_info)
        return self.to_yaml(cwl)


def _normalize_cwl_data(data: Any) -> dict[str, Any]:
    """
    Normalize loaded CWL dict so Pydantic can validate it.

    - Converts ruamel.yaml CommentedMap/CommentedSeq to plain dict/list.
    - Converts CWL map-form inputs/outputs (id -> param) to list form (list of params).
    """
    if hasattr(data, "items") and not isinstance(data, dict):
        data = dict(data)
    if not isinstance(data, dict):
        return data

    result: dict[str, Any] = {}
    for key, value in data.items():
        k = str(key)
        if k == "inputs" and value is not None:
            if hasattr(value, "items") and not isinstance(value, list):
                # Map form: { id: { type: ..., ... } } -> list form
                out = []
                for id_key, v in value.items():
                    plain = _to_plain(v)
                    if isinstance(plain, dict):
                        out.append(dict({"id": id_key, **plain}))
                    else:
                        out.append({"id": id_key})
                value = out
            else:
                value = _to_plain_list(value)
        elif k == "outputs" and value is not None:
            if hasattr(value, "items") and not isinstance(value, list):
                out = []
                for id_key, v in value.items():
                    plain = _to_plain(v)
                    if isinstance(plain, dict):
                        out.append(dict({"id": id_key, **plain}))
                    else:
                        out.append({"id": id_key})
                value = out
            else:
                value = _to_plain_list(value)
        elif k in ("requirements", "hints") and value is not None:
            # CWL allows map form: DockerRequirement: { dockerPull: ... } -> list form
            if hasattr(value, "items") and not isinstance(value, list):
                out = []
                for class_key, v in value.items():
                    plain = _to_plain(v)
                    if isinstance(plain, dict):
                        out.append(dict({"class": str(class_key), **plain}))
                    else:
                        out.append({"class": str(class_key)})
                value = out
            else:
                value = _to_plain_list(value)
        else:
            value = _to_plain(value)
        result[k] = value
    return result


def _to_plain(obj: Any) -> Any:
    """Convert ruamel.yaml / nested structures to plain Python for Pydantic."""
    if obj is None:
        return None
    if isinstance(obj, dict):
        return {str(k): _to_plain(v) for k, v in obj.items()}
    if hasattr(obj, "items") and not isinstance(obj, dict):
        return {str(k): _to_plain(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)) or (
        hasattr(obj, "__iter__") and not isinstance(obj, (str, bytes))
    ):
        try:
            return [_to_plain(item) for item in obj]
        except TypeError:
            return obj
    return obj


def _to_plain_list(obj: Any) -> list[Any]:
    """Convert to plain list, preserving list form of inputs/outputs."""
    if obj is None:
        return []
    if isinstance(obj, list):
        return [_to_plain(item) for item in obj]
    if hasattr(obj, "__iter__") and not isinstance(obj, (str, bytes, dict)):
        try:
            return [_to_plain(item) for item in obj]
        except TypeError:
            pass
    return []


def load_cwl_yaml(cwl_yaml: str) -> CWLCommandLineTool:
    """
    Parse a CWL YAML string into a CWLCommandLineTool model.

    Accepts both list-form and map-form inputs/outputs (CWL allows either).
    Normalizes ruamel.yaml types (CommentedMap/CommentedSeq) to plain dict/list.

    Args:
        cwl_yaml: CWL document as YAML string (e.g. from direct LLM generation).

    Returns:
        CWLCommandLineTool model instance.

    Raises:
        ValueError: If the YAML is invalid or does not represent a CommandLineTool.
    """
    yaml = YAML()
    try:
        data = yaml.load(io.StringIO(cwl_yaml))
    except Exception as e:
        raise ValueError(f"Invalid CWL YAML: {e}") from e
    if not data:
        raise ValueError("Empty CWL YAML")
    data = _normalize_cwl_data(data)
    try:
        return CWLCommandLineTool.model_validate(data)
    except Exception as e:
        raise ValueError(f"CWL document is not a valid CommandLineTool: {e}") from e


class CWLTemplateGenerator:
    """
    Generator that produces CWL from templates.

    Useful for specific tool types with known patterns.
    """

    TEMPLATES = {
        "simple": """
cwlVersion: v1.2
class: CommandLineTool
baseCommand: {base_command}
label: {label}
doc: {doc}

inputs:
{inputs}

outputs:
{outputs}
""",
        "docker": """
cwlVersion: v1.2
class: CommandLineTool
baseCommand: {base_command}
label: {label}
doc: {doc}

requirements:
  DockerRequirement:
    dockerPull: {docker_image}

inputs:
{inputs}

outputs:
{outputs}
""",
    }

    def generate_from_template(
        self,
        template_name: str,
        base_command: Union[str, list[str]],
        label: str,
        doc: str,
        inputs: list[dict[str, Any]],
        outputs: list[dict[str, Any]],
        **kwargs: Any,
    ) -> str:
        """Generate CWL from a template."""
        template = self.TEMPLATES.get(template_name, self.TEMPLATES["simple"])

        # Format base_command
        if isinstance(base_command, list):
            bc_str = str(base_command)
        else:
            bc_str = base_command

        # Format inputs
        inputs_yaml = self._format_params(inputs)

        # Format outputs
        outputs_yaml = self._format_params(outputs)

        return template.format(
            base_command=bc_str,
            label=label,
            doc=doc or "",
            inputs=inputs_yaml,
            outputs=outputs_yaml,
            **kwargs,
        )

    def _format_params(self, params: list[dict[str, Any]]) -> str:
        """Format parameters as YAML."""
        if not params:
            return "  []"

        lines = []
        for param in params:
            lines.append(f"  - id: {param['id']}")
            lines.append(f"    type: {param['type']}")
            if param.get("doc"):
                lines.append(f"    doc: {param['doc']}")
            if param.get("inputBinding"):
                lines.append("    inputBinding:")
                for key, value in param["inputBinding"].items():
                    lines.append(f"      {key}: {value}")
            if param.get("outputBinding"):
                lines.append("    outputBinding:")
                for key, value in param["outputBinding"].items():
                    lines.append(f"      {key}: {value}")
        return "\n".join(lines)
